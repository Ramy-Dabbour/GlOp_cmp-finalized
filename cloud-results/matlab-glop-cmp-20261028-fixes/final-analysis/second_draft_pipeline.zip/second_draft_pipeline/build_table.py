import numpy as np, pandas as pd, scipy.io as sio, sys
sys.path.insert(0,'/home/claude/handoff/paper_project/analysis_pkg')
import fpf_analysis as F
A='/mnt/user-data/uploads/MATLAB/GlOp_cmp/cloud-results/matlab-glop-cmp-20261028-fixes/'
t=pd.read_csv(A+'final-analysis/trial_table_raw.csv')
print(len(t), t.gid.is_unique)
rows=[]
for gid in (24136,29058):
    cp=sio.loadmat(A+f'final-analysis/trial_{gid}.mat',struct_as_record=False,squeeze_me=True)['checkpoint']
    r=cp.result; ref=r.referenceResult; mz=r.mziResult
    raw=np.atleast_1d(r.rawSincReference).astype(float); Am=np.asarray(mz.realizedCoefficientMatrix)
    E=F.end_to_end_error(raw,Am); dc,evn=F.half_band_deviation(Am)
    x=np.atleast_1d(ref.x).astype(float)
    rows.append(dict(gid=gid,order=int(r.firOrder),ratio=float(r.passbandRatio),seed=int(r.randomSeed),trial=int(r.trialIndex),refSolver=int(r.referenceSolver),mziSolver=int(r.mziSolver),
      status=str(cp.status),legacy_success=int(bool(r.success)),failureStage='',failureIdentifier='',ref_present=1,ref_exit=float(ref.metrics.exitFlag),ref_valid=int(bool(ref.isValidSolution)),ref_conv=int(bool(ref.metrics.converged)),
      ref_evals=float(ref.metrics.functionEvaluations),ref_seconds=float(ref.metrics.elapsedSeconds),ref_objective=float(ref.objectiveValue),ref_progress=float(ref.metrics.progressCount),ref_message=str(getattr(ref.output,'message',''))[:90],
      mzi_present=1,mzi_exit=float(mz.metrics.exitFlag),mzi_valid=int(bool(mz.isValidSolution)),mzi_conv=int(bool(mz.metrics.converged)),mzi_evals=float(mz.metrics.functionEvaluations),mzi_seconds=float(mz.metrics.elapsedSeconds),
      mzi_objective=float(mz.normalizedFrobeniusError),mzi_progress=float(mz.metrics.progressCount),mzi_message=str(getattr(mz.output,'message',''))[:90],mzi_normalized=int(bool(mz.isResponseNormalized)),
      E_saved=float(cp.error),record_elapsed_seconds=float(cp.elapsedSeconds),started_at=str(cp.startedAt),completed_at=str(cp.completedAt),E=E,E_bound=F.half_band_bound(raw),hb_dc_dev=dc,hb_even_dev=evn,
      s1_dist_x_target=float(np.linalg.norm(x-raw)/np.linalg.norm(raw)),phiFixed=float(mz.phiFixed)))
    print(rows[-1])
t=pd.concat([t,pd.DataFrame(rows)],ignore_index=True).sort_values('gid').reset_index(drop=True)
t['from_mat_checkpoint']=t.gid.isin([24136,29058]).astype(int)
# cross-check with exported csv
c=pd.read_csv(A+'final/trial_results.csv').set_index('trial_id')
m=t.set_index('gid')
print('E diff',(m.E-c.error).abs().max(),'Esaved diff',(m.E_saved-c.error).abs().max(),'evals diff',((m.ref_evals+m.mzi_evals)-c.evaluations).abs().max())
for a,b in (('order','fir_order'),('ratio','passband_ratio'),('seed','seed'),('refSolver','reference_solver'),('mziSolver','mzi_solver'),('trial','repetition'),('legacy_success','success')):
    print(a,(m[a]!=c[b]).sum())
print('status',(m.status!=c.status).sum())
# baseline
base={}
for o in range(4,13):
    for r in (.2,.3,.4,.5): base[(o,r)]=F.stage1_baseline(o,r,4001)
b=pd.DataFrame([dict(order=o,ratio=r,baseline_lower=v[0],baseline_upper=v[1],bviol=v[2],bfeas=v[3],bok=v[4]) for (o,r),v in base.items()])
print(b.describe().T); print((b.baseline_upper-b.baseline_lower).max(), b.bfeas.all(), b.bok.all())
b.to_csv('baseline.csv',index=False)
t=t.merge(b[['order','ratio','baseline_lower','baseline_upper']],on=['order','ratio'],how='left')
t['s1_gap_to_baseline']=t.ref_objective-t.baseline_lower
S=['GA','PSO','SO','SA','PS','PaS']
t['ref']=t.refSolver.map(dict(enumerate(S))); t['mzi']=t.mziSolver.map(dict(enumerate(S)))
t['both_valid']=(t.ref_valid.astype(bool)&t.mzi_valid.astype(bool)&t.mzi_present.astype(bool))
t['delta']=np.sqrt(np.maximum(t.E**2-t.E_bound**2,0)); t.loc[~t.both_valid,'delta']=np.nan
t['delta_dB']=20*np.log10(t.delta)
t['total_evals']=t.ref_evals.fillna(0)+t.mzi_evals.fillna(0); t['total_seconds']=t.ref_seconds.fillna(0)+t.mzi_seconds.fillna(0)
t['Cev']=t.total_evals; t['Tsec']=t.total_seconds
t.to_csv('trial_delta.csv',index=False)
print(t.shape, t.both_valid.mean(), t.status.value_counts().to_dict(), (t.failureIdentifier.fillna('')!='').sum())
print('margin min',(t.E-t.E_bound).min(),'hb',t.hb_dc_dev.max(),t.hb_even_dev.max(),'recompute',(t.E-t.E_saved).abs().max())
print('s1 gap min',t.s1_gap_to_baseline.min(), 'dist vs obj',(t.s1_dist_x_target-t.ref_objective).abs().max())
print(t.groupby(['ref','mzi']).size().unique(), t.groupby(['order','ratio','seed']).size().unique())
