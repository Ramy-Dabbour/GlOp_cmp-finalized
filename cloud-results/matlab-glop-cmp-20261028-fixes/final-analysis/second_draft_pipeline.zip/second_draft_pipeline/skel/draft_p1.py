# Partial draft, part 1: front matter, I. Introduction, II. Problem formulation.
import json, numpy as np
import lib, dlib
from lib import para, rich, run, h1, h2, h5, note
from dlib import cite, eq, eqref, tabref, figref
import draft_data as D
from draft_data import Y, C

OM = json.load(open('/home/claude/pp/skel/eq/omml_all.json'))
ET = json.load(open('/home/claude/pp/skel/etop_table.json'))

TITLE = 'Pairing Global Optimizers Across a Two-Stage Design Pipeline for Half-Band Mach–Zehnder Lattice Filters'
KEYWORDS = ('global optimization; derivative-free optimization; benchmarking; photonic integrated circuits; '
            'Mach–Zehnder lattice; FIR filter synthesis; particle swarm optimization; surrogate optimization')


def B(t):
    return para('BodyText', rich(t))


def sci(x, d=0):
    e = int(np.floor(np.log10(abs(x))))
    m = x / 10 ** e
    if float(f'{m:.{d}f}') >= 10:
        m /= 10; e += 1
    return f'{m:.{d}f}×10^−{abs(e)}^' if e < 0 else f'{m:.{d}f}×10^{e}^'


def abstract_text():
    CORE = ('GA', 'PSO', 'SO', 'PS')
    good = [D.P(r, m) for r in ('GA', 'PSO') for m in CORE]
    lo, hi = min(good), max(good)
    bad1 = max(D.P(r, m) for r in ('SO', 'SA') for m in D.S)
    e2 = [D.stage_cost(s)['e2'] for s in D.S]
    b25 = D.boot('PSO', 'PSO', -25, 'P')
    fl = D.FLOOR_DB
    return (
        'Cascaded Mach–Zehnder interferometer (MZI) lattices realize optical finite-impulse-response (FIR) filters, '
        'but a truncated low-pass target is not realizable, so design becomes a constrained approximation over periodic parameters. '
        'We study a two-stage procedure for a half-band lattice: Stage 1 finds the admissible response nearest to a truncated-sinc target, '
        'and Stage 2 fits the coupler angles and a shared phase to it. '
        'Optimizer rankings from analytic test functions need not carry over to a pipeline whose first stage hands the second a solver-dependent target. '
        'We therefore pair six MATLAB global optimizers at each stage, which gives 36 pipelines, and run each on 108 operating points '
        '(nine orders, four passband ratios, three seeds) with 20 repeats, 77,760 trials in all, every one of which completed. '
        'A trial succeeds when the error above the half-band bound is within a tolerance fixed in advance; '
        'we report the success fraction and the cost per success. '
        f'The first-stage solver set the final error. With a particle-swarm or genetic-algorithm first stage, {100 * lo:.0f} to {100 * hi:.0f}% of trials came within −20 dB of the target '
        f'when the second stage was a genetic algorithm, particle swarm, surrogate optimization or pattern search, and most of the failures fell on one operating point whose attainable error sits at that tolerance; '
        f'with surrogate optimization or simulated annealing as the first stage at most {100 * bad1:.1f}% did. '
        f'Particle swarm followed by surrogate optimization was the cheapest reliable pipeline in evaluations ({D.ert("PSO", "SO") / 1e3:.0f}k per success), '
        f'particle swarm followed by pattern search the cheapest in time ({D.ert("PSO", "PS", -20, "s"):.0f} s per success), '
        f'and particle swarm at both stages the most accurate ({D.P("PSO", "PSO", -25):.2f} success at −25 dB, 95% interval {b25[0]:.2f}–{b25[1]:.2f}). '
        f'A convex bound shows that passivity limits the attainable error to between −{abs(max(fl.values())):.0f} and −{abs(min(fl.values())):.0f} dB, depending on the operating point, and no trial came within {D.MIN_FLOOR_GAP:.0f} dB of it. '
        f'A ranking by the solvers’ own convergence flags agreed poorly with the ranking by outcome (Kendall’s τ = {D.KT_F_P20:.2f}).')


def build_front():
    title = para('papertitle', run(TITLE))
    author = para('Author',
                  run('Ramy Dabbour') + '<w:r><w:br/></w:r>' +
                  run('Dept. of Electronics and Communications Engineering', i=True) + '<w:r><w:br/></w:r>' +
                  run('The American University in Cairo', i=True) + '<w:r><w:br/></w:r>' +
                  run('Cairo, Egypt') + '<w:r><w:br/></w:r>' + run('ramymdabbour@aucegypt.edu'),
                  '<w:spacing w:before="100" w:beforeAutospacing="1"/>')
    return title, author


def build_p1():
    b = []
    add = b.append
    # ---------------------------------------------------------------- reading key
    add(note('Draft notes · remove before submission', plain=(
        'Second draft, regenerated from the final run (77,760 trials, run matlab-glop-cmp-20261028-fixes) as a model for your own rewrite. '
        'Every number, table and figure now comes from the final per-trial records, so the yellow snapshot marks are gone. '
        '⟪Cyan⟫ marks what only you can supply or should confirm: the MATLAB release of the cloud image, the repository link, the literature-gap sentence, the acknowledgment and the references tagged [verify]. '
        'New since the first draft: the passivity floor on δ (Section II-D, Table II), Fig. 4, three-level hypothesis verdicts, and mechanism statements labeled as observed or conjectured. '
        'Equation, table and figure references and the citation numbers are generated text: check them after you move anything. '
        'The title is a suggestion; your working title was “A Comparison of Global Optimization Algorithms in MATLAB for FIR Filter Design.”')))

    # ---------------------------------------------------------------- abstract
    add(para('Abstract', run('Abstract', i=True) + run('—') + rich(abstract_text())))
    add(para('Keywords', run('Keywords—') + run(KEYWORDS)))

    # ---------------------------------------------------------------- I. Introduction
    add(h1('Introduction'))
    add(B('Cascaded Mach–Zehnder interferometers (MZIs) are a standard building block of optical delay-line filters '
          + cite('jo', 'jk', 'jt') + '. In the lattice form, each stage combines a directional coupler of adjustable coupling angle with a delay and, in every second stage, '
          'a phase shift in one arm. The transfer functions of the cascade are polynomials in the delay variable ⟨z⟩^−1^, so the device is a finite-impulse-response (FIR) filter '
          'whose coefficients are fixed by the angles and phases ' + cite('jk', 'jt') + '. With a balanced output coupler and the delays used in ' + cite('jo') +
          ', every power response of the lattice is half-band, a property that makes such filters important components of wavelength-division multiplexing systems ' + cite('jo') +
          '. The response depends on the physical parameters through products of trigonometric terms, so it is a nonlinear, periodic function of them. '
          'Synthesis procedures ' + cite('jk') + ' recover the parameters of a response that the lattice realizes exactly, but a truncated ideal low-pass response generally cannot be realized, '
          'and its design becomes a constrained approximation over the lattice parameters.'))
    add(B('The design task we study has two stages. The target is the truncated cosine series of an ideal low-pass response with passband ratio ⟨ρ⟩. '
          'Truncation produces ripple that carries the power response outside the interval [0, 1] to which any passive network is confined, so no lattice can reproduce the target. '
          '**Stage 1** finds the admissible response nearest to the target in normalized ℓ~2~ distance, subject to 0 ≤ ⟨F⟩(ω) ≤ 1 at every frequency. '
          '**Stage 2** fits the coupler angles and the shared phase to that reference. Because every set of angles gives a lossless lattice, Stage 2 has no infeasible region, but its variables are periodic. '
          'The stages are coupled: the reference produced by Stage 1 is the target that Stage 2 must fit, so its quality and shape can change the difficulty of Stage 2.'))
    add(B('MATLAB’s Global Optimization Toolbox ' + cite('mw') + ' offers several derivative-free global solvers, and practitioners often choose among them by habit or availability. '
          'Guidance for comparing optimizers exists. Performance profiles ' + cite('dm') + ' summarize cost over a set of problems, best-practice guidelines ' + cite('bh') +
          ' cover experimental design and performance measures, the COCO platform ' + cite('coco') + ' standardizes replicated, budget-aware benchmarking of black-box optimizers, '
          'and no-free-lunch results ' + cite('nfl') + ' imply that a ranking carries over to another problem class only with evidence from that class. '
          'These studies rank optimizers on analytic functions or on single-stage problems. We are not aware of work that ranks pairings of optimizers across an engineering pipeline '
          'in which the first stage hands the second a solver-dependent target. ' + C('Search the literature before you keep this sentence.')))
    add(B('This paper compares six global solvers at each of the two stages, which gives 36 ordered pairs. Each pair runs on 108 operating points (nine FIR orders from 4 to 12, '
          'four passband ratios and three random seeds) with 20 repeats, for 77,760 trials. Our contributions are five. '
          'First, a controlled, reproducible protocol for pairwise stage comparison, in which every pair receives the same problem instance and the same random substream at each stage. '
          'Second, an end-to-end error that scores the realized lattice against the raw target, so that the score depends on neither solver’s intermediate reference. '
          'Third, an outcome-based success measure, the fraction of trials whose error above the half-band bound is within a tolerance from a ladder fixed in advance, '
          'together with the expected cost per success, reported beside the exit-flag index of our earlier analysis, whose agreement with the outcome ranking we measure. '
          'Fourth, a convex lower bound on that error, set by passivity, which shows how much of the tolerance ladder any design could reach. '
          'Fifth, an empirical ranking of the 36 pairs, with the observations that bear on its mechanisms.'))
    add(B('Section II formalizes the lattice and the two stages, Section III describes the six optimizers and states six hypotheses, and Section IV defines the protocol and the metrics. '
          'Section V reports the results, Section VI interprets them and states the threats to validity, and Section VII concludes.'))

    # ---------------------------------------------------------------- II. Problem formulation
    add(h1('Problem Formulation'))
    add(h2('The Lattice'))
    hb = D.HB_MAX
    mnlo, mnhi = abs(D.OVR['min_lo']), abs(D.OVR['min_hi'])
    assert D.OVR['n_out'] == D.OVR['n']
    add(B('The lattice has ⟨K⟩ = ⟨N⟩ + 1 tunable stages, where ⟨N⟩ is the order of the target defined in Section II-B. Stage ⟨k⟩ combines a directional coupler of angle '
          '⟨θ⟩~k~ ∈ [0, 1), measured in turns, with a delay of ⟨d⟩~k~ samples and a phase factor ⟨a⟩~k~ = exp(−j2π⟨φ⟩~k~) in one arm. '
          'The delays are ⟨d⟩~k~ = 2 for ⟨k⟩ < ⟨K⟩ and ⟨d⟩~K~ = 1. The phase is ⟨φ⟩~k~ = ⟨φ⟩ in every second stage counted back from stage ⟨K⟩, '
          'starting with stage ⟨K⟩ − 1, and zero in the others, so the design vector (⟨θ⟩~1~, …, ⟨θ⟩~K~, ⟨φ⟩) has ⟨N⟩ + 2 entries. '
          'With ⟨c⟩~k~ = cos 2π⟨θ⟩~k~ and ⟨s⟩~k~ = sin 2π⟨θ⟩~k~, the stage matrix is'))
    add(eq('stagemat', OM['stagemat']))
    add(B('and the cascade, closed by a fixed balanced coupler ⟨C⟩ = (1/√2)[1 j; j 1], is'))
    add(eq('cascade', OM['cascade']))
    add(B(figref('pipeline') + ' shows the pipeline and the lattice. Each entry of ⟨S⟩(⟨z⟩) is a polynomial in ⟨z⟩^−1^ of degree at most 2⟨N⟩ + 1, so the four power responses '
          '|⟨S⟩~11~|^2^, |⟨S⟩~12~|^2^, |⟨S⟩~21~|^2^ and |⟨S⟩~22~|^2^ are trigonometric polynomials in ω = arg ⟨z⟩ whose Fourier coefficients, '
          'which we call lag coefficients, extend through lag ±(2⟨N⟩ + 1). Every stage matrix and ⟨C⟩ is unitary, so |⟨S⟩~22~| = |⟨S⟩~11~| and |⟨S⟩~12~|^2^ = 1 − |⟨S⟩~11~|^2^. '
          'The delays 2, …, 2, 1 and the balanced output coupler follow the FIR half-band configuration of ' + cite('jo') + ', so every power response ⟨R⟩ satisfies '
          '⟨R⟩(ω + π) = 1 − ⟨R⟩(ω), which means that its lag-0 coefficient is 1/2 and its even-lag coefficients all vanish. '
          ' Here ⟨N⟩ is the order of the target, whereas the power responses of the lattice reach lag 2⟨N⟩ + 1.'))
    # Fig. 1 (pipeline + lattice)
    add(dlib.figure('pipeline', 'fig1_pipeline.png', 3.35, None,
                    'Two-stage design pipeline (a) and the lattice that Stage 2 realizes (b). The delay and the phase shifter φ sit in the same arm; '
                    'φ is applied in every second stage counted back from stage K.',
                    'Block diagram of the two-stage pipeline and drawing of the Mach-Zehnder lattice'))

    add(h2('Target and Stage 1'))
    add(B('The target is the truncated cosine series of an ideal low-pass response with passband edge ⟨ρ⟩π,'))
    add(eq('target', OM['target']))
    add(B(f'where sinc(⟨x⟩) = sin(π⟨x⟩)/(π⟨x⟩) and ⟨F⟩(ω; ⟨t⟩) = ⟨t⟩~0~ + Σ ⟨t⟩~k~ cos ⟨k⟩ω is its power response. '
          f'No tapering window is applied. The truncation produces ripple: for all {D.OVR['n']} combinations of ⟨N⟩ ∈ {{4, …, 12}} and ⟨ρ⟩ ∈ {{0.2, 0.3, 0.4, 0.5}}, '
          f'the minimum of ⟨F⟩(ω; ⟨t⟩) lies between −{mnlo:.2f} and −{mnhi:.2f}, '
          f'and its maximum between {D.OVR["max_lo"]:.2f} and {D.OVR["max_hi"]:.2f}. '
          'A passive network cannot realize a response outside [0, 1], so Stage 1 replaces ⟨t⟩ by the nearest admissible vector ⟨x⟩ ∈ ℝ^⟨N⟩+1^:'))
    add(eq('stage1', OM['stage1']))
    add(B('with ⟨x⟩~0~ ∈ [0, 1] and ⟨x⟩~k~ ∈ [−1, 1], where'))
    add(eq('F', OM['F']))
    add(B('Admissibility is tested in continuous frequency. Writing ⟨F⟩ as a polynomial in cos ω, the test takes the real roots in [−1, 1] of its derivative, adds both endpoints, '
          'and checks 0 ≤ ⟨F⟩ ≤ 1 at all of them with a tolerance of 10^−12^. Because the roots come from floating-point eigenvalue computations, we call this a continuous-domain test, not a certified one. '
          'An inadmissible candidate receives the largest representable double as its objective value, so every solver sees a flat plateau outside the feasible set. '
          'The Stage-1 root computation is not guarded against a failed eigenvalue solve; none occurred in the 77,760 trials.'))
    add(B('Feasible starts are drawn by sampling the DC coefficient ⟨x⟩~0~ uniformly on (0, 1) and the remaining coefficients uniformly in the ℓ~1~ ball of radius min(⟨x⟩~0~, 1 − ⟨x⟩~0~). '
          'Since |Σ ⟨x⟩~k~ cos ⟨k⟩ω| ≤ Σ |⟨x⟩~k~|, every such point is admissible; the ball is a conservative subset of the feasible set, so the sampler is not uniform over admissible responses.'))
    add(B('The objective is a norm and every constraint is linear in ⟨x⟩, so Stage 1 is convex and its minimizer is the unique Euclidean projection of ⟨t⟩ onto the admissible set ' + cite('bv') + '. '
          'We treat it as a black-box problem on purpose, because the study concerns what the second stage inherits from the first, and we report each solver’s gap to a convex baseline for every (⟨N⟩, ⟨ρ⟩). '
          'The baseline is the optimum of a 4,001-point frequency-grid relaxation, which bounds the projection from below, together with a shifted, continuously feasible point, which bounds it from above; '
          f'the two differ by at most {sci(D.BASE_GAP_MAX, 1)}. No Stage-1 run returned a value below the lower bound. ' + 'The gap is a reference for Stage 1 in objective units, not a floor for the final error.'))

    add(h2('Stage 2'))
    add(B('Stage 2 searches the hypercube [0, 1)^⟨N⟩+2^ for the design vector (⟨θ⟩, ⟨φ⟩), wrapped modulo 1, and minimizes'))
    add(eq('J2', OM['J2']))
    add(B('Here ⟨G⟩ is the 4 × (4⟨N⟩ + 3) matrix whose rows hold the lag coefficients of |⟨S⟩~11~|^2^, |⟨S⟩~12~|^2^, |⟨S⟩~21~|^2^ and |⟨S⟩~22~|^2^, '
          'computed as autocorrelations of the field-polynomial coefficients with no frequency sampling ' + cite('os') + '. '
          '⟨R⟩(⟨x⟩) is the matrix of the same shape with rows ⟨g⟩(⟨x⟩), ⟨e⟩~0~ − ⟨g⟩(⟨x⟩), ⟨e⟩~0~ − ⟨g⟩(⟨x⟩), ⟨g⟩(⟨x⟩), '
          'where ⟨g⟩(⟨x⟩) holds ⟨x⟩~0~ at lag 0, ⟨x⟩~k~/2 at lags ±⟨k⟩ and zeros elsewhere, and ⟨e⟩~0~ is the unit vector at lag 0. '
          '⟨x⟩^*^ is the Stage-1 reference. Because every angle gives a unitary lattice, every candidate is physically valid and ⟨J⟩~2~ has no infeasible region. '
          'The program still checks numerically that each realized power response lies in [0, 1] to within 10^−10^ and penalizes a candidate that fails, or whose root computation fails; every returned design passed. '
          'The variables are periodic and the problem is nonconvex.'))

    add(h2('End-to-End Error and the Half-Band Bound'))
    add(B('The Stage-2 objective measures fidelity to a reference that depends on the Stage-1 solver, so it cannot rank pairs. We therefore score every realized lattice against the raw target:'))
    add(eq('E', OM['E']))
    add(B('By Parseval’s relation ' + cite('os') + ', ⟨E⟩ is a normalized, integrated squared error over the four power responses; it is not a measure of ripple, stopband attenuation or phase error. '
          'The half-band structure sets a floor under ⟨E⟩. Let ⟨g⟩~k~ be the lag-⟨k⟩ coefficient of |⟨S⟩~11~|^2^ and '
          '⟨D⟩ = ‖⟨R⟩(⟨t⟩)‖~F~^2^ = 2[⟨ρ⟩^2^ + (1 − ⟨ρ⟩)^2^ + Σ ⟨t⟩~k~^2^]. '
          'The half-band identity gives ⟨g⟩~0~ = 1/2 and ⟨g⟩~k~ = 0 for even ⟨k⟩ ≥ 2, and therefore'))
    add(eq('bound', OM['bound']))
    add(B('More exactly, with ⟨t⟩~k~ = 0 for ⟨k⟩ > ⟨N⟩,'))
    add(eq('decomp', OM['decomp']))
    add(B('The first term depends only on the target and the architecture, and the second is the part that the solvers control. We write'))
    add(eq('delta', OM['delta']))
    add(B('and score every trial on δ. We use δ, and not ⟨E⟩ or ⟨E⟩ − ⟨E⟩~topology~, because the plain excess is about δ^2^/(2⟨E⟩~topology~) and so means different things at different ⟨ρ⟩; '
          'at ⟨ρ⟩ = 0.5 the bound is zero. ' + tabref('etop') + ' lists ⟨E⟩~topology~. Its vanishing at ⟨ρ⟩ = 0.5 reflects only that the even harmonics of the target vanish there, '
          'and does not mean that zero error is attainable. '
          'Section IV-E reports the numerical checks of these identities. The study therefore measures approximation under an architectural constraint, with the constraint’s contribution separated from that of the optimizers.'))
    fl = D.FLOOR_DB
    n30 = sum(1 for k in fl if fl[k] <= -30)
    add(B('Passivity sets a second floor, under δ itself. Every power response of the lattice is a half-band cosine series of degree 2⟨N⟩ + 1 confined to [0, 1], '
          'so δ cannot be smaller than the least distance from the target’s odd harmonics to that set. The set is convex in the odd lag coefficients ⟨g⟩~1~, ⟨g⟩~3~, …, ⟨g⟩~2N+1~, '
          'and we compute the minimum of δ over it for each (⟨N⟩, ⟨ρ⟩): a relaxation on a 6,001-point frequency grid gives a lower bound, and its solution, scaled until it is feasible on a 200,001-point grid, gives an upper bound; '
          f'the two agree to within 10^−5^ dB. This **passivity floor** lies between −{abs(max(fl.values())):.1f} and −{abs(min(fl.values())):.1f} dB over the 36 instances and is at or below −30 dB on {n30} of them (' + tabref('etop') + '). '
          'It bounds every passive half-band response of that degree; we do not show that this lattice, with its single shared phase, attains it. '
          'We computed the floor after the run, so it played no part in choosing the tolerances of Section IV-C.'))
    cols = [4, 6, 8, 10, 12]
    rows = [[f'⟨E⟩~topology~, ⟨ρ⟩ = {rho:.1f}'] + [f'{ET[str(n)][j]:.3f}' for n in cols] for j, rho in enumerate((0.2, 0.3, 0.4, 0.5))]
    rows += [[f'Floor (dB), ⟨ρ⟩ = {rho:.1f}'] + [f'−{abs(fl[(n, rho)]):.1f}' for n in cols] for rho in (0.2, 0.3, 0.4, 0.5)]
    add(dlib.table('etop', 'Half-band bound on the end-to-end error and passivity floor on the scored error, by passband ratio (rows) and order (columns)',
                   [1466, 680, 680, 680, 680, 680], ['⟨N⟩'] + [str(n) for n in cols], rows, row_h=210))
    return ''.join(b)
