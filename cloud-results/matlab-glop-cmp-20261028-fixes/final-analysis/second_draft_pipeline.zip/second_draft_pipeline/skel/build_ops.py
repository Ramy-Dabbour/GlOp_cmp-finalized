import json, sys
import xml.etree.ElementTree as ET
root = ET.fromstring(open('outline_rev91.xml').read())
paras = [''.join(e.itertext()) for e in root.iter('paragraph')]
R = [
("report E as excess over the bound",
 "score solvers on δ = √(E² − bound²), the error above the bound, which is comparable across ρ"),
("Count infrastructure failures separately and fix the retry policy before the cloud run.",
 "Fixed in the program for the full run: telemetry publication is best-effort, live-record writes are retried, and a failed eigenvalue solve in the feasibility test marks the candidate inadmissible instead of raising. Count any remaining exceptions by identifier. The snapshot predates the fixes and is not pooled with the full run."),
("Success becomes outcome-based: both stages valid and the excess of E over the half-band bound at most τ, for a few τ fixed before the full data are opened.",
 "Success becomes outcome-based: both stages valid and δ at most τ, where δ = √(E² − bound²) is the error above the half-band bound (P1b) and τ runs over a ladder in dB fixed before the full data are opened: −20 to −60 dB in 5 dB steps, with every second rung in the main table."),
("No rerun is needed (issue 3)",
 "The analysis itself needs no rerun (issue 3)"),
("No rerun and no change to the MATLAB code are needed for option 2. A separate Python script",
 "The analysis for option 2 needs no change to the trial code and no rerun. A separate Python script"),
("recomputes E from the stored matrices",
 "recomputes E and δ from the stored matrices"),
("The τ list lives in a written analysis plan, and the script hashes the plan into its report. Editing any file in the program folder would break the resume guard, so the analysis stays outside it.",
 "The τ ladder lives in a written analysis plan, and the script hashes the plan into its report. The analysis stays outside the program folder, because any edit there changes the source hash and the resume guard refuses older results. The trial code itself was changed for reliability before the full run: telemetry publication is best-effort, live-record writes are retried, and a failed eigenvalue solve in the feasibility test makes the candidate inadmissible. The full run therefore uses a fresh results folder, and the 4,947-trial snapshot, produced by the earlier code, is a diagnostic only: do not pool it and do not quote its numbers."),
("the fraction of trials that come within a stated excess of the half-band bound, and the evaluations spent per success",
 "the fraction of trials whose error above the half-band bound, δ, is within a stated tolerance, and the evaluations spent per success"),
("whose realized lattice came within a stated tolerance of the half-band bound",
 "whose realized lattice had an error above the half-band bound within a stated tolerance"),
("reached the target excess in 98% of trials",
 "reached the target tolerance on δ in 98% of trials"),
("the fraction of trials within a stated excess over the half-band bound",
 "the fraction of trials whose error above the half-band bound, δ, is within a tolerance from a dB ladder fixed in advance"),
("agreement with a dense grid is a diagnostic, not proof",
 "agreement with a dense grid is a diagnostic, not proof. If the eigenvalue solve inside the root finder fails to converge, the candidate is treated as inadmissible and takes the same penalty as any other infeasible point; report how often that happened [confirm against the final code, including whether the Stage-1 test is guarded too]"),
("the half-band bound of P1b, not the Stage-1 distance",
 "the half-band bound of P1b, not the Stage-1 distance, and that success is scored on δ, the part of E above that bound"),
("success means both stages are valid and the excess of E over the half-band bound is at most τ, for τ values fixed in advance in a written analysis plan",
 "success means both stages are valid and δ, the error above the half-band bound, is at most τ, for τ values (a dB ladder, −20 to −60 dB in 5 dB steps) fixed in advance in a written analysis plan"),
("Treat exceptions (no result produced) as failures and report their count.",
 "Treat any remaining exceptions (no result produced) as failures and report their count by identifier. A telemetry error no longer ends a trial, and a failed eigenvalue solve in the feasibility test is a penalized candidate, not an exception; say so."),
("Define acceptable error as the excess of E over the half-band bound. The bound is fixed by the target and the architecture, so it does not depend on which solvers entered the study.",
 "Define acceptable error as δ = √(E² − bound²), the part of E above the half-band bound, written in dB as 20 log10 δ. The bound is fixed by the target and the architecture, so it does not depend on which solvers entered the study, and δ is comparable across ρ and N. The plain excess E − bound is not: it is about δ²/(2·bound), so one absolute excess is a looser target at ρ = 0.2 than at ρ = 0.4, and at ρ = 0.5 the bound is zero."),
("Otherwise fix a short list of τ before the full data are opened, report P(τ) at each, and show the whole curve of P against τ beside the table. In the 4,947-trial snapshot the best excess found in any instance was 0.0008–0.0024, and at τ = 0.002 the best pair reached about 21% and the median pair 0% (recompute on the full run).",
 "Otherwise fix a ladder before the full data are opened: −20 to −60 dB in 5 dB steps, with the 10 dB subset (−20, −30, −40, −50, −60) in the main table and the other rungs in the supplement. The ladder does not depend on the instance and is log-spaced, as in COCO-style benchmarking; only its step size was informed by the snapshot, and the plan says so. Report P(τ) at each rung and show the whole curve of P against τ beside the table. In the snapshot (ρ = 0.2, seed 0, orders 4–10) the best δ found in any instance was 0.029–0.051 (−31 to −26 dB), and for GA→GA and PSO→pattern search success fell from about 97–98% at −20 dB to about 45–47% at −25 dB and 0% at −30 dB [snapshot only; recompute on the full run]. Rungs that no pair reaches separate nothing, so report the best δ per instance beside the ladder."),
("say if the list was set after looking at part of the data",
 "say if the ladder was set after looking at part of the data"),
("so show both.",
 "so show both. Evaluation counts are incomplete for trials that ended early (flagged cost_incomplete); say how many, because they undercount the cost of failures. Seconds are recorded for every trial."),
("Success at tolerance τ means both stages are valid and the excess of E over the half-band bound is at most τ.",
 "Success at tolerance τ (in dB) means both stages are valid and δ = √(E² − bound²) is at most 10^(τ/20)."),
("within a stated excess of the half-band bound, and the evaluations spent per such success",
 "with an error above the half-band bound, δ, within a stated tolerance, and the evaluations spent per such success"),
("In the snapshot, at τ = 0.002 the best pair reached about 21% and the median pair 0%, so very small τ values separate nothing [recompute on the full run].",
 "In the snapshot, success of the leading pairs fell from about 98% at −20 dB to about 47% at −25 dB and 0% at −30 dB, so rungs below the best attainable δ separate nothing [snapshot only; recompute on the full run]."),
("The best excess found in an instance is positive (0.0008–0.0024 in the snapshot).",
 "The best δ found in an instance is positive (0.029–0.051 in the snapshot, −31 to −26 dB)."),
("Excess error over the half-band bound against seconds and against evaluations, log axes, one point per pair, non-dominated pairs marked",
 "δ in dB against seconds and against evaluations (log axis for cost), one point per pair, non-dominated pairs marked"),
("Per-trial validity, E, excess over the bound, evaluations and seconds",
 "Per-trial validity, E, δ, evaluations and seconds"),
("P against τ (log axis), one curve per pair or for the top pairs",
 "P against τ (dB axis), one curve per pair or for the top pairs"),
("Excess over the bound for all returned designs",
 "δ for all returned designs"),
("Excess, ERT(τ) and P(τ) against FIR order",
 "δ, ERT(τ) and P(τ) against FIR order"),
("Split exceptions into infrastructure failures (for example telemetry file-sharing errors) and numerical exceptions.",
 "Split exceptions by identifier. Telemetry errors no longer end a trial, and a failed eigenvalue solve is a penalized candidate, so report any residual exceptions by class and say that the earlier snapshot is excluded."),
("Report the half-band bound and the excess over it, by ρ. At ρ = 0.2, 0.3 and 0.4 most of E is the bound, so plot the excess, not raw E",
 "Report the half-band bound and δ, by ρ. At ρ = 0.2, 0.3 and 0.4 most of E is the bound, so plot δ in dB, not raw E and not the plain excess, which is not comparable across ρ"),
("Report the excess over the bound and say",
 "Report δ, the error above the bound, and say"),
("Telemetry failures that were counted as scientific failures must be separated or corrected.",
 "In the snapshot, telemetry failures were counted as scientific failures. The program now treats telemetry publication as best-effort, so none should remain in the full run; report any that do, separately."),
]
bad=0
for f,_ in R:
    n=sum(p.count(f) for p in paras)
    if n!=1: print('COUNT',n,'|',f[:90]); bad+=1
print('bad',bad,'ops',len(R))
ops=[{"op":"replace","target":{"kind":"find","text":f},"with":{"from":{"kind":"inline","content":t},"as":"text"}} for f,t in R]
latex = r"\delta=\sqrt{E^2-E_{\mathrm{topology}}^2}=\sqrt{\frac{8}{D}\sum_{\substack{k\le 2N+1\\ k\ \mathrm{odd}}}\left|g_k-\tfrac{t_k}{2}\right|^2},\qquad \delta_{\mathrm{dB}}=20\log_{10}\delta"
md = "```latex\n"+latex+"\n```\n\nδ is the normalized distance of the lattice's odd harmonics from the target, the only part of E the solvers control. Score success on δ, not on E and not on E − E_topology: δ is comparable across ρ and N, whereas the plain excess is about δ²/(2·E_topology) and so means different things at different ρ."
ops.append({"op":"insert","target":{"kind":"blocks","ids":["mqbh6bywb7m.51101"]},"side":"after","source":{"from":{"kind":"inline","content":md},"as":"markdown"}})
json.dump({"ops":ops}, open('skel/ops.json','w'), ensure_ascii=False)
print(len(open('skel/ops.json').read()))
