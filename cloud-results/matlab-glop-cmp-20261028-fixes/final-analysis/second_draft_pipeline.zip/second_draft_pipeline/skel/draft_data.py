# Numbers for the partial draft. Everything quoted in the text comes from here, so that
# the draft can be regenerated from the final export by pointing SRC at the new trial table.
import os
import numpy as np, pandas as pd
from scipy.stats import kendalltau, spearmanr

ROOT = '/home/claude/pp'
SRC = os.environ.get('DRAFT_SRC', f'{ROOT}/draft/work/trial_delta.csv')
S = ['GA', 'PSO', 'SO', 'SA', 'PS', 'PAR']
T = pd.read_csv(SRC)
T['ref'] = T.ref.replace({'PaS': 'PAR'})
T['mzi'] = T['mzi'].replace({'PaS': 'PAR'})
T['ok'] = T.both_valid.astype(bool)
for _c in ('mzi_present', 'ref_present', 'legacy_success', 'ref_valid', 'mzi_valid'):
    T[_c] = T[_c].astype(bool)
N_TRIALS = len(T)
ORDERS = sorted(T.order.unique().tolist())


def Y(s):            # final-run value: no highlight any more
    return s


def C(s):            # slot to fill from the final run, or an item to confirm, cyan
    return '⟪' + s + '⟫'


def pct(x, d=0):
    return f'{100 * x:.{d}f}%'


def kfmt(v, d=0):
    if v is None or not np.isfinite(v):
        return '–'
    if v >= 1e6:
        return f'{v / 1e6:.1f}M'
    if v >= 1e3:
        return f'{v / 1e3:.{d}f}k'
    return f'{v:.0f}'


def mn(x):           # typographic minus for negative numbers
    return f'{x:.1f}'.replace('-', '−')


def grp(r, m):
    return T[(T.ref == r) & (T.mzi == m)]


def succ(g, tau):
    return (g.ok & (g.delta <= 10 ** (tau / 20))).values


def P(r, m, tau=-20):
    return succ(grp(r, m), tau).mean()


def ert(r, m, tau=-20, kind='ev'):
    g = grp(r, m); s = succ(g, tau).sum()
    if not s:
        return np.nan
    return (g.Cev.sum() if kind == 'ev' else g.Tsec.sum()) / s


def legacy(r, m):
    g = grp(r, m)
    ok = (g.ref_exit > 0) & (g.mzi_exit > 0) & g.ok
    k = int(ok.sum())
    if k == 0:
        return dict(k=0, P=0.0, F=0.0)
    Eb = g.E[ok].mean(); Cb = g.Cev[ok].mean()
    return dict(k=k, P=k / len(g), F=(k / len(g)) / (Eb * np.log(Cb)))


def marg_P(col, s, tau=-20):
    g = T[T[col] == s]
    return succ(g, tau).mean()


def flag_share(stage, s):
    col, sol = ('ref_exit', 'ref') if stage == 1 else ('mzi_exit', 'mzi')
    g = T[(T[sol] == s) & T[col].notna()]
    n = len(g)
    return {f: float((g[col] == f).mean()) for f in (1, 0, -1)}, n


def stage_cost(s):
    g1 = T[T.ref == s]
    g2 = T[(T.mzi == s) & T.mzi_present]
    return dict(e1=g1.ref_evals.mean(), t1=g1.ref_seconds.mean(), gap=g1.s1_gap_to_baseline.median(),
                e2=g2.mzi_evals.mean(), t2=g2.mzi_seconds.mean())


# ---- headline counts
PAIR_N = T.groupby(['ref', 'mzi']).size()
N_PER_PAIR = (int(PAIR_N.min()), int(PAIR_N.max()))
PLANNED = 77760
N_NOSTAGE2 = int((~T.ok).sum())
MIN_MARGIN = float((T.E - T.E_bound)[T.ok].min())

# ---- ranking agreement
_pairs = [(r, m) for r in S for m in S]
_tab = pd.DataFrame({'pair': [f'{r}>{m}' for r, m in _pairs],
                     'P20': [P(r, m, -20) for r, m in _pairs],
                     'P25': [P(r, m, -25) for r, m in _pairs],
                     'F': [legacy(r, m)['F'] for r, m in _pairs],
                     'ERTe': [ert(r, m, -20) for r, m in _pairs]})
KT_F_P20 = kendalltau(_tab.F, _tab.P20)[0]
KT_P20_P25 = kendalltau(_tab.P20, _tab.P25)[0]
N_F0 = int((_tab.F == 0).sum())
N_P0 = int((_tab.P20 == 0).sum())
N_P90 = int((_tab.P20 >= 0.9).sum())


def nondominated(df, kind='ev'):
    d = df[df.P20 > 0].copy()
    col = 'ERTe' if kind == 'ev' else 'ERTs'
    keep = []
    for i, a in d.iterrows():
        dom = any((b.P20 >= a.P20) and (b[col] <= a[col]) and ((b.P20 > a.P20) or (b[col] < a[col]))
                  for j, b in d.iterrows() if j != i)
        if not dom:
            keep.append(a.pair)
    return keep


_tab['ERTs'] = [ert(r, m, -20, 's') for r, m in _pairs]
ND_EV = nondominated(_tab, 'ev')
ND_S = nondominated(_tab, 's')

# ---- stage coupling
_v = T[T.ok & T.s1_gap_to_baseline.notna() & T.delta.notna()]
SPEARMAN_ALL = spearmanr(_v.s1_gap_to_baseline, _v.delta)[0]
_v2 = _v[_v.mzi != 'SA']
SPEARMAN_NOSA = spearmanr(_v2.s1_gap_to_baseline, _v2.delta)[0]
MED_DELTA_DB = {(r, m): 20 * np.log10(grp(r, m).delta.median()) for r in S for m in S}
S2COST = T[T.mzi_present].groupby(['mzi', 'ref']).mzi_evals.mean().unstack().loc[S, S]
BEST_DELTA_DB = {int(o): float(20 * np.log10(g.delta.min())) for o, g in T.groupby('order')}
BEST_INST_DB = {(int(o), float(r)): float(20 * np.log10(g.delta.min())) for (o, r), g in T.groupby(['order', 'ratio'])}
FLOOR = pd.read_csv(f'{ROOT}/draft/work/delta_floor.csv')
FLOOR_DB = {(int(a.order), float(a.ratio)): float(a.floor_dB) for a in FLOOR.itertuples()}
FLOOR_UPLO_DB = float((FLOOR.floor_up_dB - FLOOR.floor_dB).max())
T['floor_dB'] = [FLOOR_DB[(int(o), float(r))] for o, r in zip(T.order, T.ratio)]
T['gapfloor_dB'] = T.delta_dB - T.floor_dB
BASE_GAP_MAX = float((T.baseline_upper - T.baseline_lower).max())


def med_delta_by_s1(s, exclude_s2=('SA',)):
    g = T[(T.ref == s) & ~T.mzi.isin(exclude_s2) & T.ok]
    return 20 * np.log10(g.delta.median())


def P_by_order(r, m, tau=-20):
    g = grp(r, m)
    return {int(o): float(succ(gg, tau).mean()) for o, gg in g.groupby('order')}


def med_by_order(r, m):
    g = grp(r, m)
    return {int(o): float(20 * np.log10(gg.delta.median())) for o, gg in g.groupby('order')}


# ---- raw-target overshoot over the full grid (independent of the snapshot)
def overshoot():
    w = np.linspace(0, np.pi, 20001)
    mins, maxs = [], []
    for N in range(4, 13):
        for rho in (0.2, 0.3, 0.4, 0.5):
            k = np.arange(1, N + 1)
            t = np.concatenate([[rho], 2 * rho * np.sinc(rho * k)])
            F = t[0] + sum(t[i] * np.cos(i * w) for i in range(1, N + 1))
            mins.append(F.min()); maxs.append(F.max())
    mins, maxs = np.array(mins), np.array(maxs)
    return dict(min_lo=mins.min(), min_hi=mins.max(), max_lo=maxs.min(), max_hi=maxs.max(),
                n_out=int(np.sum((mins < 0) | (maxs > 1))), n=len(mins))


OVR = overshoot()


# ---- block bootstrap (whole (seed, repeat) blocks; the same blocks are drawn for every pair, which keeps the pairing)
_BLOCK = (T.seed.astype(int) * 1000 + T.trial.astype(int))
_BIDS = np.sort(_BLOCK.unique())
N_BLOCKS = len(_BIDS)
_B = 2000


def _block_sums(g, tau, kind):
    b = _BLOCK.loc[g.index]
    s = pd.Series(succ(g, tau).astype(float), index=g.index)
    c = g.Cev if kind == 'ev' else g.Tsec
    out = pd.DataFrame({'s': s.groupby(b).sum(), 'n': g.groupby(b).size(), 'c': c.groupby(b).sum()})
    return out.reindex(_BIDS).fillna(0.0)


def boot(r, m, tau=-20, stat='P', kind='ev', B=_B, seed=20261103):
    """95% percentile interval and number of dropped replicates (no success) for P or ERT of one pair."""
    d = _block_sums(grp(r, m), tau, kind)
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, N_BLOCKS, size=(B, N_BLOCKS))
    s, n, c = d.s.values[idx].sum(1), d.n.values[idx].sum(1), d.c.values[idx].sum(1)
    if stat == 'P':
        v = s / n
        return float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5)), 0
    with np.errstate(divide='ignore', invalid='ignore'):
        v = np.where(s > 0, c / s, np.nan)
    ok = np.isfinite(v)
    if ok.sum() == 0:
        return np.nan, np.nan, int(B)
    return float(np.percentile(v[ok], 2.5)), float(np.percentile(v[ok], 97.5)), int((~ok).sum())


def boot_diff(a, b, tau=-20, B=_B, seed=20261103):
    """95% interval of P(a) - P(b) for two pairs a=(r,m), b=(r,m), resampling the same blocks."""
    da, db = _block_sums(grp(*a), tau, 'ev'), _block_sums(grp(*b), tau, 'ev')
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, N_BLOCKS, size=(B, N_BLOCKS))
    pa = da.s.values[idx].sum(1) / da.n.values[idx].sum(1)
    pb = db.s.values[idx].sum(1) / db.n.values[idx].sum(1)
    v = pa - pb
    return float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5))


def ci_txt(lo, hi, d=2):
    return f'{lo:.{d}f}\u2013{hi:.{d}f}'


HB_MAX = float(max(T.hb_dc_dev.max(), T.hb_even_dev.max()))
N_RETURNED = int(T.ok.sum())
LEG_SUCC = int(T.legacy_success.sum())

# ---- Stage-1 reproducibility across the six trials that share a (solver, instance, seed, repeat)
_K = ['ref', 'order', 'ratio', 'seed', 'trial']
_g1 = T.groupby(_K).ref_objective
N_S1 = int(_g1.ngroups)
S1_BITWISE = int((_g1.nunique() == 1).sum())
_spread = (_g1.max() - _g1.min())
S1_TOL = int((_spread <= 1e-12).sum())
S1_DIFF = N_S1 - S1_TOL
S1_DIFF_MAX = float(_spread.max())
S1U = T.drop_duplicates(_K)


def start_objective_median(M=20000, seed=7):
    """Median Stage-1 objective of the feasible-start sampler (Python port of generateInitialPoints), per instance."""
    rng = np.random.default_rng(seed); out = {}
    for N in range(4, 13):
        for rho in (0.2, 0.3, 0.4, 0.5):
            k = np.arange(1, N + 1); t = np.concatenate([[rho], 2 * rho * np.sinc(rho * k)])
            dc = rng.random((M, 1)); w = -np.log(rng.random((M, N))); w /= w.sum(1, keepdims=True)
            sg = 2 * (rng.random((M, N)) >= 0.5) - 1
            rad = np.minimum(dc, 1 - dc) * rng.random((M, 1)) ** (1 / N)
            x = np.hstack([dc, rad * w * sg])
            out[(N, rho)] = float(np.median(np.linalg.norm(x - t, axis=1) / np.linalg.norm(t)))
    return out


START = start_objective_median()
START_MED = float(np.median(list(START.values())))
S1_OBJ_MED = {s: float(S1U[S1U.ref == s].ref_objective.median()) for s in S}
S1_EV_MED = {s: float(S1U[S1U.ref == s].ref_evals.median()) for s in S}
S1_EV_MIN = {s: float(S1U[S1U.ref == s].ref_evals.min()) for s in S}
SO_S1_LE230 = float((S1U[S1U.ref == 'SO'].ref_evals <= 230).mean())
WORKER_HOURS = float(T.record_elapsed_seconds.sum() / 3600)
RECOMP_MAX = float((T.E - T.E_saved).abs().max())
MIN_S1_GAP = float(T.s1_gap_to_baseline.min())
MIN_FLOOR_GAP = float(T.gapfloor_dB.min())
BEST_GAPFLOOR = {k: BEST_INST_DB[k] - FLOOR_DB[k] for k in FLOOR_DB}

if __name__ == '__main__':
    print(N_TRIALS, N_PER_PAIR, PLANNED, N_NOSTAGE2, MIN_MARGIN)
    print(S1_BITWISE, S1_TOL, S1_DIFF, S1_DIFF_MAX, START_MED, S1_OBJ_MED, S1_EV_MED, S1_EV_MIN, SO_S1_LE230, WORKER_HOURS, RECOMP_MAX, MIN_S1_GAP, MIN_FLOOR_GAP, FLOOR_UPLO_DB)
    print('KT', KT_F_P20, KT_P20_P25, 'F0', N_F0, 'P0', N_P0, 'P90', N_P90)
    print('ND', ND_EV, ND_S)
    print('spearman', SPEARMAN_ALL, SPEARMAN_NOSA)
    print(OVR, BASE_GAP_MAX)
    print({s: flag_share(1, s) for s in S})
    print({s: stage_cost(s) for s in S})
