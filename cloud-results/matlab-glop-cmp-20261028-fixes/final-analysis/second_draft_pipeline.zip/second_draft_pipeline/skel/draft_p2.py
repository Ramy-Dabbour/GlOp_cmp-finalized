# Partial draft, part 2: III. Optimization algorithms, IV. Experimental methodology.
import json
import lib, dlib
from lib import para, rich, run, h1, h2, note
from dlib import cite, eq, eqref, tabref, figref
import draft_data as D
from draft_data import Y, C

OM = json.load(open('/home/claude/pp/skel/eq/omml_all.json'))


def B(t):
    return para('BodyText', rich(t))


def sci(x, d=0):
    import numpy as np
    e = int(np.floor(np.log10(abs(x))))
    m = x / 10 ** e
    if float(f'{m:.{d}f}') >= 10:
        m /= 10; e += 1
    return f'{m:.{d}f}\u00d710^\u2212{abs(e)}^' if e < 0 else f'{m:.{d}f}\u00d710^{e}^'


def build_p2():
    b = []
    add = b.append
    T = D.T

    # ================================================================ III. Optimization algorithms
    add(h1('Optimization Algorithms'))
    add(B('We compare six derivative-free solvers from MATLAB’s Global Optimization Toolbox ' + cite('mw') +
          '. Each treats the objective as a black box on box-bounded variables, which suits Stage 1, where the penalty plateau makes the objective nonsmooth. '
          'The solvers differ in four ways: the state the search carries, whether it uses randomness, how it uses objective values, and what the plateau does to it. '
          'Three methods keep a population (genetic algorithm, particle swarm and Pareto search), two follow a single trajectory (simulated annealing and pattern search), '
          'and one fits a model of the objective (surrogate optimization). ' + tabref('solvers') + ' lists the settings. '
          'Each paragraph below ends with a hypothesis that Section V tests. We wrote the hypotheses after inspecting diagnostics from a 4,947-trial snapshot of an earlier run (one passband ratio, one seed, orders 4 to 10), so they are exploratory; '
          'the full run reported here was started afresh and imports none of those trials.'))

    add(B('**Genetic algorithm (GA).** A GA evolves a population by selection, crossover and mutation ' + cite('hol', 'gol') +
          '. We use the toolbox defaults: stochastic-uniform selection, rank scaling, scattered crossover with probability 0.8, adaptive-feasible mutation and 5% elitism. '
          'It learns only the rank of each candidate. In Stage 1 all infeasible children receive the same penalty, so selection cannot discriminate among them. '
          'In Stage 2, coordinate-wise crossover can place a child far from both parents, because the angles are periodic. '
          '**H1:** GA uses at least ten times as many evaluations per stage as either single-trajectory method.'))
    add(B('**Particle swarm (PSO).** Each particle moves by ⟨v⟩ ← ⟨W⟩⟨v⟩ + ⟨y⟩~1~⟨u⟩~1~∘(⟨p⟩ − ⟨x⟩) + ⟨y⟩~2~⟨u⟩~2~∘(⟨g⟩ − ⟨x⟩), '
          'where ⟨p⟩ is its own best position, ⟨g⟩ the best position in a random neighborhood of the swarm, ⟨u⟩~1~ and ⟨u⟩~2~ are random vectors, and the inertia ⟨W⟩ adapts during the run ' + cite('ke', 'mw') +
          '. Once the swarm is seeded feasibly, ⟨p⟩ and ⟨g⟩ remain feasible, so a feasible attractor persists even when most proposed moves land on the plateau. '
          '**H2:** PSO reaches a success fraction of at least 0.9 at the −20 dB tolerance as a Stage-1 solver (with every Stage-2 solver but SA) and as a Stage-2 solver (after GA or PSO), '
          'at more than 10^5^ evaluations per stage.'))
    add(B('**Surrogate optimization (SO).** SO fits a cubic radial-basis surrogate with a linear tail to all evaluated points. '
          'The next point minimizes a weighted sum of the surrogate value and the distance to evaluated points, with the weight cycling through 0.3, 0.5, 0.8 and 0.95 ' + cite('gu', 'rs', 'mw') +
          '. It uses every evaluation, so it needs few. The documentation does not say how extreme values enter the fit, so the largest-double penalty may distort the surrogate. '
          'Stage 2 is smooth and unconstrained. Our stall rule, which stops after 200 evaluations without improvement, confounds any Stage-1 failure. '
          '**H3:** SO uses fewer than 10^3^ evaluations per stage, reaches a success fraction of at least 0.9 as a Stage-2 solver (after GA or PSO), and below 0.05 as a Stage-1 solver.'))
    add(B('**Simulated annealing (SA).** SA follows one trajectory. It accepts a worse point with probability 1/(1 + exp(Δ/⟨T⟩)), where Δ is the increase in the objective and the temperature falls as ⟨T⟩~0~0.95^⟨k⟩^; '
          'steps scale with ⟨T⟩, and the run re-anneals periodically ' + cite('kgv', 'ing', 'mw') +
          '. A move onto the plateau has an enormous Δ and is almost never accepted, so a walk that starts feasible stays feasible. '
          'Our stall window of 60 iterations is shorter than the roughly 90 iterations needed for ⟨T⟩ to fall a hundredfold, so a run may stop while the temperature is still high and the walk has barely moved. '
          '**H4:** SA stops on its stall tolerance in nearly every run, after fewer than 200 evaluations per stage, and is the worst Stage-2 solver.'))
    add(B('**Pattern search (PS).** PS polls a fixed stencil of points around the incumbent, moves to an improving point and otherwise shrinks the mesh ' + cite('hj', 'ad') +
          '. With opportunistic polling it moves as soon as it finds an improvement. It is deterministic given its start. '
          'At the feasible boundary of Stage 1 the mesh contracts, which acts as a hard wall; at Stage 2 the method is local, so on a periodic landscape its result is a property of the starting basin. '
          '**H5:** PS has the lowest cost per success among the pairs with a success fraction of at least 0.5, but as a Stage-2 solver its success at −25 dB is below that of GA and PSO.'))
    add(B('**Pareto search (PAR).** PAR is built for several objectives. It keeps a set of non-dominated points and polls around each ' + cite('cu') +
          '. With one objective the set collapses to the best point and its ties, so the method acts as a pattern search seeded with a population. '
          'The documented volume-based stopping test is evaluated only when the non-dominated set has more members than there are objectives ' + cite('mw') +
          ', so we expect it never to fire and the run to end at its budget. We take the best member of the returned set. '
          '**H6:** PAR exhausts its 20,000-evaluation budget in every run, and is costlier and less accurate than PS at both stages.'))

    rows = [
        ['GA', 'population', 'max(80, 20⟨n⟩)', 'MaxGenerations 2000 (S1), 200 (S2); stall 60 generations; tolerance 10^−10^'],
        ['PSO', 'population', 'max(100, 20⟨n⟩)', 'MaxIterations 2000; stall 60 iterations; tolerance 10^−10^'],
        ['SO', 'surrogate', 'max(20, 2⟨n⟩) initial points', '4,000 evaluations; 400 s; ObjectiveLimit 10^−10^; stop after 200 evaluations without improvement'],
        ['SA', 'single point', '1', 'MaxIterations 2000; stall 60 iterations; 20,000 evaluations; re-anneal every 100 accepted points; tolerance 10^−10^'],
        ['PS', 'single point', '1', 'MaxIterations 200; opportunistic poll and search; tolerance 10^−10^; mesh tolerance 10^−6^ (default)'],
        ['PAR', 'population', 'max(100, 20⟨n⟩)', '20,000 evaluations; 400 iterations; 400 s; mesh tolerance 10^−6^; minimum poll fraction 0; constraint tolerance 10^−10^'],
    ]
    add(dlib.table('solvers', 'Solvers and settings. n is the number of variables (N + 1 in Stage 1, N + 2 in Stage 2). '
                   'S1 and S2 denote the stages. Every method starts from a common point (see Section IV-B).',
                   [600, 880, 960, 2426], ['Solver', 'State', 'Population', 'Stopping settings'], rows, row_h=200,
                   col_jc=['left', 'left', 'left', 'left']))

    # ================================================================ IV. Experimental methodology
    add(h1('Experimental Methodology'))
    add(h2('Design and Replication'))
    add(B('The factors are the Stage-1 solver (6 levels), the Stage-2 solver (6), the target order ⟨N⟩ ∈ {4, …, 12} (9), the passband ratio ⟨ρ⟩ ∈ {0.2, 0.3, 0.4, 0.5} (4), '
          'the seed ∈ {0, 1, 2} (3) and 20 repeats. The full factorial has 77,760 trials, 2,160 per pair. '
          'The target depends only on (⟨N⟩, ⟨ρ⟩), so all randomness comes from the solvers and their starting points. '
          'We use the MRG32k3a generator ' + cite('le') + ' with the seed selecting the stream and the substream index 2(⟨r⟩ − 1) + ⟨stage⟩ for repeat ⟨r⟩. '
          'Substreams of one stream do not overlap by construction, whereas separately seeded streams carry no such guarantee. '
          'Because the substream depends only on (seed, repeat, stage), every solver pair draws from the same substream at the same stage, and the Stage-2 stream does not depend on the Stage-1 solver. '
          'The comparison is therefore paired.'))
    add(B('Each trial solves both stages. The six trials that differ only in the Stage-2 solver therefore repeat the same Stage-1 problem from the same substream, '
          'so the 77,760 trials contain only 12,960 distinct Stage-1 configurations (6 solvers × 36 instances × 60 seed–repeat labels). '
          f'The repeated solves agree: the Stage-1 objective value is bitwise identical across the six trials in {D.S1_BITWISE:,} configurations, equal to within 10^−12^ in {D.S1_TOL - D.S1_BITWISE} more, '
          f'and different in {D.S1_DIFF}, by at most {sci(D.S1_DIFF_MAX, 0)}; in each of those three, the deviating trial ran immediately before or after the interruption of the job (Section V-A), and we did not identify the cause. '
          'The trials are thus paired and clustered, not 77,760 independent problems, and the effective sample size is set by the number of distinct Stage-1 configurations.'))

    add(h2('Initialization and Solver Settings'))
    add(B('Stage 1 starts from one point drawn as in Section II-B. Population methods receive it as their first member, with feasible samples for the rest, and single-point methods use it directly. '
          'Stage 2 starts uniformly in [0, 1)^⟨N⟩+2^. The start is therefore feasible by construction, but later candidates are not certified. '
          + f'All {D.N_TRIALS:,} Stage-1 references were valid, so validity does not discriminate between solvers.' +
          ' We measure how close each method gets, not whether it gets there.'))
    add(B('The budgets in ' + tabref('solvers') + ' are native and unequal on purpose: each solver stops by its own rule under an iteration or evaluation cap, as a practitioner would run it. '
          'A comparison at equal budget answers a different question, which we leave to future work. All solvers run serially inside a trial, and the parallelism is across trials, which keeps evaluation counts comparable.'))

    add(h2('Outcome Measures'))
    add(B('Four events are distinct: the solver returned a design, the design is valid, the solver met its own convergence test, and the achieved error is acceptable. '
          'They need not coincide, because a run that exhausts its budget can return an excellent design and one that stalls can return a poor one. '
          'We score the last event with δ from ' + eqref('delta') + '. A trial **succeeds at tolerance τ** (in dB) when both stages return valid designs and δ ≤ 10^τ/20^. '
          'The tolerances form a ladder from −20 to −60 dB in 5 dB steps, fixed before the full run was launched, with every second rung (−20, −30, −40, −50 and −60 dB) intended for the main table. '
          'Only the range and spacing were informed by the snapshot, in which the best δ found for any instance was between −26 and −31 dB. '
          'The ladder turned out to be too deep: no trial of the full run reaches −35 dB, and the passivity floor of Section II-D, computed afterwards, rules out −40 dB and below. '
          'We keep the ladder as fixed, report the rungs that some pair reaches (−20, −25 and −30 dB), and give the best δ per instance beside the floor. '
          'For pair (⟨i⟩, ⟨j⟩) with ⟨n⟩ trials, the success fraction and the expected cost per success are'))
    add(eq('P', OM['P']))
    add(eq('ERT', OM['ERT']))
    add(B('where ⟨s⟩~ij~(τ) is the number of successes and ⟨C⟩~t~^(1)^ + ⟨C⟩~t~^(2)^ is the evaluation count of trial ⟨t⟩ over both stages. '
          'The numerator sums over all ⟨n⟩ trials, failures included, and the ratio is infinite when there is no success. '
          'It follows the expected running time of the COCO platform ' + cite('coco') + '. We also report it in seconds. '
          'Every trial returned a Stage-2 result, so the evaluation counts are complete.'))
    add(B('For continuity with our earlier analysis we also compute a **legacy index**,'))
    add(eq('legacy', OM['legacy']))
    add(B('where success requires both exit flags to be positive and both outputs to be valid, ⟨P⟩ is the fraction of such successes in all trials, and the mean error and the mean total evaluations are taken over the successes only. '
          'Pairs without a success score 0. The index rewards pipelines that fail rarely, err little and stop early, but both means are conditional on success, and a flag reports only that the solver’s own rule fired, '
          'so it ranks stopping rules as much as designs. We keep it for audit and label it legacy.'))

    add(h2('Statistical Treatment'))
    add(B('The unit of analysis is one trial. Trials in the same (seed, repeat) block share random numbers and trials of one instance share a target, so they are not independent. '
          'Intervals are 95% percentile intervals from a block bootstrap that resamples whole (seed, repeat) blocks and applies the same resample to every pair, which preserves the pairing: ' +
          f'{D.N_BLOCKS} blocks, 2,000 replicates. '
          'A replicate without a success has no expected cost, so we report how many were dropped. We measure rank agreement by Kendall’s τ. '
          'The intervals describe variation over seeds and repeats on the fixed set of 36 instances and do not generalize over instances. '
          'With 36 pairs we report differences with intervals and make no unadjusted significance claims. We pool over ⟨N⟩ and ⟨ρ⟩ and show per-order results where they differ.'))

    add(h2('Implementation and Validation'))
    add(B('The study ran in MATLAB with the Global Optimization Toolbox and the Parallel Computing Toolbox ' + C('(release of the cloud image; R2026a on the development machine)') +
          ' on four cloud virtual machines with eight virtual CPUs and 32 GB of memory each (Google Compute Engine e2-standard-8). Each machine ran a process-based pool of eight single-threaded workers, one trial per worker task, 32 trials at a time. '
          f'The trials consumed {D.WORKER_HOURS:,.0f} worker-hours, about {D.WORKER_HOURS / 32 / 24:.0f} days of computing on the 32 workers, between 28 October and 12 November 2026; the job stopped once, from 31 October to 3 November, and resumed from its checkpoints. '
          'Each trial draws from its own deterministic substreams, so scheduling cannot change the random numbers. Outputs can still differ with load when the 400 s limits bind, so we do not claim bitwise invariance. '
          'Seconds are measured with eight workers sharing eight virtual CPUs and are not isolated timings. '
          'Each trial is committed atomically on completion, with a hash of the source files and of the configuration, so that a resumed run cannot mix outputs from different code. '
          'The run reported here differs from the code that produced the snapshot in two guards: a failed write of progress telemetry no longer ends a trial, and a failed eigenvalue solve in the Stage-2 response check marks the candidate as penalized instead of ending the trial. '
          + C('Repository or archive link and commit hash.')))
    add(B('We report only checks that we ran, all on the stored results of the 77,760 trials. '
          f'The end-to-end error recomputed in Python from each stored coefficient matrix equals the value saved by the MATLAB program to within {sci(D.RECOMP_MAX)}. '
          f'Every end-to-end error is at least its half-band bound (smallest margin {sci(D.MIN_MARGIN, 1)}), every δ is above its passivity floor (smallest margin {D.MIN_FLOOR_GAP:.1f} dB), and the half-band identity holds on every stored matrix to {sci(D.HB_MAX)}. '
          f'No Stage-1 objective value is below the convex lower bound (smallest gap {sci(D.MIN_S1_GAP, 1)}). '
          f'The legacy successes rebuilt from the per-trial exit flags number {D.LEG_SUCC:,}, the count in the exported summary, and the trial parameters, errors and evaluation counts of the per-trial records match the exported table in every trial. '
          'The identities of Section II (half-band structure, unitarity and the decomposition of ⟨E⟩) also hold to 4×10^−16^ on 12 random designs with an independent Python implementation of the lattice. '
          'We did not test admissibility against a dense frequency grid, and we did not rerun trials to test reproducibility beyond the repeated Stage-1 solves of Section IV-A.'))
    return ''.join(b)
