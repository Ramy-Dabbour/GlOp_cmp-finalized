import re, shutil, os, sys, zipfile, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import importlib, content, lib
importlib.reload(lib); importlib.reload(content)

SRC = '/home/claude/pp/tpl/un'
WORK = '/home/claude/pp/skel/work'

def build(out_path, notes):
    lib._seq['eq'] = 0; lib._sdt_id[0] = 5000
    if os.path.exists(WORK): shutil.rmtree(WORK)
    shutil.copytree(SRC, WORK, symlinks=False)
    doc = open(f'{SRC}/word/document.xml', encoding='utf8').read()
    head = doc[:doc.index('<w:body>') + len('<w:body>')]
    paras = re.findall(r'<w:p[ >].*?</w:p>', doc, re.S)
    p3 = paras[3]                                   # carries the title-section sectPr
    assert '<w:sectPr' in p3
    # section 2: the author block, one column
    s2 = ('<w:p><w:pPr><w:sectPr><w:type w:val="continuous"/><w:pgSz w:w="11906" w:h="16838" w:code="9"/>'
          '<w:pgMar w:top="450" w:right="893" w:bottom="1440" w:left="893" w:header="720" w:footer="720" w:gutter="0"/>'
          '<w:cols w:space="720"/><w:docGrid w:linePitch="360"/></w:sectPr></w:pPr></w:p>')
    final_sect = ('<w:sectPr><w:type w:val="continuous"/><w:pgSz w:w="11906" w:h="16838" w:code="9"/>'
                  '<w:pgMar w:top="1080" w:right="907" w:bottom="1440" w:left="907" w:header="720" w:footer="720" w:gutter="0"/>'
                  '<w:cols w:num="2" w:space="360"/><w:docGrid w:linePitch="360"/></w:sectPr>')
    title, author, body = content.build_body(notes)
    xml = head + title + p3 + author + s2 + body + final_sect + '</w:body></w:document>'
    open(f'{WORK}/word/document.xml', 'w', encoding='utf8').write(xml)

    # styles
    st = open(f'{WORK}/word/styles.xml', encoding='utf8').read()
    n = open(f'{WORK}/word/numbering.xml', encoding='utf8').read()
    abs_ids = [int(x) for x in re.findall(r'<w:abstractNum w:abstractNumId="(\d+)"', n)]
    num_ids = [int(x) for x in re.findall(r'<w:num w:numId="(\d+)"', n)]
    a_new, n_new = max(abs_ids) + 1, max(num_ids) + 1
    absnum = (f'<w:abstractNum w:abstractNumId="{a_new}"><w:multiLevelType w:val="singleLevel"/>'
              '<w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="bullet"/><w:pStyle w:val="SkelBullet"/>'
              '<w:lvlText w:val="•"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="240" w:hanging="140"/></w:pPr>'
              '<w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial" w:hint="default"/></w:rPr></w:lvl></w:abstractNum>')
    first_num = n.index('<w:num ')
    n = n[:first_num] + absnum + n[first_num:]
    n = n.replace('</w:numbering>', f'<w:num w:numId="{n_new}"><w:abstractNumId w:val="{a_new}"/></w:num></w:numbering>')
    open(f'{WORK}/word/numbering.xml', 'w', encoding='utf8').write(n)

    ARIAL = '<w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/>'
    styles = (
        '<w:style w:type="paragraph" w:customStyle="1" w:styleId="SkelLabel"><w:name w:val="Skeleton note label"/>'
        '<w:basedOn w:val="Normal"/><w:next w:val="SkelBullet"/><w:pPr><w:keepNext/>'
        '<w:shd w:val="clear" w:color="auto" w:fill="DCE6F1"/><w:spacing w:before="100" w:after="0" w:line="216" w:lineRule="auto"/>'
        '<w:ind w:left="100" w:right="60"/><w:jc w:val="left"/></w:pPr>'
        f'<w:rPr>{ARIAL}<w:b/><w:bCs/><w:color w:val="1F3864"/><w:sz w:val="15"/><w:szCs w:val="15"/></w:rPr></w:style>'
        '<w:style w:type="paragraph" w:customStyle="1" w:styleId="SkelBullet"><w:name w:val="Skeleton note bullet"/>'
        '<w:basedOn w:val="Normal"/><w:pPr>'
        f'<w:numPr><w:numId w:val="{n_new}"/></w:numPr>'
        '<w:shd w:val="clear" w:color="auto" w:fill="EAF0F8"/><w:spacing w:before="0" w:after="0" w:line="216" w:lineRule="auto"/>'
        '<w:ind w:left="240" w:right="60" w:hanging="140"/><w:jc w:val="left"/></w:pPr>'
        f'<w:rPr>{ARIAL}<w:color w:val="1B2A41"/><w:sz w:val="15"/><w:szCs w:val="15"/></w:rPr></w:style>'
        '<w:style w:type="paragraph" w:customStyle="1" w:styleId="SkelNote"><w:name w:val="Skeleton note text"/>'
        '<w:basedOn w:val="Normal"/><w:pPr><w:shd w:val="clear" w:color="auto" w:fill="EAF0F8"/>'
        '<w:spacing w:before="0" w:after="0" w:line="216" w:lineRule="auto"/><w:ind w:left="100" w:right="60"/><w:jc w:val="left"/></w:pPr>'
        f'<w:rPr>{ARIAL}<w:color w:val="1B2A41"/><w:sz w:val="15"/><w:szCs w:val="15"/></w:rPr></w:style>'
        '<w:style w:type="character" w:styleId="PlaceholderText"><w:name w:val="Placeholder Text"/>'
        '<w:basedOn w:val="DefaultParagraphFont"/><w:uiPriority w:val="99"/><w:semiHidden/>'
        '<w:rPr><w:i/><w:iCs/><w:color w:val="8A8A8A"/></w:rPr></w:style>')
    st = st.replace('</w:styles>', styles + '</w:styles>')
    open(f'{WORK}/word/styles.xml', 'w', encoding='utf8').write(st)

    # metadata
    core = open(f'{WORK}/docProps/core.xml', encoding='utf8').read()
    core = re.sub(r'<dc:title>.*?</dc:title>', f'<dc:title>{lib.esc(content.TITLE)}</dc:title>', core)
    core = re.sub(r'<dc:creator>.*?</dc:creator>', '<dc:creator>Ramy Dabbour</dc:creator>', core)
    core = re.sub(r'<cp:lastModifiedBy>.*?</cp:lastModifiedBy>', '<cp:lastModifiedBy>Claude</cp:lastModifiedBy>', core)
    open(f'{WORK}/docProps/core.xml', 'w', encoding='utf8').write(core)

    if os.path.exists(out_path): os.remove(out_path)
    subprocess.run(f'cd {WORK} && zip -Xr "{out_path}" "[Content_Types].xml" _rels docProps word customXml', shell=True, check=True, stdout=subprocess.DEVNULL)

if __name__ == '__main__':
    out = sys.argv[1]; notes = sys.argv[2] == 'notes'
    build(out, notes); print('built', out, os.path.getsize(out))
