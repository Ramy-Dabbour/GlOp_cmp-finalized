# LaTeX -> OMML for the equations the draft adds; merged with the ten already in eq/omml.json.
import json, re, subprocess, os, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
NEW = {
 'stagemat': r"\mathbf{S}_k(z)=\begin{bmatrix}a_k c_k z^{-d_k} & \mathrm{j}\,s_k\\ \mathrm{j}\,a_k s_k z^{-d_k} & c_k\end{bmatrix}",
 'cascade': r"\mathbf{S}(z)=\mathbf{S}_1(z)\,\mathbf{S}_2(z)\cdots\mathbf{S}_K(z)\,\mathbf{C}",
 'target': r"t_0=\rho,\qquad t_k=2\rho\,\mathrm{sinc}(\rho k),\quad k=1,\dots,N",
 'J2': r"J_2(\boldsymbol{\theta},\varphi)=\frac{\lVert \mathbf{G}(\boldsymbol{\theta},\varphi)-\mathbf{R}(\mathbf{x}^{*})\rVert_F}{\lVert \mathbf{R}(\mathbf{x}^{*})\rVert_F}",
 'E': r"E(\boldsymbol{\theta},\varphi)=\frac{\lVert \mathbf{G}(\boldsymbol{\theta},\varphi)-\mathbf{R}(\mathbf{t})\rVert_F}{\lVert \mathbf{R}(\mathbf{t})\rVert_F}",
}

def convert(eqs):
    d = tempfile.mkdtemp()
    md = '\n\n'.join(f'$${v}$$' for v in eqs.values())
    open(f'{d}/e.md', 'w', encoding='utf8').write(md)
    subprocess.run(['pandoc', f'{d}/e.md', '-o', f'{d}/e.docx'], check=True)
    subprocess.run(['unzip', '-o', '-q', f'{d}/e.docx', '-d', f'{d}/u'], check=True)
    x = open(f'{d}/u/word/document.xml', encoding='utf8').read()
    ms = re.findall(r'<m:oMath>.*?</m:oMath>', x, re.S)
    assert len(ms) == len(eqs), (len(ms), len(eqs))
    out = {}
    for k, m in zip(eqs, ms):
        m = re.sub(r'<m:t>(\s+)</m:t>', r'<m:t xml:space="preserve">\1</m:t>', m)
        out[k] = m
    return out


def _reorder(m):
    """Schema order: m:dPr = begChr, sepChr, endChr, grow, shp, ctrlPr; m:mcPr = count, mcJc."""
    def dpr(mo):
        body = mo.group(1)
        parts = {}
        for name in ('begChr', 'sepChr', 'endChr', 'grow', 'shp'):
            f = re.search(r'<m:%s\b[^>]*/>' % name, body)
            if f:
                parts[name] = f.group(0)
        ctrl = re.search(r'<m:ctrlPr>.*?</m:ctrlPr>', body, re.S)
        out = ''.join(parts[n] for n in ('begChr', 'sepChr', 'endChr', 'grow', 'shp') if n in parts)
        return '<m:dPr>' + out + (ctrl.group(0) if ctrl else '') + '</m:dPr>'
    m = re.sub(r'<m:dPr>(.*?)</m:dPr>', dpr, m, flags=re.S)

    def mcpr(mo):
        body = mo.group(1)
        c = re.search(r'<m:count\b[^>]*/>', body)
        j = re.search(r'<m:mcJc\b[^>]*/>', body)
        return '<m:mcPr>' + (c.group(0) if c else '') + (j.group(0) if j else '') + '</m:mcPr>'
    return re.sub(r'<m:mcPr>(.*?)</m:mcPr>', mcpr, m, flags=re.S)

if __name__ == '__main__':
    old = json.load(open(f'{HERE}/eq/omml.json'))
    old = {k: re.sub(r'<m:t>(\s+)</m:t>', r'<m:t xml:space="preserve">\1</m:t>', v) for k, v in old.items()}
    new = convert(NEW)
    allq = {k: _reorder(v) for k, v in {**old, **new}.items()}
    json.dump(allq, open(f'{HERE}/eq/omml_all.json', 'w'), ensure_ascii=False)
    print({k: len(v) for k, v in allq.items()})
