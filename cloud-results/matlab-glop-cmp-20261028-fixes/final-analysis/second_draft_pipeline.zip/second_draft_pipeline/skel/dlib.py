# Draft-mode helpers: cross-reference registries (two-pass), citations, inline figures.
import os, re
import lib
from lib import run, rich, para, esc, COL_W

ROOT = '/home/claude/pp'
FIGDIR = f'{ROOT}/draft/figs'

# ---------------------------------------------------------------- registries (filled on pass 1, read on pass 2)
PREV = {'eq': {}, 'tab': {}, 'fig': {}}
CUR = {'eq': {}, 'tab': {}, 'fig': {}}
CITE_ORDER = []
IMAGES = []                 # (rId, filename) pairs for the assembler
_cnt = {'tab': 0, 'fig': 0, 'img': 0}


def reset():
    global CUR, CITE_ORDER, IMAGES
    CUR = {'eq': {}, 'tab': {}, 'fig': {}}
    CITE_ORDER = []
    IMAGES = []
    _cnt.update({'tab': 0, 'fig': 0, 'img': 0})


def commit():
    """After pass 1: the numbers found become the numbers pass 2 refers to."""
    PREV['eq'], PREV['tab'], PREV['fig'] = dict(CUR['eq']), dict(CUR['tab']), dict(CUR['fig'])


def roman(n):
    vals = [(10, 'X'), (9, 'IX'), (5, 'V'), (4, 'IV'), (1, 'I')]
    out = ''
    for v, s in vals:
        while n >= v:
            out += s; n -= v
    return out


# ---------------------------------------------------------------- equations, tables, figures
def eq(label, omml):
    CUR['eq'][label] = lib._seq['eq'] + 1
    return lib.equation(omml)


def eqref(label):
    n = PREV['eq'].get(label)
    return f'({n})' if n else '(?)'


def eqrefs(*labels):
    ns = [PREV['eq'].get(l) for l in labels]
    return '(' + '), ('.join(str(n) if n else '?' for n in ns) + ')'


def tabref(label):
    n = PREV['tab'].get(label)
    return f'Table {roman(n)}' if n else 'Table ?'


def figref(label):
    n = PREV['fig'].get(label)
    return f'Fig. {n}' if n else 'Fig. ?'


def table(label, caption, widths, header, rows, **kw):
    _cnt['tab'] += 1
    CUR['tab'][label] = _cnt['tab']
    return lib.table(caption, widths, header, rows, **kw)


def image_par(filename, width_in, height_in, descr):
    """Inline picture in a centred paragraph. The assembler copies FIGDIR/filename into word/media."""
    _cnt['img'] += 1
    k = _cnt['img']
    if height_in is None:                       # keep the picture's aspect ratio
        from PIL import Image
        with Image.open(f'{FIGDIR}/{filename}') as im:
            height_in = width_in * im.size[1] / im.size[0]
    rid = f'rIdImg{k}'
    IMAGES.append((rid, filename))
    cx, cy = int(width_in * 914400), int(height_in * 914400)
    d = (f'<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="{cx}" cy="{cy}"/>'
         f'<wp:docPr id="{900 + k}" name="Picture {k}" descr="{esc(descr)}"/>'
         '<wp:cNvGraphicFramePr><a:graphicFrameLocks xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" noChangeAspect="1"/></wp:cNvGraphicFramePr>'
         '<a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
         '<a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
         '<pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">'
         f'<pic:nvPicPr><pic:cNvPr id="{900 + k}" name="{esc(filename)}"/><pic:cNvPicPr/></pic:nvPicPr>'
         f'<pic:blipFill><a:blip r:embed="{rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
         f'<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm>'
         '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic>'
         '</wp:inline></w:drawing></w:r>')
    return para('Normal', d, '<w:keepNext/><w:spacing w:before="60" w:after="40"/><w:jc w:val="center"/>')


def figure(label, filename, width_in, height_in, caption, descr):
    _cnt['fig'] += 1
    CUR['fig'][label] = _cnt['fig']
    return image_par(filename, width_in, height_in, descr) + para('figurecaption', rich(caption))


# ---------------------------------------------------------------- citations in order of first use
REFS = {}          # key -> (text, is_candidate)


def cite(*keys):
    for k in keys:
        if k not in REFS:
            raise KeyError(k)
        if k not in CITE_ORDER:
            CITE_ORDER.append(k)
    nums = sorted(CITE_ORDER.index(k) + 1 for k in keys)
    groups, cur = [], [nums[0]]
    for n in nums[1:]:
        if n == cur[-1] + 1:
            cur.append(n)
        else:
            groups.append(cur); cur = [n]
    groups.append(cur)
    parts = []
    for g in groups:
        if len(g) >= 3:
            parts.append(f'[{g[0]}]–[{g[-1]}]')
        else:
            parts += [f'[{n}]' for n in g]
    return ', '.join(parts)


def reference_list():
    out = ''
    for k in CITE_ORDER:
        text, cand = REFS[k]
        inner = run(text)
        if cand:
            inner += run(' [verify]', hl='cyan')
        out += para('references', inner)
    return out
