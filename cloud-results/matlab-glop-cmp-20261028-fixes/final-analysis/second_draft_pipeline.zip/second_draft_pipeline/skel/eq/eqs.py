EQ = {
 'bound': r"E \ge E_{\mathrm{topology}}=\sqrt{\frac{4\,(1/2-\rho)^2+2\sum_{k\ \mathrm{even},\,k\le N}t_k^2}{D}}",
 'D': r"D=2\Big[\rho^2+(1-\rho)^2+\sum_{k=1}^{N}t_k^2\Big]",
 'decomp': r"E^2=E_{\mathrm{topology}}^2+\frac{8}{D}\sum_{k\le 2N+1,\ k\ \mathrm{odd}}\left|g_k-\tfrac{t_k}{2}\right|^2",
 'delta': r"\delta=\sqrt{E^2-E_{\mathrm{topology}}^2},\qquad \delta_{\mathrm{dB}}=20\log_{10}\delta",
 'stage1': r"\min_{x}\ \frac{\lVert x-t\rVert_2}{\lVert t\rVert_2}\quad\text{s.t.}\quad 0\le F(\omega;x)\le 1\ \ \forall\,\omega\in[0,\pi]",
 'F': r"F(\omega;x)=x_0+\sum_{k=1}^{N}x_k\cos(k\omega)",
 'P': r"P_{ij}(\tau)=\frac{s_{ij}(\tau)}{n}",
 'ERT': r"\mathrm{ERT}_{ij}(\tau)=\frac{\sum_{t=1}^{n}\bigl(C_t^{(1)}+C_t^{(2)}\bigr)}{s_{ij}(\tau)}",
 'legacy': r"\mathcal{F}_{ij}=\frac{P_{ij}}{\bar{E}_{ij}\,\ln \bar{C}_{ij}}",
 'legacy2': r"\bar{E}_{ij}=\frac{1}{s_{ij}}\sum_{t\in\mathcal{S}_{ij}}E_t,\qquad \bar{C}_{ij}=\frac{1}{s_{ij}}\sum_{t\in\mathcal{S}_{ij}}\bigl(C_t^{(1)}+C_t^{(2)}\bigr)",
}
