# Builds the partial-draft .docx from the IEEE template: two passes (cross-references), embedded figures.
import re, shutil, os, sys, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import importlib
import lib, dlib, draft_refs, draft_p1, draft_p2, draft_p3

SRC = '/home/claude/pp/tpl/un'
WORK = '/home/claude/pp/skel/work_draft'
FIGS = dlib.FIGDIR


def build_pass():
    lib._seq['eq'] = 0
    lib._sdt_id[0] = 5000
    title, author = draft_p1.build_front()
    body = draft_p1.build_p1() + draft_p2.build_p2() + draft_p3.build_p3()
    return title, author, body


def build(out_path):
    dlib.reset(); build_pass()          # pass 1: collect equation, table, figure and citation numbers
    dlib.commit(); dlib.reset()
    title, author, body = build_pass()  # pass 2: references now resolve

    if os.path.exists(WORK):
        shutil.rmtree(WORK)
    shutil.copytree(SRC, WORK, symlinks=False)
    doc = open(f'{SRC}/word/document.xml', encoding='utf8').read()
    head = doc[:doc.index('<w:body>') + len('<w:body>')]
    paras = re.findall(r'<w:p[ >].*?</w:p>', doc, re.S)
    p3 = paras[3]
    assert '<w:sectPr' in p3
    s2 = ('<w:p><w:pPr><w:sectPr><w:type w:val="continuous"/><w:pgSz w:w="11906" w:h="16838" w:code="9"/>'
          '<w:pgMar w:top="450" w:right="893" w:bottom="1440" w:left="893" w:header="720" w:footer="720" w:gutter="0"/>'
          '<w:cols w:space="720"/><w:docGrid w:linePitch="360"/></w:sectPr></w:pPr></w:p>')
    final_sect = ('<w:sectPr><w:type w:val="continuous"/><w:pgSz w:w="11906" w:h="16838" w:code="9"/>'
                  '<w:pgMar w:top="1080" w:right="907" w:bottom="1440" w:left="907" w:header="720" w:footer="720" w:gutter="0"/>'
                  '<w:cols w:num="2" w:space="360"/><w:docGrid w:linePitch="360"/></w:sectPr>')
    xml = head + title + p3 + author + s2 + body + final_sect + '</w:body></w:document>'
    open(f'{WORK}/word/document.xml', 'w', encoding='utf8').write(xml)

    # ---- custom styles for the legend box
    st = open(f'{WORK}/word/styles.xml', encoding='utf8').read()
    ARIAL = '<w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/>'
    styles = (
        '<w:style w:type="paragraph" w:customStyle="1" w:styleId="SkelLabel"><w:name w:val="Skeleton note label"/>'
        '<w:basedOn w:val="Normal"/><w:next w:val="SkelNote"/><w:pPr><w:keepNext/>'
        '<w:shd w:val="clear" w:color="auto" w:fill="DCE6F1"/><w:spacing w:before="100" w:after="0" w:line="216" w:lineRule="auto"/>'
        '<w:ind w:left="100" w:right="60"/><w:jc w:val="left"/></w:pPr>'
        f'<w:rPr>{ARIAL}<w:b/><w:bCs/><w:color w:val="1F3864"/><w:sz w:val="15"/><w:szCs w:val="15"/></w:rPr></w:style>'
        '<w:style w:type="paragraph" w:customStyle="1" w:styleId="SkelNote"><w:name w:val="Skeleton note text"/>'
        '<w:basedOn w:val="Normal"/><w:pPr><w:shd w:val="clear" w:color="auto" w:fill="EAF0F8"/>'
        '<w:spacing w:before="0" w:after="100" w:line="216" w:lineRule="auto"/><w:ind w:left="100" w:right="60"/><w:jc w:val="left"/></w:pPr>'
        f'<w:rPr>{ARIAL}<w:color w:val="1B2A41"/><w:sz w:val="15"/><w:szCs w:val="15"/></w:rPr></w:style>')
    st = st.replace('</w:styles>', styles + '</w:styles>')
    open(f'{WORK}/word/styles.xml', 'w', encoding='utf8').write(st)

    # ---- figures: media files, content type, relationships
    os.makedirs(f'{WORK}/word/media', exist_ok=True)
    rels = open(f'{WORK}/word/_rels/document.xml.rels', encoding='utf8').read()
    ct = open(f'{WORK}/[Content_Types].xml', encoding='utf8').read()
    add_rels = ''
    for rid, fname in dlib.IMAGES:
        shutil.copy(f'{FIGS}/{fname}', f'{WORK}/word/media/{fname}')
        add_rels += (f'<Relationship Id="{rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" '
                     f'Target="media/{fname}"/>')
    rels = rels.replace('</Relationships>', add_rels + '</Relationships>')
    if 'Extension="png"' not in ct:
        ct = ct.replace('<Default Extension="xml"', '<Default Extension="png" ContentType="image/png"/><Default Extension="xml"')
    open(f'{WORK}/word/_rels/document.xml.rels', 'w', encoding='utf8').write(rels)
    open(f'{WORK}/[Content_Types].xml', 'w', encoding='utf8').write(ct)

    # ---- metadata
    core = open(f'{WORK}/docProps/core.xml', encoding='utf8').read()
    core = re.sub(r'<dc:title>.*?</dc:title>', f'<dc:title>{lib.esc(draft_p1.TITLE)}</dc:title>', core)
    core = re.sub(r'<dc:creator>.*?</dc:creator>', '<dc:creator>Ramy Dabbour</dc:creator>', core)
    core = re.sub(r'<cp:lastModifiedBy>.*?</cp:lastModifiedBy>', '<cp:lastModifiedBy>Claude</cp:lastModifiedBy>', core)
    open(f'{WORK}/docProps/core.xml', 'w', encoding='utf8').write(core)

    if os.path.exists(out_path):
        os.remove(out_path)
    subprocess.run(f'cd {WORK} && zip -Xr "{out_path}" "[Content_Types].xml" _rels docProps word customXml', shell=True, check=True,
                   stdout=subprocess.DEVNULL)


if __name__ == '__main__':
    out = sys.argv[1]
    build(out)
    print('built', out, os.path.getsize(out), 'citations', len(dlib.CITE_ORDER), 'images', len(dlib.IMAGES))
