# Helpers that emit WordprocessingML fragments for the IEEE conference template.
import re, json
from xml.sax.saxutils import escape

COL_W = 4866          # one text column of the A4 template, in dxa
_sdt_id = [5000]
_seq = {'eq': 0}


def esc(s):
    return escape(s, {'"': '&quot;'})


def run(text, b=False, i=False, color=None, sz=None, rstyle=None, sub=False, sup=False,
        hl=None, font=None, caps=False):
    pr = ''
    if rstyle:
        pr += f'<w:rStyle w:val="{rstyle}"/>'
    if font:
        pr += f'<w:rFonts w:ascii="{font}" w:hAnsi="{font}" w:cs="{font}"/>'
    if b:
        pr += '<w:b/><w:bCs/>'
    if i:
        pr += '<w:i/><w:iCs/>'
    if caps:
        pr += '<w:caps/>'
    if color:
        pr += f'<w:color w:val="{color}"/>'
    if sz:
        pr += f'<w:sz w:val="{sz}"/><w:szCs w:val="{sz}"/>'
    if hl:
        pr += f'<w:highlight w:val="{hl}"/>'
    if sub:
        pr += '<w:vertAlign w:val="subscript"/>'
    if sup:
        pr += '<w:vertAlign w:val="superscript"/>'
    pr = f'<w:rPr>{pr}</w:rPr>' if pr else ''
    return f'<w:r>{pr}<w:t xml:space="preserve">{esc(text)}</w:t></w:r>'


TAG = r'\[(?:code|final run|verify[^\]]*|snapshot[^\]]*|confirm[^\]]*|computed[^\]]*)\]'
HLTOK = re.compile(r'(\u27e6.*?\u27e7|\u27ea.*?\u27eb)')       # yellow: [[ ]]  cyan: << >>
TOK = re.compile(r'(\*\*.+?\*\*|\u27e8.+?\u27e9|~[^~]+~|\^[^^]+\^|' + TAG + ')')   # bold, italic <x>, sub, sup, red tags


def rich(text, base=None, tagcolor='B03A2E'):
    """Mini-markup: **bold**, <x> italic, ~sub~, ^sup^, [[yellow]], <<cyan>>, and [code]/[final run]/... tags.
    Highlight spans and bold/italic/sub/sup spans may contain each other (one level each)."""
    base = dict(base or {})
    out = []
    for seg in HLTOK.split(text):
        if not seg:
            continue
        if seg[0] == '\u27e6' and seg[-1] == '\u27e7':
            kw = dict(base); kw['hl'] = 'yellow'
            out.append(rich(seg[1:-1], kw, tagcolor)); continue
        if seg[0] == '\u27ea' and seg[-1] == '\u27eb':
            kw = dict(base); kw['hl'] = 'cyan'
            out.append(rich(seg[1:-1], kw, tagcolor)); continue
        for part in TOK.split(seg):
            if not part:
                continue
            if part.startswith('**') and part.endswith('**') and len(part) > 4:
                kw = dict(base); kw['b'] = True
                out.append(rich(part[2:-2], kw, tagcolor))
            elif part[0] == '\u27e8' and part[-1] == '\u27e9':
                kw = dict(base); kw['i'] = True
                out.append(rich(part[1:-1], kw, tagcolor))
            elif part.startswith('~') and part.endswith('~') and len(part) > 2:
                kw = dict(base); kw['sub'] = True
                out.append(rich(part[1:-1], kw, tagcolor))
            elif part.startswith('^') and part.endswith('^') and len(part) > 2:
                kw = dict(base); kw['sup'] = True
                out.append(rich(part[1:-1], kw, tagcolor))
            elif re.fullmatch(TAG, part):
                kw = dict(base); kw['b'] = True; kw['color'] = tagcolor
                out.append(run(part, **kw))
            else:
                out.append(run(part, **base))
    return ''.join(out)


def para(style, inner, ppr=''):
    st = f'<w:pStyle w:val="{style}"/>' if style else ''
    return f'<w:p><w:pPr>{st}{ppr}</w:pPr>{inner}</w:p>'


# ---------- structural elements ----------
def h1(t):
    return para('Heading1', run(t))


def h2(t):
    return para('Heading2', run(t))


def h5(t):
    return para('Heading5', run(t), '<w:keepNext/>')


# ---------- skeleton notes ----------
def note(label, bullets=(), plain=None, notes=True):
    if not notes:
        return ''
    x = para('SkelLabel', rich(label, {}))
    if plain:
        x += para('SkelNote', rich(plain))
    for b in bullets:
        x += para('SkelBullet', rich(b))
    return x


def spacer_note(notes=True):
    return para('SkelGap', '') if notes else ''


# ---------- fill-in fields (content controls) ----------
def _sdt_pr(alias):
    _sdt_id[0] += 1
    return (f'<w:sdtPr><w:alias w:val="{esc(alias)}"/><w:tag w:val="{esc(alias)}"/>'
            f'<w:id w:val="{_sdt_id[0]}"/><w:showingPlcHdr/></w:sdtPr>')


def slot(label, style='BodyText', ppr=''):
    """Block-level content control: gray placeholder that vanishes when typed over."""
    ph = f'<w:r><w:rPr><w:rStyle w:val="PlaceholderText"/></w:rPr><w:t xml:space="preserve">{esc(label)}</w:t></w:r>'
    return (f'<w:sdt>{_sdt_pr(label)}<w:sdtContent>'
            f'<w:p><w:pPr><w:pStyle w:val="{style}"/>{ppr}</w:pPr>{ph}</w:p></w:sdtContent></w:sdt>')


def inline_slot(label):
    ph = f'<w:r><w:rPr><w:rStyle w:val="PlaceholderText"/></w:rPr><w:t xml:space="preserve">{esc(label)}</w:t></w:r>'
    return f'<w:sdt>{_sdt_pr(label)}<w:sdtContent>{ph}</w:sdtContent></w:sdt>'


def bullet_slot(lead, label):
    return para('bulletlist', run(lead + ' ', b=True) + inline_slot(label))


# ---------- figures and tables ----------
def fig(box_text, caption_hint, height=2100):
    box = (f'<w:tbl><w:tblPr><w:tblW w:w="{COL_W - 60}" w:type="dxa"/><w:jc w:val="center"/>'
           '<w:tblBorders>'
           + ''.join(f'<w:{s} w:val="dashed" w:sz="6" w:space="0" w:color="8C8C8C"/>' for s in ('top', 'left', 'bottom', 'right'))
           + '</w:tblBorders><w:tblLayout w:type="fixed"/>'
           '<w:tblCellMar><w:left w:w="80" w:type="dxa"/><w:right w:w="80" w:type="dxa"/></w:tblCellMar>'
           '<w:tblLook w:val="0000"/></w:tblPr>'
           f'<w:tblGrid><w:gridCol w:w="{COL_W - 60}"/></w:tblGrid>'
           f'<w:tr><w:trPr><w:cantSplit/><w:trHeight w:val="{height}" w:hRule="atLeast"/></w:trPr>'
           f'<w:tc><w:tcPr><w:tcW w:w="{COL_W - 60}" w:type="dxa"/><w:vAlign w:val="center"/></w:tcPr>'
           + para('Normal', rich(box_text, {'i': True, 'color': '6B6B6B', 'sz': 16}), '<w:keepNext/><w:jc w:val="center"/>')
           + '</w:tc></w:tr></w:tbl>')
    cap = para('figurecaption', inline_slot(caption_hint))
    return box + cap


def _cell(text, w, style, jc='left', fill=None, span=1, bold=False):
    tcpr = f'<w:tcW w:w="{w}" w:type="dxa"/>'
    if span > 1:
        tcpr += f'<w:gridSpan w:val="{span}"/>'
    if fill:
        tcpr += f'<w:shd w:val="clear" w:color="auto" w:fill="{fill}"/>'
    tcpr += '<w:vAlign w:val="center"/>'
    inner = rich(text, {'b': True} if bold else {}) if text else ''
    return (f'<w:tc><w:tcPr>{tcpr}</w:tcPr>'
            + para(style, inner, f'<w:jc w:val="{jc}"/>') + '</w:tc>')


def table(caption, widths, header, rows, align=None, row_h=260, cap_slot=False, col_jc=None):
    """caption: text for the auto-numbered 'table head'. header/rows: lists of strings."""
    n = len(widths)
    col_jc = col_jc or ['left'] + ['center'] * (n - 1)
    cap_inner = inline_slot(caption) if cap_slot else rich(caption)
    x = para('tablehead', cap_inner, '<w:keepNext/>')
    x += ('<w:tbl><w:tblPr><w:tblW w:w="%d" w:type="dxa"/><w:jc w:val="center"/><w:tblBorders>' % sum(widths)
          + ''.join(f'<w:{s} w:val="single" w:sz="2" w:space="0" w:color="auto"/>' for s in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'))
          + '</w:tblBorders><w:tblLayout w:type="fixed"/>'
          '<w:tblCellMar><w:left w:w="50" w:type="dxa"/><w:right w:w="50" w:type="dxa"/></w:tblCellMar>'
          '<w:tblLook w:val="0000"/></w:tblPr><w:tblGrid>'
          + ''.join(f'<w:gridCol w:w="{w}"/>' for w in widths) + '</w:tblGrid>')
    x += ('<w:tr><w:trPr><w:cantSplit/><w:trHeight w:val="240"/><w:tblHeader/></w:trPr>'
          + ''.join(_cell(h, w, 'tablecolhead', 'center', fill='F2F2F2') for h, w in zip(header, widths)) + '</w:tr>')
    for r_ in rows:
        x += (f'<w:tr><w:trPr><w:cantSplit/><w:trHeight w:val="{row_h}" w:hRule="atLeast"/></w:trPr>'
              + ''.join(_cell(c, w, 'tablecopy', j) for c, w, j in zip(r_, widths, col_jc)) + '</w:tr>')
    x += '</w:tbl>'
    x += para('Normal', '', '<w:spacing w:before="0" w:after="60"/><w:rPr><w:sz w:val="8"/></w:rPr>')
    return x


# ---------- equations ----------
EQ_TABS = ('<w:tabs><w:tab w:val="clear" w:pos="2520"/><w:tab w:val="clear" w:pos="5040"/>'
           f'<w:tab w:val="center" w:pos="{COL_W // 2}"/><w:tab w:val="right" w:pos="{COL_W}"/></w:tabs>')
TNR = '<w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/>'


def _eqnum():
    _seq['eq'] += 1
    n = _seq['eq']
    f = lambda t: f'<w:r><w:rPr>{TNR}</w:rPr>{t}</w:r>'
    return (f(f'<w:tab/><w:t>(</w:t>')
            + f('<w:fldChar w:fldCharType="begin"/>')
            + f('<w:instrText xml:space="preserve"> SEQ Equation \\* ARABIC </w:instrText>')
            + f('<w:fldChar w:fldCharType="separate"/>')
            + f(f'<w:t>{n}</w:t>')
            + f('<w:fldChar w:fldCharType="end"/>')
            + f('<w:t>)</w:t>'))


def equation(omml):
    return para('equation', f'<w:r><w:rPr>{TNR}</w:rPr><w:tab/></w:r>' + omml + _eqnum(), EQ_TABS)


def equation_placeholder(text):
    ph = f'<w:r><w:rPr>{TNR}<w:i/><w:color w:val="6B6B6B"/><w:sz w:val="18"/></w:rPr><w:tab/><w:t xml:space="preserve">{esc(text)}</w:t></w:r>'
    return para('equation', ph + _eqnum(), EQ_TABS)


def body_text(text):
    return para('BodyText', rich(text))
