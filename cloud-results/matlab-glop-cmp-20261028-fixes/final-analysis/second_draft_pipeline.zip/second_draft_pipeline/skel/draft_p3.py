# Second draft (final run), part 3: V. Results, VI. Discussion, VII. Conclusion, acknowledgment, references.
# Every number is computed from draft_data (final run, 77,760 trials).
import numpy as np
import lib, dlib
from lib import para, rich, run, h1, h2, h5
from dlib import cite, eq, eqref, tabref, figref
import draft_data as D
from draft_data import Y, C

S = D.S
NONSA = [m for m in S if m != 'SA']
ARW = '→'
NUMW = {1: 'One', 2: 'Two', 3: 'Three', 4: 'Four', 5: 'Five', 6: 'Six', 7: 'Seven', 8: 'Eight', 9: 'Nine', 10: 'Ten'}
MIN = '−'


def B(t):
    return para('BodyText', rich(t))


def both_pct(a, b):
    if f'{100 * a:.0f}' == f'{100 * b:.0f}':
        return f'{100 * a:.0f}% of runs at both stages'
    return f'{100 * a:.0f}% and {100 * b:.0f}% of runs'


def pr(r, m):
    return f'{r}{ARW}{m}'


def ev(v):
    if v is None or not np.isfinite(v):
        return '–'
    if v >= 1e6:
        return f'{v / 1e6:.1f}M'
    if v >= 1e4:
        return f'{v / 1e3:.0f}k'
    if v >= 1e3:
        return f'{v / 1e3:.1f}k'
    return f'{v:.0f}'


def sc(v):
    if v is None or not np.isfinite(v):
        return '–'
    return f'{v:.1f}' if v < 10 else f'{v:,.0f}'


def rg(vals, d=2):
    lo, hi = min(vals), max(vals)
    if f'{lo:.{d}f}' == f'{hi:.{d}f}':
        return f'{lo:.{d}f}'
    return f'{lo:.{d}f}–{hi:.{d}f}'


def db(x, d=1):
    return f'{MIN}{abs(x):.{d}f}'


def ci(lo, hi, d=2):
    return f'{lo:.{d}f}–{hi:.{d}f}'


def sci(x, d=0):
    e = int(np.floor(np.log10(abs(x))))
    m = x / 10 ** e
    if float(f'{m:.{d}f}') >= 10:
        m /= 10; e += 1
    return f'{m:.{d}f}×10^{MIN}{abs(e)}^' if e < 0 else f'{m:.{d}f}×10^{e}^'


def build_p3():
    T = D.T
    b = []
    add = b.append

    # ------------------------------------------------------------------ numbers used below
    cost = {s: D.stage_cost(s) for s in S}
    flags = {s: (D.flag_share(1, s)[0], D.flag_share(2, s)[0]) for s in S}
    ms = {s: dict(S1=1000 * T[T.ref == s].ref_seconds.sum() / T[T.ref == s].ref_evals.sum(),
                  S2=1000 * T[T.mzi == s].mzi_seconds.sum() / T[T.mzi == s].mzi_evals.sum()) for s in S}
    g12 = T[T.ref.isin(['GA', 'PSO'])]

    def p_s2(m, tau=-20):                     # success of a Stage-2 solver after a GA or PSO reference
        g = g12[g12.mzi == m]
        return float(D.succ(g, tau).mean())

    def med_s2(m):
        return 20 * np.log10(g12[g12.mzi == m].delta.median())

    def p_s1(r, tau=-20, cols=NONSA):         # success of a Stage-1 solver over a set of Stage-2 solvers
        return [D.P(r, m, tau) for m in cols]

    CORE = ['GA', 'PSO', 'SO', 'PS']          # Stage-2 solvers that behave alike after a good reference
    lead = [(r, m) for r in ('GA', 'PSO') for m in CORE]
    Fm = {(r, m): D.legacy(r, m)['F'] for r in S for m in S}
    Pl = {(r, m): D.legacy(r, m)['P'] for r in S for m in S}
    top_F = sorted(Fm, key=lambda k: -Fm[k])[:5]
    P25 = {(r, m): D.P(r, m, -25) for r in S for m in S}
    best25 = max(P25, key=P25.get)
    hard = (T.order == 4) & np.isclose(T.ratio, 0.5)        # the one instance whose best delta sits at the -20 dB tolerance
    Th = T[~hard]

    def P_excl(r, m, tau=-20):
        g = Th[(Th.ref == r) & (Th.mzi == m)]
        return float(D.succ(g, tau).mean())

    # ================================================================== V. Results
    add(h1('Results'))
    add(h2('Coverage and Exit Flags'))
    nfail = int((T.status == 'failed').sum())
    assert nfail == 0 and D.N_NOSTAGE2 == 0 and D.N_TRIALS == D.PLANNED
    add(B(f'All {D.N_TRIALS:,} planned trials completed, {D.N_PER_PAIR[0]:,} per pair, and every trial returned a valid design from both stages. '
          f'No trial ended in an exception: the telemetry-write and eigenvalue failures that ended nine trials of the earlier snapshot did not recur after the changes described in Section IV-E. '
          f'The job was interrupted once and resumed from its per-trial checkpoints under the same source and configuration hashes. '
          f'The per-trial diagnostic record of two trials was not exported, so we read those two from their checkpoint files. No trial is excluded.'))

    def fstr(s, stage):
        d = flags[s][stage]
        return '/'.join(f'{100 * d[f]:.0f}' for f in (1, 0, -1))

    rows3 = [[s, fstr(s, 0), fstr(s, 1), ev(cost[s]['e1']), ev(cost[s]['e2']), sc(cost[s]['t1']), sc(cost[s]['t2'])] for s in S]
    par_s2_other = int(((T.mzi == 'PAR') & (T.mzi_exit != 0)).sum())
    so_s2 = T[T.mzi == 'SO']
    so_lim = int(so_s2.mzi_message.str.contains('ObjectiveLimit').sum()); so_time = int(so_s2.mzi_message.str.contains('time limit').sum())
    add(B(tabref('flags') + ' shows how the runs ended. '
          f'SA stopped on its stall tolerance in every run of both stages. SO stopped through our stall rule (flag −1) in every Stage-1 run and in {100 * flags["SO"][1][-1]:.1f}% of Stage-2 runs; '
          f'the others reached the objective limit ({so_lim}) or the time limit ({so_time}). '
          f'PAR reached its evaluation budget in every Stage-1 run and in all but {NUMW.get(par_s2_other, str(par_s2_other)).lower()} Stage-2 runs. '
          f'GA, PSO and PS stopped on tolerance in {100 * min(flags[s][0][1] for s in ("GA", "PSO", "PS")):.0f}–{100 * max(flags[s][0][1] for s in ("GA", "PSO", "PS")):.0f}% of Stage-1 runs. '
          f'At Stage 2, GA and PS ended at their generation or iteration cap in {100 * flags["GA"][1][0]:.0f}% and {100 * flags["PS"][1][0]:.0f}% of runs, and PSO in {100 * flags["PSO"][1][0]:.0f}%. '
          f'Under the legacy rule, success requires both flags to be positive, so no pair with SO or PAR at Stage 1 can succeed and pairs ending in GA, PS, SO or PAR seldom or never do: '
          f'{D.LEG_SUCC:,} of {D.N_TRIALS:,} trials ({100 * D.LEG_SUCC / D.N_TRIALS:.0f}%) qualify, and {D.N_F0} of the 36 pairs have no legacy success. '
          'A flag reports that a solver’s own rule fired, not that the design is accurate.'))
    add(dlib.table('flags', 'Exit flags (share of runs in %: flag 1 / 0 / −1, meaning tolerance or stall / iteration or evaluation cap / output-function stop) '
                   'and mean cost per run, 12,960 runs per solver and stage.',
                   [600, 860, 860, 640, 640, 633, 633],
                   ['Solver', 'S1 flags', 'S2 flags', 'S1 evals', 'S2 evals', 'S1 s', 'S2 s'], rows3, row_h=200))

    # ------------------------------------------------------------------ B. Success and cost
    add(h2('Success and Cost'))
    pgap = lambda r, cols=NONSA: rg(p_s1(r, -20, cols))
    lead_vals = [D.P(*k) for k in lead]
    ci_top = D.boot('PSO', 'GA', -20, 'P')
    hard_best = D.BEST_INST_DB[(4, 0.5)]
    hard_n = int(D.succ(T[hard], -20).sum())
    add(B(f'The first-stage solver separates the pairs (' + figref('heat') + 'a). With GA or PSO at Stage 1, the success fraction at −20 dB is '
          f'{rg(lead_vals)} when Stage 2 is GA, PSO, SO or PS, {rg([D.P(r, "PAR") for r in ("GA", "PSO")])} when it is PAR and {D.P("GA", "SA"):.2f} when it is SA. '
          f'With PS at Stage 1 it is {pgap("PS")} ({D.P("PS", "SA"):.2f} with SA), with PAR {pgap("PAR")}, with SA at most {max(p_s1("SA")):.3f}, and with SO zero in all 12,960 trials. '
          f'The best pair, PSO{ARW}GA, reaches {D.P("PSO", "GA"):.3f} (95% interval {ci(*ci_top[:2], 3)}). '
          f'The ceiling near 0.97 is set largely by one instance: at ⟨N⟩ = 4 and ⟨ρ⟩ = 0.5 the best δ found by any of the 2,160 trials is {db(hard_best, 2)} dB, and only {NUMW.get(hard_n, str(hard_n)).lower()} of them meet{"s" if hard_n == 1 else ""} the tolerance. '
          f'On the other 35 instances the eight leading pairs succeed in {rg([P_excl(*k) for k in lead], 3)} of trials.'))
    add(dlib.figure('heat', 'fig2_heatmaps.png', 3.35, None,
                    'Success fraction at −20 dB (a) and evaluations per success (b) for the 36 pairs, by Stage-1 solver (rows) and Stage-2 solver (columns); 2,160 trials per pair.',
                    'Two six-by-six heat maps of success fraction and cost per success'))

    b25 = D.boot(*best25, -25, 'P')
    d25 = D.boot_diff(('PSO', 'PSO'), ('GA', 'GA'), -25)
    d25b = D.boot_diff(('PSO', 'PSO'), ('PSO', 'PS'), -25)
    mx30 = max(D.P(r, m, -30) for r in S for m in S)
    n30 = int(D.succ(T, -30).sum()); n35 = int(D.succ(T, -35).sum())
    bi = D.BEST_INST_DB; fl = D.FLOOR_DB
    n_fl30 = sum(1 for k in fl if fl[k] <= -30)
    gapf = D.BEST_GAPFLOOR
    add(B(f'Tightening the tolerance separates the leaders (' + figref('curves') + f'a). At −25 dB the order is PSO{ARW}PSO {P25[("PSO", "PSO")]:.2f} ({ci(*b25[:2])}), PSO{ARW}GA {P25[("PSO", "GA")]:.2f}, '
          f'PSO{ARW}PS {P25[("PSO", "PS")]:.2f} and PSO{ARW}SO {P25[("PSO", "SO")]:.2f}, against {P25[("GA", "PSO")]:.2f} for GA{ARW}PSO and {P25[("GA", "GA")]:.2f} for GA{ARW}GA. '
          f'The difference between PSO{ARW}PSO and GA{ARW}GA is {ci(*d25)}, and between PSO{ARW}PSO and PSO{ARW}PS {ci(*d25b)} (95% block-bootstrap intervals). '
          f'At −30 dB no pair exceeds {mx30:.3f} ({n30} trials in all), and no trial reaches −35 dB, so the rungs from −35 to −60 dB separate nothing. '
          f'The passivity floor of Section II-D explains why: it lies between {db(max(fl.values()), 1)} and {db(min(fl.values()), 1)} dB, so the rungs at −40 dB and below are out of reach of any passive half-band response of this degree, '
          f'and −30 dB is attainable in principle on only {n_fl30} of the 36 instances. The best δ found per instance is {db(max(bi.values()), 1)} to {db(min(bi.values()), 1)} dB, '
          f'which is {min(gapf.values()):.1f} to {max(gapf.values()):.1f} dB above the floor. ' + tabref('pairs') + ' therefore reports −20, −25 and −30 dB.'))

    # figure 3 (curves + scatter)
    add(dlib.figure('curves', 'fig3_curves.png', 3.35, None,
                    'Success fraction against tolerance for six pairs chosen by rule (a): the pair with the highest success at −25 dB, the best pair with GA first, the pair with the fewest seconds per success among those above 0.9, '
                    'the pair with the fewest evaluations per success, the best pair with PAR first and the best pair with SA second. '
                    'Final δ against the Stage-1 gap to the convex baseline for every trial with a Stage-2 solver other than SA, colored by Stage-1 solver (b).',
                    'Success fraction against tolerance and final error against Stage-1 gap'))

    ert = {k: D.boot(*k, -20, 'ERT', 'ev') for k in (('PSO', 'SO'), ('PS', 'SO'), ('PS', 'PS'), ('PSO', 'PS'))}
    erts = {k: D.boot(*k, -20, 'ERT', 's') for k in (('PSO', 'PS'), ('PSO', 'SO'), ('PS', 'PS'))}
    es = lambda r, m: D.ert(r, m, -20, 's')
    nd_ev = ', '.join(k.replace('>', ARW) for k in D.ND_EV); nd_s = ', '.join(k.replace('>', ARW) for k in D.ND_S)
    add(B(f'Cost reverses the order (' + figref('heat') + f'b). PS{ARW}SO needs {ev(D.ert("PS", "SO"))} evaluations per success ({ev(ert[("PS", "SO")][0])}–{ev(ert[("PS", "SO")][1])}) and PS{ARW}PS {ev(D.ert("PS", "PS"))} '
          f'({ev(ert[("PS", "PS")][0])}–{ev(ert[("PS", "PS")][1])}), at success fractions of {D.P("PS", "SO"):.2f} and {D.P("PS", "PS"):.2f}. '
          f'The cheapest pair above 0.9 is PSO{ARW}SO at {ev(D.ert("PSO", "SO"))} ({ev(ert[("PSO", "SO")][0])}–{ev(ert[("PSO", "SO")][1])}), {D.ert("PSO", "SO") / D.ert("PS", "SO"):.0f} times the cost of PS{ARW}SO; '
          f'almost all of it is the Stage-1 run, which averages {ev(cost["PSO"]["e1"])} evaluations for PSO and {ev(cost["GA"]["e1"])} for GA. '
          f'In seconds the picture changes, because a Stage-2 evaluation costs about {ms["GA"]["S2"]:.0f} ms against {ms["GA"]["S1"]:.1f} ms at Stage 1, and SO adds overhead ({ms["SO"]["S1"]:.0f} and {ms["SO"]["S2"]:.0f} ms per evaluation at the two stages). '
          f'PSO{ARW}PS takes {sc(es("PSO", "PS"))} s per success ({sc(erts[("PSO", "PS")][0])}–{sc(erts[("PSO", "PS")][1])}) at a success fraction of {D.P("PSO", "PS"):.2f}, PSO{ARW}SO {sc(es("PSO", "SO"))} s, and PS{ARW}PS {sc(es("PS", "PS"))} s at {D.P("PS", "PS"):.2f}; '
          f'PSO{ARW}PSO, the most accurate pair, takes {sc(es("PSO", "PSO"))} s. '
          f'The pairs not dominated in (success fraction, evaluations per success) are {nd_ev}; in (success fraction, seconds per success) they are {nd_s}.'))
    rows4 = []
    sel = [('PSO', 'PSO'), ('PSO', 'GA'), ('GA', 'PSO'), ('GA', 'GA'), ('PSO', 'SO'), ('GA', 'SO'), ('PSO', 'PS'), ('GA', 'PS'), ('PSO', 'PAR'),
           ('PS', 'GA'), ('PS', 'SO'), ('PS', 'PS'), ('PAR', 'PAR'), ('PS', 'SA'), ('SA', 'SA'), ('SO', 'SO')]
    ndset = {k.replace('>', ARW) for k in D.ND_EV}; ndset_s = {k.replace('>', ARW) for k in D.ND_S}
    for r, m in sel:
        name = pr(r, m) + ('†' if pr(r, m) in ndset else '') + ('‡' if pr(r, m) in ndset_s else '')
        rows4.append([name, f'{D.P(r, m, -20):.2f}', f'{D.P(r, m, -25):.2f}', f'{D.P(r, m, -30):.3f}', ev(D.ert(r, m, -20)), sc(D.ert(r, m, -20, "s")), f'{Fm[(r, m)]:.3f}'])
    add(dlib.table('pairs', 'Selected pairs (Stage 1' + ARW + 'Stage 2): success fraction at −20, −25 and −30 dB, evaluations and seconds per success at −20 dB, and legacy index. '
                   '† and ‡ mark pairs not dominated in (success fraction, evaluations per success) and in (success fraction, seconds per success).',
                   [980, 560, 560, 560, 760, 720, 726], ['Pair', '−20 dB', '−25 dB', '−30 dB', 'Evals / success', 'Sec / success', 'Legacy F'], rows4, row_h=200))

    tf = ', '.join(f'{pr(*k)} ({Fm[k]:.2f})' for k in top_F[:3])
    pf = ', '.join(f'{D.P(*k):.2f}' for k in top_F[:3])
    add(B(f'The legacy index ranks the pairs differently. It places {tf} first, whose success fractions at −20 dB are {pf}, and gives zero to {D.N_F0} of the 36 pairs, whereas only {NUMW.get(D.N_P0, str(D.N_P0)).lower()} pairs have no success at −20 dB. '
          f'GA{ARW}GA and PSO{ARW}GA, with success fractions of {D.P("GA", "GA"):.2f} and {D.P("PSO", "GA"):.2f}, score {Fm[("GA", "GA")]:.3f} and {Fm[("PSO", "GA")]:.3f}, because GA ends at its generation cap in Stage 2. '
          f'The rank agreement of the index with the success fraction at −20 dB is Kendall’s τ = {D.KT_F_P20:.2f}, while the success fractions at −20 and −25 dB agree at {D.KT_P20_P25:.2f}.'))

    # ------------------------------------------------------------------ C. Cross-stage coupling
    add(h2('Cross-Stage Coupling'))
    med1 = {s: D.med_delta_by_s1(s) for s in S}
    med2 = {m: med_s2(m) for m in S}
    core_med2 = [med2[m] for m in CORE]
    s2 = D.S2COST
    rel = {m: (s2.loc[m].max() - s2.loc[m].min()) / s2.loc[m].min() for m in S}
    others = [m for m in S if m != 'PSO']
    add(B(f'The Stage-1 solver sets the final error. With the Stage-2 solvers other than SA, the median δ is {db(med1["PSO"])}, {db(med1["GA"])}, {db(med1["PS"])}, {db(med1["PAR"])}, {db(med1["SO"])} and {db(med1["SA"])} dB '
          f'for PSO, GA, PS, PAR, SO and SA at Stage 1. With GA or PSO at Stage 1, the choice among GA, PSO, SO and PS at Stage 2 moves the median δ by {max(core_med2) - min(core_med2):.1f} dB; '
          f'PAR costs {med2["PAR"] - min(core_med2):.1f} dB and SA {med2["SA"] - min(core_med2):.0f} dB. '
          f'The final error follows the Stage-1 gap to the convex baseline (Spearman ρ~s~ = {D.SPEARMAN_NOSA:.2f} over the {int((T.mzi != "SA").sum()):,} trials without SA at Stage 2, ' + figref('curves') + 'b), whose median is '
          f'{sci(cost["PSO"]["gap"])}, {sci(cost["GA"]["gap"])}, {cost["PS"]["gap"]:.3f}, {cost["PAR"]["gap"]:.2f}, {cost["SO"]["gap"]:.2f} and {cost["SA"]["gap"]:.2f} for the same six solvers. '
          f'No Stage-2 solver repairs a poor reference, and below a gap of about 10^−2^ a better reference improves the final error only slightly.'))
    pso2 = T[T.mzi == 'PSO']
    stall = {r: float((pso2[pso2.ref == r].mzi_exit == 1).mean()) for r in S}
    add(B(f'The Stage-1 solver also changes the Stage-2 cost, mainly for PSO. PSO’s mean Stage-2 evaluations range from {ev(s2.loc["PSO"].min())} after {s2.loc["PSO"].idxmin()} to {ev(s2.loc["PSO"].max())} after {s2.loc["PSO"].idxmax()}, '
          f'a factor of {s2.loc["PSO"].max() / s2.loc["PSO"].min():.1f}; SA varies by {100 * rel["SA"]:.0f}% and the other four by at most {100 * max(rel[m] for m in others if m != "SA"):.0f}%. '
          f'PSO stops on its stall rule in {100 * min(stall["SO"], stall["SA"]):.0f}–{100 * max(stall["SO"], stall["SA"]):.0f}% of runs after an SO or SA reference and in {100 * min(stall["GA"], stall["PSO"], stall["PS"]):.0f}–{100 * max(stall["GA"], stall["PSO"], stall["PS"]):.0f}% after GA, PSO or PS, '
          f'so the cheaper runs are runs that stall earlier. Why a poor reference makes PSO stall earlier we did not test.'))

    # ------------------------------------------------------------------ D. Order and passband ratio
    add(h2('Dependence on Order and Passband Ratio'))
    gl = T[T.ref.isin(['GA', 'PSO']) & T.mzi.isin(CORE)]

    def by(g, col, tau):
        return {k: float(D.succ(x, tau).mean()) for k, x in g.groupby(col)}

    r20 = by(gl, 'ratio', -20)
    o20n = by(gl[~np.isclose(gl.ratio, 0.5)], 'order', -20)
    psf = T[(T.ref == 'PS') & T.mzi.isin(CORE)]; ps_r = by(psf, 'ratio', -20)
    parf = T[(T.ref == 'PAR') & T.mzi.isin(CORE)]; par_o = by(parf, 'order', -20)
    par2 = by(g12[g12.mzi == 'PAR'], 'order', -20)
    par_gap = {int(o): float(x.s1_gap_to_baseline.median()) for o, x in D.S1U[D.S1U.ref == 'PAR'].groupby('order')}
    r25 = {r: by(T[(T.ref == r) & T.mzi.isin(CORE)], 'ratio', -25) for r in ('GA', 'PSO')}
    o25 = by(gl[np.isclose(gl.ratio, 0.2)], 'order', -25)
    best5 = max(v for k, v in bi.items() if k[1] == 0.5), min(v for k, v in bi.items() if k[1] == 0.5)
    fl5 = max(v for k, v in fl.items() if k[1] == 0.5), min(v for k, v in fl.items() if k[1] == 0.5)
    add(B(figref('order') + f' splits the results by instance for the three Stage-1 solvers with the highest success, pooled over the Stage-2 solvers GA, PSO, SO and PS. '
          f'With GA or PSO at Stage 1, success at −20 dB is {min(o20n.values()):.2f} or more at every order for ⟨ρ⟩ ≤ 0.4 and shows no trend; at ⟨ρ⟩ = 0.5 it is zero at ⟨N⟩ = 4 and {min(v for k, v in by(gl[np.isclose(gl.ratio, 0.5)], "order", -20).items() if k > 4):.2f} or more above. '
          f'PS at Stage 1 weakens as the passband widens: {ps_r[0.2]:.2f}, {ps_r[0.3]:.2f}, {ps_r[0.4]:.2f} and {ps_r[0.5]:.2f} at ⟨ρ⟩ = 0.2, 0.3, 0.4 and 0.5. '
          f'PAR weakens with order at both stages. As a Stage-1 solver it falls from {par_o[4]:.2f} at ⟨N⟩ = 4 to {par_o[8]:.2f} at ⟨N⟩ = 8 and to zero from ⟨N⟩ = 10, while its median gap to the convex baseline grows from {par_gap[4]:.2f} to {par_gap[12]:.2f}; '
          f'as a Stage-2 solver after GA or PSO it falls from {par2[5]:.2f} at ⟨N⟩ = 5 to {par2[12]:.2f} at ⟨N⟩ = 12. Its budget of 20,000 evaluations is the same at every order.'))
    add(B(f'At −25 dB the instances differ more than the solvers do. No trial reaches −25 dB at ⟨ρ⟩ = 0.5, where the best δ per order is {db(best5[0], 1)} to {db(best5[1], 1)} dB and the floor {db(fl5[0], 1)} to {db(fl5[1], 1)} dB, '
          f'and almost none at ⟨N⟩ = 4 or 5 for any ⟨ρ⟩ (at ⟨ρ⟩ = 0.2, {o25[4]:.2f} and {o25[5]:.2f} against {o25[7]:.2f} at ⟨N⟩ = 7). '
          f'The advantage of PSO over GA at Stage 1 also depends on ⟨ρ⟩: success at −25 dB is {r25["PSO"][0.2]:.2f} against {r25["GA"][0.2]:.2f} at ⟨ρ⟩ = 0.2, {r25["PSO"][0.3]:.2f} against {r25["GA"][0.3]:.2f} at 0.3 and {r25["PSO"][0.4]:.2f} against {r25["GA"][0.4]:.2f} at 0.4. '
          f'At −20 dB the order of the Stage-1 solvers (PSO, GA, PS, PAR, then SA and SO near zero) is the same at every ⟨ρ⟩; across orders the only change is that PAR passes PS at ⟨N⟩ = 4.'))
    add(dlib.figure('order', 'fig4_order.png', 3.35, None,
                    'Success fraction against order for each passband ratio, with PSO, GA or PS at Stage 1, pooled over the Stage-2 solvers GA, PSO, SO and PS (240 trials per point). Solid lines and filled markers: −20 dB; dashed lines and open markers: −25 dB.',
                    'Four panels of success fraction against order, one per passband ratio'))

    # ------------------------------------------------------------------ E. Hypotheses
    add(h2('Hypotheses'))
    H = {}
    r1 = [cost['GA']['e1'] / cost['PS']['e1'], cost['GA']['e2'] / cost['PS']['e2'], cost['GA']['e1'] / cost['SA']['e1'], cost['GA']['e2'] / cost['SA']['e2']]
    H[1] = ('Supported' if min(r1) >= 10 else 'Not supported',
            f'GA uses {r1[0]:.0f}× (S1) and {r1[1]:.0f}× (S2) the evaluations of PS, and {r1[2]:,.0f}× and {r1[3]:.0f}× those of SA.')
    p2a = p_s2('PSO')
    h2_s1 = min(p_s1('PSO')) >= 0.9; h2_rest = p2a >= 0.9 and cost['PSO']['e1'] > 1e5 and cost['PSO']['e2'] > 1e5
    H[2] = ('Supported' if (h2_s1 and h2_rest) else ('Partly supported' if h2_rest else 'Not supported'),
            f'As Stage 1: {rg(p_s1("PSO", -20, CORE))} with GA, PSO, SO or PS, but {D.P("PSO", "PAR"):.2f} with PAR, below 0.9. As Stage 2 after GA or PSO: {p2a:.2f}. {ev(cost["PSO"]["e1"])} and {ev(cost["PSO"]["e2"])} evaluations.')
    h3 = cost['SO']['e1'] < 1e3 and cost['SO']['e2'] < 1e3 and p_s2('SO') >= 0.9 and max(p_s1('SO')) < 0.05
    H[3] = ('Supported' if h3 else 'Not supported',
            f'{ev(cost["SO"]["e1"])} and {ev(cost["SO"]["e2"])} evaluations; success {p_s2("SO"):.2f} as Stage 2 after GA or PSO, {max(p_s1("SO")):.2f} as Stage 1.')
    worst_s2 = min(S, key=lambda m: p_s2(m))
    h4 = flags['SA'][0][1] >= 0.95 and flags['SA'][1][1] >= 0.95 and cost['SA']['e1'] < 200 and cost['SA']['e2'] < 200 and worst_s2 == 'SA'
    sa200 = (float((D.S1U[D.S1U.ref == 'SA'].ref_evals < 200).mean()), float((T[T.mzi == 'SA'].mzi_evals < 200).mean()))
    H[4] = ('Supported on average' if h4 else 'Not supported',
            f'Flag 1 in {both_pct(flags["SA"][0][1], flags["SA"][1][1])}; mean {ev(cost["SA"]["e1"])} and {ev(cost["SA"]["e2"])} evaluations, under 200 in {100 * sa200[0]:.0f}% and {100 * sa200[1]:.0f}% of runs; '
            f'success {p_s2("SA"):.2f} as Stage 2 after GA or PSO against {min(p_s2(m) for m in NONSA):.2f} or more for the others.')
    qual = sorted([k for k in Fm if D.P(*k) >= 0.5], key=lambda k: D.ert(*k))
    cheap = qual[:3]
    h5a = cheap[0][0] == 'PS'; h5b = all(D.P(r, 'PS', -25) < D.P(r, r, -25) for r in ('GA', 'PSO'))
    n_ps_q = sum(1 for k in qual if k[0] == 'PS')
    H[5] = ('Supported, narrowly' if (h5a and h5b) else ('Partly supported' if (h5a or h5b) else 'Not supported'),
            f'Cheapest pairs with success ≥ 0.5: {", ".join(pr(*k) + " (" + ev(D.ert(*k)) + ")" for k in cheap)}; only {NUMW.get(n_ps_q, str(n_ps_q)).lower()} PS-first pairs qualify, and PS{ARW}SO ({D.P("PS", "SO"):.3f}) and PS{ARW}PS ({D.P("PS", "PS"):.3f}) fall just below 0.5. '
            f'At −25 dB, GA{ARW}PS {D.P("GA", "PS", -25):.2f} vs GA{ARW}GA {D.P("GA", "GA", -25):.2f}, PSO{ARW}PS {D.P("PSO", "PS", -25):.2f} vs PSO{ARW}PSO {D.P("PSO", "PSO", -25):.2f}.')
    h6_budget = flags['PAR'][0][0] == 1.0 and par_s2_other == 0
    h6_rest = max(p_s1('PAR')) < min(p_s1('PS')) and p_s2('PAR') < p_s2('PS') and cost['PAR']['e1'] > cost['PS']['e1'] and cost['PAR']['e2'] > cost['PS']['e2']
    H[6] = ('Supported' if (h6_budget and h6_rest) else ('Supported but for ' + NUMW.get(par_s2_other, str(par_s2_other)).lower() + ' runs' if h6_rest else 'Not supported'),
            f'Budget exhausted in all 12,960 Stage-1 runs and all but {par_s2_other} Stage-2 runs, which stopped on mesh size. Success as Stage 1 {rg(p_s1("PAR"))} vs {rg(p_s1("PS"))} for PS; as Stage 2 after GA or PSO {p_s2("PAR"):.2f} vs {p_s2("PS"):.2f}.')
    assert all(Fm[(r, m)] == 0 for r in ('SO', 'PAR') for m in S) and all(Fm[(r, 'SO')] == 0 for r in S), 'legacy zero claim'
    assert par_o[4] > by(psf, 'order', -20)[4] and all(par_o[o] < by(psf, 'order', -20)[o] for o in range(5, 13))
    nsup = sum(1 for k in H if H[k][0] == 'Supported')
    assert [k for k in H if H[k][0] == 'Supported'] == [1, 3]
    add(B(f'{tabref("hyp")} scores the hypotheses on the full run. The full run is a fresh data set: it shares no trial with the snapshot that suggested the hypotheses, although it repeats that snapshot’s sub-grid among its instances. '
          f'{NUMW.get(nsup, str(nsup))} of the six (H1 and H3) are supported as stated. H2 fails in one clause, because PAR at Stage 2 lowers the success of a PSO reference to {D.P("PSO", "PAR"):.2f}; '
          f'H4 holds for the means, but {100 * (1 - sa200[0]):.0f}% of SA’s Stage-1 runs use 200 evaluations or more; '
          f'H5 holds only narrowly, because PS at Stage 1 succeeds in about half of its trials; and H6 misses its “every run” by {NUMW.get(par_s2_other, str(par_s2_other)).lower()} runs. '
          f'The thresholds were written after the snapshot, so agreement on quantities that the snapshot already showed is weak evidence; the departures are the informative part.'))
    rowsH = [[f'H{k}', H[k][1], H[k][0]] for k in range(1, 7)]
    add(dlib.table('hyp', 'Hypotheses (exploratory) and the evidence from the full run.',
                   [380, 3466, 1020], ['', 'Evidence', 'Verdict'], rowsH, row_h=200, col_jc=['left', 'left', 'center']))

    # ================================================================== VI. Discussion
    add(h1('Discussion'))
    so1 = D.S1U[D.S1U.ref == 'SO']
    add(B('**Mechanisms.** ' + f'The ranking is first a ranking of Stage-1 solvers. PSO and GA end within {sci(cost["PSO"]["gap"])} and {sci(cost["GA"]["gap"])} of the convex baseline (medians), PS within {cost["PS"]["gap"]:.3f} and PAR within {cost["PAR"]["gap"]:.2f}, '
          f'whereas SO and SA end {cost["SO"]["gap"]:.2f} and {cost["SA"]["gap"]:.2f} from it. Two observations show that SO and SA barely leave their starting point. '
          f'The feasible-start sampler gives a median objective of {D.START_MED:.2f} (simulated with a Python port of the sampler, not read from the recorded starts), and the median final objective is {D.S1_OBJ_MED["SA"]:.2f} for SA and {D.S1_OBJ_MED["SO"]:.2f} for SO. '
          f'SA stops after a median of {D.S1_EV_MED["SA"]:.0f} evaluations and never fewer than {D.S1_EV_MIN["SA"]:.0f}, one more than its 60-iteration stall window. '
          f'SO stops after a median of {D.S1_EV_MED["SO"]:.0f} evaluations ({100 * D.SO_S1_LE230:.0f}% of runs use 230 or fewer); since our rule stops it 200 evaluations after the last improvement, '
          f'that improvement came within its initial sample of 20 to 26 points, and the surrogate phase improved nothing. '
          'These are observations. Their causes remain conjectures, because we varied neither the stall rules nor the penalty: for SA, a stall window shorter than the cooling time, and for SO, the penalty plateau distorting the surrogate. '
          f'SO’s success as a Stage-2 solver ({p_s2("SO"):.2f} after GA or PSO) under the same stall rule, on an objective that has no infeasible region, is consistent with the plateau explanation but does not test it. '
          f'PAR’s budget exits (H6) agree with the documented volume test never firing; its decline with order at a fixed budget suggests, but does not show, that the budget is too small for the larger problems.'))
    add(B('**Practice.** ' + f'For this pipeline the data favor spending effort on Stage 1. PSO or GA there is what the final error needs, and among GA, PSO, SO and PS the Stage-2 solver hardly matters at −20 dB: '
          f'after a GA or PSO reference they reach {p_s2("GA"):.2f}, {p_s2("PSO"):.2f}, {p_s2("SO"):.2f} and {p_s2("PS"):.2f}, with {ev(cost["GA"]["e2"])}, {ev(cost["PSO"]["e2"])}, {ev(cost["SO"]["e2"])} and {ev(cost["PS"]["e2"])} evaluations per run. '
          f'PSO{ARW}PS is then the economical choice in time ({sc(es("PSO", "PS"))} s per success) and PSO{ARW}SO in evaluations ({ev(D.ert("PSO", "SO"))}). '
          f'At −25 dB the Stage-2 solver matters: after a PSO reference, PSO and GA reach {P25[("PSO", "PSO")]:.2f} and {P25[("PSO", "GA")]:.2f} against {P25[("PSO", "PS")]:.2f} and {P25[("PSO", "SO")]:.2f} for PS and SO, '
          f'at {es("PSO", "PSO") / es("PSO", "PS"):.0f} and {es("PSO", "GA") / es("PSO", "PS"):.0f} times the time per success at −20 dB of PSO{ARW}PS. '
          f'If a success fraction near one half suffices, PS at Stage 1 cuts the evaluations per success by a factor of {D.ert("PSO", "SO") / D.ert("PS", "SO"):.0f} (PS{ARW}SO against PSO{ARW}SO), '
          f'but only {es("PSO", "PS") / es("PS", "PS"):.1f}× in seconds (PS{ARW}PS against PSO{ARW}PS), and the gain shrinks as ⟨ρ⟩ grows. '
          'SA at either stage, SO or PAR at Stage 1, and PAR at Stage 2 for the larger orders should be avoided under the settings used here.'))
    add(B('**Flags and outcomes.** ' + f'Stop-rule flags are not comparable across algorithms, and a metric built on them ranks stopping rules. '
          f'The legacy index places {pr(*top_F[0])}, whose success fraction at −20 dB is {D.P(*top_F[0]):.2f}, first, because SA always reports convergence and stops after about a hundred evaluations; '
          f'it gives zero to every pair with SO or PAR at Stage 1 and to every pair ending in SO, and its rank agreement with outcome is {D.KT_F_P20:.2f}.'))
    add(B('**Threats to validity.** The comparison is of algorithms under their own stopping rules, not at matched cost, and with settings fixed once for all ⟨N⟩ and ⟨ρ⟩; tuned settings or budgets could change the ranking, most plausibly for SA, SO and PAR. '
          'The study covers one lattice, one target family (a truncated series without a window), ⟨N⟩ = 4–12 and ⟨ρ⟩ = 0.2–0.5, and one toolbox release. '
          'Evaluation counts ignore per-iteration overhead, which is large for SO, so we also report seconds; these come from eight concurrent workers on each eight-vCPU virtual machine and are not isolated timings. '
          'Stage 1 is convex, so a convex method computes its optimum; we treat it as a black-box testbed and the convex baseline is a reference for Stage-1 gaps, not a floor for ⟨E⟩. '
          'Infeasible points receive the largest representable value, and other constraint handling could change the Stage-1 results. '
          'The tolerance ladder was fixed before the full run, but the passivity floor was computed afterwards and shows that most of the ladder is unattainable; '
          'a tolerance relative to the floor would compare instances more evenly, and the −20 dB results at ⟨N⟩ = 4, ⟨ρ⟩ = 0.5 reflect the instance, not the solvers. We do not show that the lattice attains the floor. '
          'The hypotheses and the mechanisms are exploratory. '
          f'The trials are paired and clustered, so the effective sample size is set by the 12,960 distinct Stage-1 configurations, not by 77,760, and three of those configurations were not reproduced exactly across the trials that share them.'))
    add(B('**Generalization and future work.** The pairing result should extend to other cascades in which a constrained first stage hands a solver-dependent target to a periodic second stage; the absolute costs will not. '
          'Natural extensions are a comparison at matched budget, ablations of the stall rules and of the penalty, a convex first stage with a global second stage, tolerances set relative to the passivity floor, and larger orders.'))

    # ================================================================== VII. Conclusion
    add(h1('Conclusion'))
    add(B(f'We compared six global optimizers at each stage of a two-stage design of a half-band Mach–Zehnder lattice filter, scoring all 36 pairings on success, error and cost over 108 operating points with 20 repeats. All {D.N_TRIALS:,} trials completed.'))
    add(B(f'The first-stage solver set the final error. With PSO or GA at Stage 1 and GA, PSO, SO or PS at Stage 2, {100 * min(lead_vals):.0f} to {100 * max(lead_vals):.0f}% of trials came within −20 dB of the target’s odd harmonics, and most of the failures fell on one instance whose attainable error sits at that tolerance; '
          f'with SO or SA at Stage 1 at most {100 * max(max(p_s1("SA")), max(p_s1("SO"))):.1f}% did. '
          f'PSO{ARW}SO was the cheapest reliable pair in evaluations ({ev(D.ert("PSO", "SO"))} per success) and PSO{ARW}PS in time ({sc(es("PSO", "PS"))} s per success), while PSO{ARW}PSO was the most accurate ({P25[("PSO", "PSO")]:.2f} at −25 dB, interval {ci(*b25[:2])}). '
          f'No trial came within {min(gapf.values()):.1f} dB of the passivity floor, and the convergence-flag index ranked the pairs almost independently of outcome (Kendall’s τ = {D.KT_F_P20:.2f}).'))
    add(B('For comparable designs we recommend PSO at the first stage, a cheap local or surrogate method at the second when −20 dB suffices, and a population method at the second when the tightest attainable error is wanted. '
          'This holds for the settings, orders and passband ratios studied; a matched-budget study and ablations of the stopping rules are the natural next steps.'))

    add(h5('Acknowledgment'))
    add(B(C('Optional: sponsor and funding acknowledgments go in the unnumbered footnote on the first page, as the template says. Delete this heading if there is nothing to acknowledge.')))
    add(h5('References'))
    add(dlib.reference_list())
    return ''.join(b)
