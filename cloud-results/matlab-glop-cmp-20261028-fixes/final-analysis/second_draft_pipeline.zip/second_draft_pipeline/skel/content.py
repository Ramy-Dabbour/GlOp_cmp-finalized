import json, re
from lib import *

OM = json.load(open('/home/claude/pp/skel/eq/omml.json'))
ET = json.load(open('/home/claude/pp/skel/etop_table.json'))
OM_KEYS = ['bound', 'D', 'decomp', 'delta', 'stage1', 'F', 'P', 'ERT', 'legacy', 'legacy2']

start = open('/mnt/user-data/uploads/Draft_Starting_Point.txt', encoding='utf8').read()
m_t = re.search(r'Title:\s*(.+)', start)
m_a = re.search(r'Abstract:\s*(.+)', start, re.S)
TITLE = m_t.group(1).strip()
ABSTRACT = re.sub(r'\s+', ' ', m_a.group(1)).strip()

KEYWORDS = ('global optimization; derivative-free optimization; benchmarking; photonic integrated circuits; '
            'Mach–Zehnder lattice; FIR filter synthesis; particle swarm optimization; surrogate optimization')

REFS_VERIFIED = [
    'K. Jinguji and M. Oguma, “Optical half-band filters,” J. Lightwave Technol., vol. 18, no. 2, pp. 252–259, Feb. 2000.',
    'K. Jinguji and M. Kawachi, “Synthesis of coherent two-port lattice-form optical delay-line circuit,” J. Lightwave Technol., vol. 13, pp. 73–82, Jan. 1995.',
    'K. Jinguji, N. Takato, Y. Hida, T. Kitoh, and M. Kawachi, “Two-port optical wavelength circuits composed of cascaded Mach–Zehnder interferometers with point-symmetrical configurations,” J. Lightwave Technol., vol. 14, pp. 2301–2310, Oct. 1996.',
    'J. H. Holland, Adaptation in Natural and Artificial Systems. Ann Arbor, MI, USA: Univ. Michigan Press, 1975.',
    'D. E. Goldberg, Genetic Algorithms in Search, Optimization & Machine Learning. Reading, MA, USA: Addison-Wesley, 1989.',
    'J. Kennedy and R. Eberhart, “Particle swarm optimization,” in Proc. IEEE Int. Conf. Neural Networks, vol. 4, Perth, Australia, 1995, pp. 1942–1948.',
    'H.-M. Gutmann, “A radial basis function method for global optimization,” J. Global Optim., vol. 19, pp. 201–227, Mar. 2001.',
    'R. G. Regis and C. A. Shoemaker, “A stochastic radial basis function method for the global optimization of expensive functions,” INFORMS J. Comput., vol. 19, pp. 497–509, 2007.',
    'S. Kirkpatrick, C. D. Gelatt, and M. P. Vecchi, “Optimization by simulated annealing,” Science, vol. 220, no. 4598, pp. 671–680, 1983.',
    'L. Ingber, “Adaptive simulated annealing (ASA): Lessons learned,” Control Cybern., 1995. [Online]. Available: https://arxiv.org/abs/cs/0001018.',
    'R. Hooke and T. A. Jeeves, “‘Direct search’ solution of numerical and statistical problems,” J. ACM, vol. 8, no. 2, pp. 212–229, Apr. 1961.',
    'C. Audet and J. E. Dennis Jr., “Analysis of generalized pattern searches,” SIAM J. Optim., vol. 13, no. 3, pp. 889–903, 2003.',
    'A. L. Custódio, J. F. A. Madeira, A. I. F. Vaz, and L. N. Vicente, “Direct multisearch for multiobjective optimization,” SIAM J. Optim., vol. 21, no. 3, pp. 1109–1140, 2011.',
    'The MathWorks, Inc., Global Optimization Toolbox User’s Guide, R2026a. Natick, MA, USA.',
    'A. V. Oppenheim and R. W. Schafer, Discrete-Time Signal Processing, 3rd ed. Upper Saddle River, NJ, USA: Prentice Hall, 2010.',
]
REFS_CANDIDATE = [
    'E. D. Dolan and J. J. Moré, “Benchmarking optimization software with performance profiles,” Math. Program., vol. 91, no. 2, pp. 201–213, 2002.',
    'N. Beiranvand, W. Hare, and Y. Lucet, “Best practices for comparing optimization algorithms,” Optim. Eng., vol. 18, no. 4, pp. 815–848, 2017.',
    'N. Hansen, A. Auger, R. Ros, O. Mersmann, T. Tušar, and D. Brockhoff, “COCO: A platform for comparing continuous optimizers in a black-box setting,” Optim. Methods Softw., vol. 36, no. 1, pp. 114–144, 2021.',
    'D. H. Wolpert and W. G. Macready, “No free lunch theorems for optimization,” IEEE Trans. Evol. Comput., vol. 1, no. 1, pp. 67–82, Apr. 1997.',
    'P. L’Ecuyer, R. Simard, E. J. Chen, and W. D. Kelton, “An object-oriented random-number package with many long streams and substreams,” Oper. Res., vol. 50, no. 6, pp. 1073–1075, 2002.',
    'S. Boyd and L. Vandenberghe, Convex Optimization. Cambridge, U.K.: Cambridge Univ. Press, 2004.',
]


def build_body(notes=True):
    """Return (front_xml, body_xml). front_xml = title block; body_xml = two-column flow."""
    N = notes
    b = []
    add = b.append

    # ------------------------------------------------------------------ front
    front_title = para('papertitle', run(TITLE))
    if N:
        front_title += note('Title', [
            'Pattern: [what is compared] for [the design task] in [the device class]. Name the algorithms or the pairing structure, not MATLAB. Your working title is kept above.',
            'Template rule: no symbols, special characters, footnotes or math in the title or the abstract.'])
    author = para('Author',
                  run('Ramy Dabbour') + '<w:r><w:br/></w:r>' +
                  run('Dept. of Electronics and Communications Engineering', i=True) + '<w:r><w:br/></w:r>' +
                  run('The American University in Cairo', i=True) + '<w:r><w:br/></w:r>' +
                  run('Cairo, Egypt') + '<w:r><w:br/></w:r>' + run('ramymdabbour@aucegypt.edu'),
                  '<w:spacing w:before="100" w:beforeAutospacing="1"/>')
    if N:
        author += note('Authors', plain='One author block is set up. For more authors, copy the block and set the columns of that section (Layout → Columns), as the template instructs.')

    # ------------------------------------------------------------------ abstract / keywords
    if N:
        add(note('Abstract · about 200 words, one paragraph', [
            'No citations, no equations, every abbreviation defined. Seven sentence slots, in this order:',
            '**1 Problem and device.** Name the filter class (a half-band Mach–Zehnder lattice) and why its design is an optimization problem.',
            '**2 Gap.** One claim the literature leaves open, stated as a missing comparison, not as a weakness of others.',
            '**3 Approach.** The decomposition and the pairing: six algorithms at each of two stages, 36 pipelines.',
            '**4 Protocol.** 9 FIR orders (4–12), 4 passband ratios, 3 seeds, 20 repeats, 77,760 trials [code]; plus the metric in words: the fraction of trials whose error above the half-band bound is within a stated tolerance, and the evaluations spent per success.',
            '**5 Headline result.** The best pair, its success rate at the main tolerance and its cost per success [final run].',
            '**6 Second finding.** The structural result: which stage drives the ranking, or whether the Stage-1 choice affects Stage-2 behavior [final run].',
            '**7 Implication and scope.** What a practitioner should do, and one limit.',
            'Your starting-point abstract is kept below. It predates the final protocol (orders 4–10, an ℓ2-norm error, a citation); rewrite it to these slots.']))
    abstract_p = para('Abstract', run('Abstract', i=True) + run('—') + run(ABSTRACT), '')
    add(abstract_p)
    add(para('Keywords', run('Keywords—') + run(KEYWORDS)))
    if N:
        add(note('Keywords', plain='Six to eight, from general to specific. The list above is the skeleton’s suggestion; edit freely.'))

    if N:
        add(note('How to use this file', [
            'Blue blocks like this one are skeleton notes (style “Skeleton note”). Gray “write here” fields are where your own text goes; typing replaces the gray text. Everything else is the conference template’s own formatting, so headings, figure and table numbers, and reference numbers update themselves.',
            'Tags: [code] taken from your program. [final run] fill from the complete 77,760-trial run. [verify] could not be confirmed from the files. [snapshot] a number from the 4,947-trial prefix: a diagnostic, never quote it.',
            '**Scope of the claim.** The defensible claim is a comparison of these six configured solver implementations, paired across this two-stage procedure, for this target and lattice family. Do not write it as a ranking of the underlying algorithms in general. Hypotheses formed after you looked at diagnostics are exploratory; say so.',
            '**Page budget (six to eight pages).** Abstract and I: 1.0. II: 1.0. III: 1.2. IV: 1.6. V: 2.0. VI and VII: 1.0. References: 0.5. If the venue caps you at six pages: move the solver-configuration table to an appendix or the repository README, shorten III to its summary table plus hypotheses, and merge IV-P6 and IV-P7.',
            'Prefilled tables and equations come from the skeleton and the program; recheck them against the code before you rely on them. The skeleton’s model sentences and the §0 decision table stay in the skeleton document.',
            'Before submission remove the notes (Home → Styles → right-click each “Skeleton note …” style → Select All Instances → Delete), or move your text into the clean copy, and replace the footer line as the conference tells you.']))

    # ------------------------------------------------------------------ I. Introduction
    add(h1('Introduction'))
    if N:
        add(note('Section I · about 0.75–1 page · five paragraphs'))
        add(note('I-P1 · The device, and why its design is an optimization problem', [
            'Describe the cascaded Mach–Zehnder lattice in two sentences: couplers set by angles, one shared phase pattern, outputs as polynomials in the delay variable. Cite Jinguji and Oguma [1]–[3].',
            'State the application your design documentation supports. Do not add applications you have not documented.',
            'End on the consequence: the filter response is a nonlinear, periodic function of the physical parameters, so synthesis is a search of a parameter space, not a solve for coefficients.']))
    add(slot('Write I-P1 here'))
    if N:
        add(note('I-P2 · The two-stage structure of the design task', [
            'Stage 1: the truncated sinc target is generally not realizable, because the power response must stay inside [0, 1]. The task is the nearest admissible coefficient vector. Say what “nearest” means (normalized ℓ2 distance) [code].',
            'Stage 2: fit the lattice angles and the shared phase to the Stage-1 reference. Unitarity holds for any angle, so Stage 2 has no feasibility barrier.',
            'The stages are coupled: the Stage-1 reference is the target Stage 2 must fit, so its quality and shape can change Stage-2 difficulty.']))
    add(slot('Write I-P2 here'))
    if N:
        add(note('I-P3 · Why solver choice is an open question', [
            'Name the solver families you test, and say that practitioners pick among them by habit or availability.',
            'Cite the benchmarking literature as the standard you follow or depart from, one sentence each: performance profiles (Dolan and Moré), best-practice guidance (Beiranvand et al.), the COCO platform (Hansen et al.), the no-free-lunch result (Wolpert and Macready) [verify citation details].',
            'State the gap, after you have searched for prior work on solver pairings in engineering pipelines (the benchmarking papers alone do not show that none exists): those studies rank optimizers on analytic functions or single-stage problems; they do not rank pairings across a pipeline in which the first stage hands the second a solver-dependent target.']))
    add(slot('Write I-P3 here'))
    if N:
        add(note('I-P4 · What this paper does, then the contributions', [
            'One sentence of method: six algorithms at each stage, 36 pairs, 9 FIR orders, 4 passband ratios, 3 seeds, 20 repeats, 77,760 trials [code].',
            'Contributions as a numbered list of 3–4 items, each checkable in the paper: (1) a controlled, reproducible protocol for pairwise stage comparison (feasible-start sampling, per-stage RNG substreams); (2) an end-to-end error that scores the realized lattice against the raw target, so the score does not depend on either solver’s intermediate reference; (3) an outcome-based success measure (the fraction of trials whose error above the half-band bound, δ, is within a tolerance from a dB ladder fixed in advance) with the expected cost per success, beside the legacy flag-based index and its sensitivity analysis; (4) an empirical ranking of the 36 pairs and the mechanisms behind it [final run].']))
    add(slot('Write I-P4 here, then the numbered contributions'))
    if N:
        add(note('I-P5 · Roadmap', plain='One sentence per section, II to VII, in order.'))
    add(slot('Write I-P5 here'))

    # ------------------------------------------------------------------ II. Problem formulation
    add(h1('Problem Formulation'))
    if N:
        add(note('Section II · about 1 page · six paragraphs, one figure, a symbol table', plain='This section defines every quantity the later sections score. Check it against the code last.'))
    add(h2('The Lattice and Its Half-Band Structure'))
    if N:
        add(note('II-P1 · The lattice and its notation', [
            'Define N (FIR order), the N+1 taps, the N+1 coupler stages, the coupler angle θ~k~, the shared phase φ, and the transfer coefficients T and K with T^2^ + K^2^ = 1 [code].',
            'The four power responses |S~11~|^2^, |S~12~|^2^, |S~21~|^2^, |S~22~|^2^ are polynomials in the delay variable. Say what a “lag coefficient” is in your convention.',
            'The lattice drawing and the two-stage pipeline go in the figure below, so the reader sees where each stage sits.']))
    add(slot('Write II-P1 here'))
    add(fig('Insert figure: the two-stage pipeline and the lattice', 'Pipeline: target → Stage 1 → admissible reference → Stage 2 → physical parameters; add the lattice drawing (couplers, delays, shared phase)'))
    if N:
        add(note('II-P1b · The half-band structure (state it explicitly)', [
            'The implemented stage delays are [2, …, 2, 1], followed by a fixed balanced output coupler [code]. Every power response R then satisfies R(ω + π) = 1 − R(ω): its mean is 1/2 and every nonconstant even harmonic is zero. Unitarity alone does not imply this. Cite Jinguji and Oguma for the half-band family, and say the code realizes it.',
            'Say what N means in this code: the raw-reference order, which gives N+1 tunable stages. The field polynomials reach degree 2N+1 and the power responses have lags through ±(2N+1), so do not call every realized response an order-N FIR response.',
            'Consequence for the targets: the raw target has mean t~0~ = ρ, so at ρ = 0.2, 0.3 and 0.4 the lattice cannot reach the mean or the target’s even harmonics. At ρ = 0.5 those two restrictions coincide with the lattice, though truncation ripple and the restricted parameterization can still prevent exact realization. All four ratios are valid test cases: half-band complementarity is a property of the lattice, not a requirement on the target.',
            'Give the bound and the table of E~topology~ by N and ρ below. A zero means only that this DC-and-parity bound vanishes, not that zero error is attainable.',
            'Define δ, the part of E the solvers control. Score success on δ, not on E and not on E − E~topology~: δ is comparable across ρ and N, whereas the plain excess is about δ^2^/(2·E~topology~) and so means different things at different ρ.',
            'Verified on the snapshot [snapshot] (repeat on the full run): every returned matrix obeys the half-band identity to 9e-16, no error falls below its bound, and the decomposition holds to 3e-16.',
            'State what the study therefore measures: approximation under an architectural constraint, with the constraint’s contribution separated from the optimizers’.']))
    add(slot('Write II-P1b here'))
    add(equation(OM['bound']))
    add(equation(OM['D']))
    add(equation(OM['decomp']))
    if N:
        add(note('Equation note', plain='Here g~k~ denotes the lattice’s odd-harmonic coefficients [verify its exact definition and normalization against the code] and t~k~ = 0 for k > N. Define both in the text next to the equation.'))
    add(equation(OM['delta']))
    rows = [[str(n)] + [f'{v:.3f}' for v in ET[str(n)]] for n in range(4, 13)]
    add(table('Half-band bound E~topology~ by order N and passband ratio ρ'.replace('~topology~', '~topology~'),
              [600, 1050, 1050, 1050, 1050], ['N', 'ρ = 0.2', 'ρ = 0.3', 'ρ = 0.4', 'ρ = 0.5'], rows, row_h=200))
    if N:
        add(note('Table note', plain='[computed from the two bound equations above; recompute from your code before use.] Reproduces the skeleton’s values at N = 4, 10, 12.'))
    add(h2('Target and Why It Is Not Realizable'))
    if N:
        add(note('II-P2 · The target', [
            'Give the target as the DC-first cosine series of an ideal low-pass with passband ratio ρ: t~0~ = ρ and t~k~ = 2ρ·sinc(ρk), where sinc is the normalized form, sin(πx)/(πx) [code]. The code applies no tapering window, so call it a truncated (rectangular-window) series, not a “windowed sinc” unless you add a window.',
            'The truncated series overshoots. A check over your full grid (N = 4–12, ρ = 0.2–0.5) found all 36 raw targets leave [0, 1], with minima near −0.06 to −0.12 and maxima near 1.06 to 1.17. Report the range from your own computation.']))
    add(slot('Write II-P2 here'))
    add(h2('Stage 1: Nearest Admissible Reference'))
    if N:
        add(note('II-P3 · Stage 1', [
            'Write the problem below: minimize ‖x − t‖~2~ / ‖t‖~2~ over x with x~0~ ∈ [0, 1], x~k~ ∈ [−1, 1], subject to 0 ≤ F(ω; x) ≤ 1 for all ω [code]. Number of variables: N+1.',
            'Describe the feasibility test: stationary points taken as the real roots in [−1, 1] of the derivative of the response written as a polynomial in cos ω, plus both endpoints, tolerance 1e-12 [code]. Call it a continuous-domain extrema test implemented with floating-point root finding. Do not call it certified exact; agreement with a dense grid is a diagnostic, not proof.',
            'If the eigenvalue solve inside the root finder fails to converge, the candidate is treated as inadmissible and takes the same penalty as any other infeasible point; report how often that happened [confirm against the final code, including whether the Stage-1 test is guarded too].',
            'Penalty: infeasible candidates return the largest representable double, so every solver sees a plateau outside the feasible set.',
            'Feasible start: draw DC first, uniformly on (0, 1); draw the other coefficients inside an L1 ball of radius min(x~0~, 1 − x~0~) centered at zero. This is not uniform over the admissible set. State the guarantee (the sum of absolute cosine coefficients ≤ min(x~0~, 1 − x~0~) keeps F in [0, 1]) and that it is a sufficient, conservative subset of the feasible set [code].',
            '**Convexity.** The objective is convex and the constraint is linear in x for every ω, so the feasible set is convex and the minimizer is unique. Say this in one sentence, say that you treat the problem as a black box on purpose, and point forward to Section VI. Give a convex baseline for each (N, ρ), checked for continuous feasibility, as the reference the Stage-1 solvers are measured against. It is a reference for Stage-1 gaps, not a floor for E. Cite a convex-optimization text.']))
    add(slot('Write II-P3 here'))
    add(equation(OM['stage1']))
    add(equation(OM['F']))
    add(h2('Stage 2: Lattice Fitting'))
    if N:
        add(note('II-P4 · Stage 2', [
            'Variables: N+1 angles and one shared phase, N+2 in total, each in [0, 1) and wrapped by mod 1 [code]. Say what the unit interval maps to physically [verify].',
            'Objective: the normalized Frobenius distance between the lag-coefficient matrices of the realized and the reference S-matrix power responses.',
            'Structural difference from Stage 1: because T^2^ + K^2^ = 1 for every angle, every candidate is physically valid, so there is no penalty plateau. The variables are periodic.']))
    add(slot('Write II-P4 here'))
    add(equation_placeholder('[equation: Stage-2 objective]'))
    add(h2('End-to-End Error'))
    if N:
        add(note('II-P5 · End-to-end error E', [
            'Define E as the normalized Frobenius distance between the realized lattice’s lag-coefficient matrix and the matrix built from the raw target, with no frequency sampling [code].',
            'Why it is needed: the Stage-2 objective measures fidelity to a reference that depends on the Stage-1 solver, so it cannot rank pairs. E is the common yardstick.',
            'What E measures: by Parseval’s identity, a normalized, integrated squared error over the four power responses. It is not maximum ripple, stopband attenuation or phase error. E cannot fall below the half-band bound of II-P1b, not the Stage-1 distance, and success is scored on δ, the part of E above that bound.',
            'The Stage-1 and final residuals add with a cross term, so never write final error as Stage-1 error plus Stage-2 error.']))
    add(slot('Write II-P5 here'))
    add(equation_placeholder('[equation: end-to-end error E]'))
    add(h2('Problem Instances and Symbols'))
    if N:
        add(note('II-P6 · Problem instances', [
            'Table of the factors: N ∈ {4, …, 12} (9 levels), ρ ∈ {0.2, 0.3, 0.4, 0.5}, seed ∈ {0, 1, 2}, repeats 20 [code]. Give the Stage-1 and Stage-2 variable counts as functions of N. State that all 36 solver pairs see the same instance grid.',
            'Add the symbol table the section needs; a first set of rows is prefilled, edit it.']))
    add(slot('Write II-P6 here'))
    add(table('Experimental factors',
              [1500, 1900, 1400],
              ['Factor', 'Levels', 'Count'],
              [['FIR order N', '4, 5, …, 12', '9'],
               ['Passband ratio ρ', '0.2, 0.3, 0.4, 0.5', '4'],
               ['Seed', '0, 1, 2', '3'],
               ['Repeats per seed', '20', '20'],
               ['Stage-1 solver', 'six algorithms', '6'],
               ['Stage-2 solver', 'six algorithms', '6'],
               ['Trials in total', '6 × 6 × 9 × 4 × 3 × 20', '77,760'],
               ['Variables', 'Stage 1: N + 1; Stage 2: N + 2', '—']],
              col_jc=['left', 'left', 'center']))
    add(table('Symbols',
              [900, 3900],
              ['Symbol', 'Meaning'],
              [['N', 'FIR order of the raw reference; N + 1 tunable stages'],
               ['ρ', 'passband ratio of the target'],
               ['t~k~', 'cosine-series coefficients of the target, DC first'],
               ['x', 'Stage-1 coefficient vector (N + 1 entries)'],
               ['θ~k~, φ', 'coupler angles and the shared phase (Stage 2)'],
               ['T, K', 'coupler transfer coefficients, T^2^ + K^2^ = 1'],
               ['E', 'end-to-end error against the raw target'],
               ['E~topology~', 'half-band bound on E'],
               ['δ', 'error above the bound, δ = √(E^2^ − E~topology~^2^)'],
               ['τ', 'tolerance on δ, in dB'],
               ['s(τ), n', 'successes within τ; trials per pair (2,160)']],
              col_jc=['center', 'left']))

    # ------------------------------------------------------------------ III. Algorithms
    add(h1('Optimization Algorithms'))
    if N:
        add(note('Section III · 1–1.5 pages · one comparison table', plain='This section is about mechanisms, not about a software package. Name the algorithm, never the toolbox function, in headings and in the analysis; name the implementation once, in Section IV.'))
    add(h2('Organizing Principle'))
    if N:
        add(note('III-P1 · Organizing principle', [
            'Say the six algorithms differ along four axes: what state the search carries (a population or a single point), whether it uses randomness, how it uses objective values (rank, surrogate model, mesh polling or acceptance probability), and how it treats the penalty plateau.',
            'Every algorithm is derivative-free and treats the objective as a black box with bounds. Say why: the Stage-1 plateau makes the objective non-smooth.']))
    add(slot('Write III-P1 here'))
    add(h2('The Six Algorithms'))
    if N:
        add(note('III-P2 to P7 · One paragraph per algorithm, the same five slots in the same order', [
            'Mechanism in two or three sentences, with the one update rule that defines it. Cite the original source.',
            'Information used: what it learns from each evaluation.',
            'Stage 1 behavior: what the penalty plateau does to it.',
            'Stage 2 behavior: what periodic, unconstrained variables do to it.',
            'Testable prediction, written as a hypothesis (H1–H6) that Section V confirms or refutes.']))
        add(note('Genetic algorithm (Holland; Goldberg)', [
            'Selection, crossover, mutation, elitism. Plateau effect: infeasible offspring all tie at the penalty value, so selection pressure among them vanishes. Prediction: slow, evaluation-heavy convergence that rarely reaches a tolerance-based stop.']))
    add(slot('Write the genetic-algorithm paragraph'))
    if N:
        add(note('Particle swarm (Kennedy and Eberhart)', [
            'Velocity update with inertia, personal-best and global-best attraction: v ← ωv + c~1~r~1~(p − x) + c~2~r~2~(g − x). Plateau effect: personal and global bests remain at feasible points once the swarm is seeded feasibly, which anchors the swarm. Prediction: reliable convergence at high evaluation cost.']))
    add(slot('Write the particle-swarm paragraph'))
    if N:
        add(note('Surrogate optimization (Gutmann; Regis and Shoemaker)', [
            'Radial-basis surrogate of all evaluated points; the next point minimizes a merit function that trades predicted value against distance from evaluated points. Plateau effect: a penalty of the largest representable double distorts or breaks a radial-basis fit [verify in the toolbox documentation how non-finite and extreme values are handled]. Prediction: very few evaluations, sensitive to the penalty.',
            'Its 1e-10 ObjectiveLimit cannot be reached when the optimum residual is nonzero, so runs end by budget or by the stall callback.']))
    add(slot('Write the surrogate-optimization paragraph'))
    if N:
        add(note('Simulated annealing (Kirkpatrick et al.; Ingber)', [
            'One trajectory; a worse point is accepted with probability exp(−Δ/T) under a cooling schedule, with periodic reannealing. Plateau effect: from a feasible start, a move into the plateau has an enormous Δ and is essentially never accepted, so the walk stays feasible. Prediction: cheap, and sensitive to the stopping window relative to the cooling rate.']))
    add(slot('Write the simulated-annealing paragraph'))
    if N:
        add(note('Pattern search (Hooke and Jeeves; Audet and Dennis)', [
            'Poll a fixed stencil of points around the incumbent; move on improvement, shrink the mesh otherwise. Plateau effect: the mesh contracts at the feasible boundary, acting as a hard wall. Prediction: deterministic given the start, cheapest, but confined to the starting basin on a periodic landscape.']))
    add(slot('Write the pattern-search paragraph'))
    if N:
        add(note('Pareto search (Custódio et al., direct multisearch)', [
            'Built for several objectives: it keeps a set of non-dominated points and polls around them. With one objective the non-dominated set shrinks to the best point(s), so it acts as a population-seeded pattern search [verify against the algorithm description].',
            'Say that this is a single-objective use of a solver built for several objectives (the implementation has a scalar branch [verify]) and that the best member of the returned set is taken as the solution.',
            'Prediction, to test and not to assume: with this mesh tolerance it usually exhausts its 20,000-evaluation budget. A reviewer reports a scalar convergence branch that can return +1, so treat exit 0 as a property of this configuration [verify in the implementation].']))
    add(slot('Write the Pareto-search paragraph'))
    add(h2('Summary and Hypotheses'))
    if N:
        add(note('III-P8 · Summary table', plain='Columns: algorithm; search state; randomness; information used; plateau handling; termination rule used in this study. Six rows, one line each. Keep it factual; no performance claims.'))
    add(table('Summary of the six algorithms',
              [1000, 600, 700, 1000, 760, 780],
              ['Algorithm', 'State', 'Random', 'Information', 'Plateau', 'Stop rule'],
              [['Genetic algorithm', '', '', '', '', ''],
               ['Particle swarm', '', '', '', '', ''],
               ['Surrogate optimization', '', '', '', '', ''],
               ['Simulated annealing', '', '', '', '', ''],
               ['Pattern search', '', '', '', '', ''],
               ['Pareto search', '', '', '', '', '']],
              row_h=330, col_jc=['left'] + ['left'] * 5))
    if N:
        add(note('III-P9 · Hypotheses', plain='List H1–H6 in one compact block or one sentence each, so Section V can answer them one by one. Phrase each as a comparison that the data can refute, and label them exploratory if you write them after inspecting diagnostics.'))
    add(slot('Write III-P9 here (H1–H6)'))

    # ------------------------------------------------------------------ IV. Methodology
    add(h1('Experimental Methodology'))
    if N:
        add(note('Section IV · 1.5–2 pages · nine paragraphs, two tables, a few equations', plain='Everything a reader needs to reproduce a number in Section V must be here.'))
    add(h2('Design and Replication'))
    if N:
        add(note('IV-P1 · Factorial design and replication', [
            'Factors and levels: solver at Stage 1 (6) × solver at Stage 2 (6) × FIR order (9) × passband ratio (4) × seed (3) × repeats (20) = 77,760 trials, 2,160 per pair [code].',
            'What seed and repeat control: the target depends only on (N, ρ), so all randomness comes from the solvers and their starting points. Each (seed, repeat) pair selects one random stream, giving 60 streams per (N, ρ, pair). Separately seeded streams carry no guaranteed separation, so claim only what the construction guarantees.',
            'Paired structure: the stream for a stage depends only on (seed, repeat, stage), so every solver pair sees the same stream at the same stage. Stage 2’s stream is independent of which Stage-1 solver ran [code]. This allows paired comparisons and isolates Stage-2 randomness from Stage-1 consumption.']))
    add(slot('Write IV-P1 here'))
    if N:
        add(note('IV-P1a · Dependence structure', [
            'The same Stage-1 solve is reused for each of the six Stage-2 choices, so the 77,760 trials contain 12,960 distinct Stage-1 configurations (6 solvers × 36 instances × 60 labels). The saved Stage-1 evaluation counts confirm this: they are identical across the six Stage-2 solvers for a given trial.',
            'The trials are paired and clustered, not 77,760 independent problems. Recomputing the Stage-1 solve is deliberate (each trial is a fresh full pipeline) but does not multiply independent evidence.']))
    add(slot('Write IV-P1a here'))
    add(h2('Initialization and Solver Configuration'))
    if N:
        add(note('IV-P2 · Initialization protocol', [
            'Stage 1: one start drawn uniformly from the feasible L1-ball subset; population methods receive that point as their first member and feasible samples for the rest; single-point methods use it directly [code]. Give the sampling recipe in one sentence (DC uniform on (0, 1); remaining coefficients uniform in an L1 ball of radius min(DC, 1 − DC)).',
            'Stage 2: uniform in [0, 1]^N+2^.',
            'Consequence: the start is provably feasible, but later candidates are not certified. In the snapshot all 4,947 returned references were valid, so validity does not discriminate between solvers [snapshot; recompute]. Report it once and move on. Do not claim unbiased sampling of all admissible filters.']))
    add(slot('Write IV-P2 here'))
    if N:
        add(note('IV-P3 · Solver configuration', [
            'One row per algorithm: starting set, population size, every stopping setting [code]. n is the number of variables, N+1 in Stage 1 and N+2 in Stage 2.',
            'The budgets are native and unequal on purpose: each algorithm stops by its own rule under an iteration or evaluation cap, so the comparison reflects each algorithm as a practitioner would run it. An equal-evaluation-budget comparison is a different question; note it as future work.',
            'All runs are serial inside a trial (the parallelism is across trials), which keeps counts comparable.']))
    add(slot('Write IV-P3 here'))
    add(table('Solver configuration (n = number of variables)',
              [1000, 1050, 950, 1800],
              ['Algorithm', 'Start', 'Population', 'Stopping settings'],
              [['Genetic algorithm', 'common start + feasible/uniform samples', 'max(80, 20n)', 'MaxGenerations 2000 (S1) / 200 (S2); stall 60 generations; tolerance 1e-10'],
               ['Particle swarm', 'common start + feasible/uniform samples', 'max(100, 20n)', 'MaxIterations 2000; stall 60 iterations; tolerance 1e-10'],
               ['Surrogate optimization', 'common start + max(20, 2n) initial points', 'surrogate-driven', '4,000 evaluations; 400 s; ObjectiveLimit 1e-10; custom stop after 200 evaluations without improvement beyond 1e-10 · max(1, |best|)'],
               ['Simulated annealing', 'common start', 'single point', 'MaxIterations 2000; stall 60 iterations; 20,000 evaluations; reanneal every 100; tolerance 1e-10'],
               ['Pattern search', 'common start', 'single point', 'MaxIterations 200; opportunistic poll and search; tolerance 1e-10'],
               ['Pareto search', 'common start + feasible/uniform samples', 'max(100, 20n)', '20,000 evaluations; 400 iterations; 400 s; mesh tolerance 1e-6; min poll fraction 0; constraint tolerance 1e-10']],
              row_h=300, col_jc=['left', 'left', 'left', 'left']))
    if N:
        add(note('Table note', plain='[code] Rows are copied from the skeleton; confirm each setting against the configuration files.'))
    add(h2('Success Measures'))
    if N:
        add(note('IV-P4 · Exit flags and the success rule', [
            'Tabulate, per algorithm, what each exit flag means, taken from the documentation (the shares of runs go to the results table) [final run]. Include surrogate optimization’s −1 (stopped by the output function), annealing’s 1 (stall tolerance) and 0 (iteration or evaluation cap), and Pareto search’s 0 (budget exhausted).',
            'State the rule you adopt: success means both stages are valid and δ, the error above the half-band bound, is at most τ, for τ values (a dB ladder, −20 to −60 dB in 5 dB steps) fixed in advance in a written analysis plan.',
            'Say what a positive flag does and does not mean. A flag reports that the solver’s own rule fired; it does not report accuracy. Keep the legacy score, labelled as legacy; do not interpret it as solution quality.',
            'Treat any remaining exceptions (no result produced) as failures and report their count by identifier. A telemetry error no longer ends a trial, and a failed eigenvalue solve in the feasibility test is a penalized candidate, not an exception; say so.']))
    add(slot('Write IV-P4 here'))
    add(table('Exit flags and what they mean (from the documentation)',
              [1300, 600, 2900],
              ['Algorithm', 'Flag', 'Meaning'],
              [['Genetic algorithm', '', ''],
               ['Particle swarm', '', ''],
               ['Surrogate optimization', '−1', 'stopped by the output function (stall callback)'],
               ['Simulated annealing', '1', 'stall tolerance'],
               ['Simulated annealing', '0', 'iteration or evaluation cap'],
               ['Pattern search', '', ''],
               ['Pareto search', '0', 'budget exhausted']],
              row_h=260, col_jc=['left', 'center', 'left']))
    if N:
        add(note('IV-P4a · Four events, not one', [
            'Name four separate events: the solver returned; its output is valid; it met its own convergence test; its achieved error is acceptable. They need not coincide. Budget exhaustion can return an excellent design, and stagnation a mediocre one.',
            '**Acceptable error.** Define it as δ = √(E^2^ − bound^2^), the part of E above the half-band bound, in dB as 20 log~10~ δ. The bound is fixed by the target and the architecture, so it does not depend on which solvers entered the study, and δ is comparable across ρ and N. The plain excess E − bound is not: it is about δ^2^/(2·bound), so one absolute excess is a looser target at ρ = 0.2 than at ρ = 0.4, and at ρ = 0.5 the bound is zero.',
            '**The ladder.** Use an application tolerance if you have one. Otherwise fix a ladder before the full data are opened: −20 to −60 dB in 5 dB steps, with the 10 dB subset (−20, −30, −40, −50, −60) in the main table and the other rungs in the supplement. The ladder does not depend on the instance and is log-spaced, as in COCO-style benchmarking; only its step size was informed by the snapshot, and the plan says so. Report P(τ) at each rung and show the whole curve of P against τ beside the table.',
            'Snapshot, to disclose and not to quote [snapshot; recompute on the full run]: in the snapshot (ρ = 0.2, seed 0, orders 4–10) the best δ found in any instance was 0.029–0.051 (−31 to −26 dB), and for GA→GA and PSO→pattern search success fell from about 97–98% at −20 dB to about 45–47% at −25 dB and 0% at −30 dB. Rungs that no pair reaches separate nothing, so report the best δ per instance beside the ladder.',
            'The gap to the best E found in the same instance is a secondary, descriptive criterion, because it depends on which solvers were run. A best-observed value is an empirical reference, not a certified optimum. Any τ chosen after seeing results is exploratory; say so, and say if the ladder was set after looking at part of the data.',
            '**Cost per success.** Total evaluations (or seconds) over all runs of the pair, failures included, divided by the number of successes. It is undefined when a pair has no success, and it can be many times the mean cost of a successful run, so show both. Evaluation counts are incomplete for trials that ended early (flagged cost_incomplete); say how many, because they undercount the cost of failures. Seconds are recorded for every trial.',
            'Judge each stage against its own reference as well. Stage 1: the gap to the convex projection, computed to a stated tolerance. Stage 2: the gap to the best result among the six Stage-2 solvers that share the same Stage-1 solution. Do not use E both as the success gate and as a term in an index.',
            'Record the termination reason (for example, a callback stop) separately from the exit flag.']))
    add(slot('Write IV-P4a here'))
    if N:
        add(note('IV-P5 · Success, cost and the legacy index', [
            'Define the primary measures per pair (i, j), each over its n = 2,160 trials. Success at tolerance τ (in dB) means both stages are valid and δ = √(E^2^ − bound^2^) is at most 10^τ/20^. P(τ) = s(τ)/n is the success fraction. The expected cost per success, ERT(τ), is the total evaluations (or seconds) over all n trials, Stage 1 plus Stage 2, failures included, divided by s(τ); it is infinite when s(τ) = 0 [code].',
            'Define the legacy index F separately and label it legacy: success is both exit flags positive and both outputs valid; the means of E and C are over those successes only, and P is over all trials. Conventions: pairs with no legacy success score 0; pairs whose mean cost is at most 1 or whose error is not finite are marked invalid [code].',
            'Justify each term of F in one sentence: P rewards reliability, 1/E rewards accuracy, 1/ln C rewards economy while compressing a range that spans orders of magnitude. State why a logarithm and why natural.',
            'State what F is not: a relative ranking on this problem family, not an absolute quality measure; E and C are conditional on success, while P is not.']))
    add(slot('Write IV-P5 here'))
    add(equation(OM['P']))
    add(equation(OM['ERT']))
    add(equation(OM['legacy']))
    add(equation(OM['legacy2']))
    if N:
        add(note('Equation note', plain='Here s~ij~(τ) is the number of successes of pair (i, j), n = 2,160, C~t~^(1)^ and C~t~^(2)^ are the costs of the two stages in trial t, and S~ij~ is the set of legacy successes. Define them in the text.'))
    if N:
        add(note('IV-P5a · Limits of the index to state', [
            'For the legacy index, give the sensitivity so the trade-off is explicit: d ln F = d ln P − d ln E − d ln C / ln C. Changing the logarithm’s base multiplies every score by a constant and cannot change the order.',
            'In the legacy index, E and C are averaged over accepted designs only. Expensive failed runs do not raise C, a pair can be averaged over a different and easier set of instances than another, and few accepted outcomes give unstable means. C is not the expected compute per acceptable design; ERT(τ) is.',
            'Display P(τ), ERT in evaluations and in seconds, the legacy flag-based P and F, and the non-dominated pairs side by side.',
            'A high F does not mean “most accurate” or “best optical design”. Say what the index rewards [snapshot] on the legacy rule, SA→SA ranked first with a worse final error than the GA and PSO pairs; recompute.',
            'P(τ) depends on τ. Show the whole curve of P against τ and a table at the pre-specified values, and say where two pairs swap order between τ values.',
            'A success is not a certificate of optimality. The best δ found in an instance is positive [snapshot] 0.029–0.051, −31 to −26 dB. The data do not say whether that remainder is the Stage-1 projection residual, the lattice’s limited freedom in the odd harmonics, or solver error; say so.',
            'Report block-bootstrap intervals for P(τ) and ERT(τ) (see IV-P7). A bootstrap replicate with no success has no ERT, so state how many replicates were dropped at each τ.']))
    add(slot('Write IV-P5a here'))
    add(h2('Robustness and Statistical Treatment'))
    if N:
        add(note('IV-P6 · Robustness of the ranking to the index', [
            'Show that the ranking does not hinge on the formula. Recompute with variants such as exponents on each term, or ln C replaced by C or by a rank, and report the rank correlation (Kendall’s τ) between each variant and the baseline.',
            'Report the non-dominated pairs in the three-dimensional space (P, E, C) as a scale-free cross-check of the scalar ranking.',
            'Add performance profiles for cost (Dolan and Moré) if space allows.']))
    add(slot('Write IV-P6 here'))
    if N:
        add(note('IV-P7 · Statistical treatment', [
            'Unit of analysis: one trial. Clustering: trials within a seed and within an instance are not independent. Give confidence intervals by a bootstrap that resamples whole seed/repeat blocks across pairs and instances, because the design is paired. Do not apply Wilson intervals to the pooled sample unless you can justify independence.',
            'Say how you pool across N and ρ and show per-N results where they differ, since cost and error can change with dimension.',
            'Say how you handle 36 comparisons: report effect sizes with intervals and avoid unadjusted significance claims, or apply a stated correction.']))
    add(slot('Write IV-P7 here'))
    add(h2('Implementation and Validation'))
    if N:
        add(note('IV-P8 · Implementation, parallel execution and reproducibility', [
            'Software: MATLAB R2026a with the Global Optimization Toolbox and the Parallel Computing Toolbox. Name the version once, here.',
            'Execution: a process-based pool; one trial per worker task; each solver runs serially inside the trial. The random numbers do not depend on scheduling because each trial draws from its own deterministic stream. Full solver outputs can still differ across hardware or load when the 400 s limits bind, so do not claim bitwise invariance.',
            'Random numbers: the MRG32k3a generator, with one substream per (seed, repeat, stage). Cite L’Ecuyer et al. (2002) for streams and substreams.',
            'Fault tolerance: one atomic checkpoint per trial, a manifest with a source hash that refuses to mix results from different code versions, and a resume path. The trial code was changed for reliability before the full run (best-effort telemetry, retried live-record writes, a guarded eigenvalue solve), so the full run uses a fresh results folder and the snapshot is not pooled. Mention batch-shard mode only if you used it for the reported run.',
            'Hardware and time: processor, cores, memory, workers, concurrency, total wall-clock time, trials per hour (seconds from concurrent runs on one device are not isolated timings) [final run].',
            'Availability: repository or archive link and the exact commit or hash [verify].']))
    add(slot('Write IV-P8 here'))
    if N:
        add(note('IV-P9 · Validation of the pipeline', [
            'Include only checks you have actually run, each in one sentence.',
            'The feasibility test agrees with a dense frequency grid on a sample of random candidates [verify].',
            'Re-running a trial reproduces its outputs, and a different worker count does not change results where no time limit binds [verify].',
            'Aggregated tables rebuilt from the per-trial checkpoints match the exported summary [snapshot] every favorability entry matched benchmark_results.csv to four decimals; repeat on the full run.',
            'Every end-to-end error is at least its half-band bound [snapshot] confirmed on the 4,938 returned matrices; repeat on the full run.']))
    add(slot('Write IV-P9 here'))

    # ------------------------------------------------------------------ V. Results
    add(h1('Results'))
    if N:
        add(note('Section V · about 2 pages · five or six exhibits', plain='Do not write this section from the 4,947-trial snapshot. It is fixed here as claims and the evidence each needs, so you can draft it the moment the full run exists. Every sentence should state a number with its denominator and an interval, then say what it means. Build the exhibits first; write the prose around them.'))
    add(h2('Coverage and Exit Flags'))
    if N:
        add(note('V-R1 · Coverage and data quality · one short paragraph', [
            'Report trials completed out of 77,760, the exception count and rate, and any trials excluded, with the reason.',
            'Split exceptions by identifier. Telemetry errors no longer end a trial, and a failed eigenvalue solve is a penalized candidate, so report any residual exceptions by class and say that the earlier snapshot is excluded.']))
    add(slot('Write V-R1 here'))
    if N:
        add(note('V-R2 · What the exit flags report', [
            'The flag-share table comes first, because it conditions how the legacy P is read.',
            'State, for each algorithm, the share of runs ending in each flag. Say which algorithms essentially always stop by their own tolerance rule and which essentially always stop at a cap. Say what follows for the legacy P in one sentence, so the reader does not mistake P for accuracy.',
            'Exhibit data: exit flags, already saved [final run].']))
    add(slot('Write V-R2 here'))
    add(table('Share of runs ending in each exit flag, by algorithm and stage',
              [1500, 700, 800, 1800],
              ['Algorithm', 'Stage', 'Flag', 'Share of runs (%)'],
              [[a, s, '', ''] for a in ('Genetic algorithm', 'Particle swarm', 'Surrogate optimization', 'Simulated annealing', 'Pattern search', 'Pareto search') for s in ('1', '2')],
              row_h=220, cap_slot=False, col_jc=['left', 'center', 'center', 'center']))
    add(h2('Headline Ranking'))
    if N:
        add(note('V-R3 · The headline ranking', [
            'Exhibits: the 6 × 6 matrices of P(τ) at the pre-specified τ values and of ERT(τ), with the legacy F beside them; and heat maps of P(τ), ERT(τ), mean evaluations and F on the same grid. Data: per-trial validity, E, δ, evaluations and seconds for all 77,760 trials.',
            'Name the pair with the highest P(τ) at each pre-specified τ and the pair with the lowest ERT(τ), with intervals, and say whether they are the same pair. Give the legacy F ranking in one sentence and say how it differs. Name the worst pair as an anchor.',
            'State how many of the 36 pairs score 0 under the legacy rule and why [snapshot] 20 of 36; recompute.']))
    add(slot('Write V-R3 here'))
    mat_w = [820] + [660] * 6
    solv = ['GA', 'PSO', 'SO', 'SA', 'PS', 'PaS']
    add(table('Success fraction P(τ) at the main tolerance, by Stage-1 (rows) and Stage-2 (columns) solver',
              mat_w, ['S1 \\ S2'] + solv, [[s] + [''] * 6 for s in solv], row_h=260, cap_slot=False))
    add(table('Expected cost per success ERT(τ) in evaluations, same layout',
              mat_w, ['S1 \\ S2'] + solv, [[s] + [''] * 6 for s in solv], row_h=260, cap_slot=False))
    if N:
        add(note('Table note', plain='Duplicate for seconds and for the legacy F, and for each τ you report (the 10 dB subset goes in the main text, the other rungs in a supplement). Define the abbreviations at first use.'))
    add(fig('Insert figure: heat maps on the 6 × 6 grid', 'Heat maps of P(τ), ERT(τ), mean evaluations and the legacy F on the same 6 × 6 grid of Stage-1 by Stage-2 solver'))
    add(h2('Accuracy, Cost and Reliability'))
    if N:
        add(note('V-R4 · Accuracy', [
            'Exhibits: δ in dB against seconds and against evaluations (log axis for cost), one point per pair, non-dominated pairs marked; and P against τ on the dB axis, one curve per pair or for the top pairs. Data: δ for all returned designs, from the analysis script (computable from the checkpoints).',
            'Report the spread of E across pairs relative to its absolute level. If the spread is small, say that accuracy barely separates the pairs and that cost and reliability decide the ranking.',
            'Report the half-band bound and δ, by ρ. At ρ = 0.2, 0.3 and 0.4 most of E is the bound, so plot δ in dB, not raw E and not the plain excess, which is not comparable across ρ.']))
    add(slot('Write V-R4 here'))
    add(fig('Insert figure: error against cost', 'δ in dB against seconds and against evaluations (log axis for cost), one point per pair, non-dominated pairs marked'))
    add(fig('Insert figure: P against τ', 'P against τ on the dB axis, one curve per pair or for the top pairs'))
    if N:
        add(note('V-R5 · Cost', [
            'Report C and ERT(τ) by Stage-1 solver and by Stage-2 solver. State which stage contributes most of the total.',
            'Report elapsed seconds per stage beside evaluations. [snapshot] surrogate optimization’s 321 evaluations took 25 s in one saved trial, so evaluations alone understate its cost.']))
    add(slot('Write V-R5 here'))
    if N:
        add(note('V-R6 · Reliability', plain='Report P(τ) by solver and stage, with block-bootstrap intervals (IV-P7), and keep the stop-rule convergence share beside it as a separate column.'))
    add(slot('Write V-R6 here'))
    add(h2('Cross-Stage Coupling'))
    if N:
        add(note('V-R7 · Cross-stage coupling · this is the paper’s distinctive result, so give it its own paragraph', [
            'Exhibit: Stage-2 cost and P(τ) by Stage-1 solver, per Stage-2 solver. Data: stage-wise evaluation counts, already saved.',
            'Test whether the Stage-1 solver changes Stage-2 cost, success or final error for a fixed Stage-2 solver, using paired comparisons across the shared random substreams.',
            'State the direction and size, and offer one mechanism (for example, a reference with a different geometry gives Stage 2 a harder or easier target). Mark it as a hypothesis unless you tested it.']))
    add(slot('Write V-R7 here'))
    add(fig('Insert figure: Stage-2 cost and success by Stage-1 solver', 'Stage-2 cost and P(τ) by Stage-1 solver, for each Stage-2 solver'))
    add(h2('Order and Passband Ratio'))
    if N:
        add(note('V-R8 · Dependence on order and passband ratio', [
            'Exhibit: δ, ERT(τ) and P(τ) against FIR order for the top pairs. Data: per-N aggregates with intervals.',
            'Report whether rankings are stable across N = 4–12 and ρ = 0.2–0.5, and name any crossover.']))
    add(slot('Write V-R8 here'))
    add(fig('Insert figure: results against FIR order', 'δ, ERT(τ) and P(τ) against FIR order for the top pairs'))
    add(h2('Robustness and Hypotheses'))
    if N:
        add(note('V-R9 · Robustness to the index', plain='Exhibit: rank correlation of F with each index variant, and of the ERT(τ) ranking across τ. Report the rank correlations and the pairs that stay in the non-dominated set under every variant.'))
    add(slot('Write V-R9 here'))
    add(table('Rank correlation of the baseline ranking with each index variant',
              [2000, 1500, 1300],
              ['Variant', 'Kendall’s τ', 'Top pairs unchanged'],
              [['Baseline', '1', ''], ['', '', ''], ['', '', ''], ['', '', ''], ['ERT(τ) across τ', '', '']],
              row_h=240, col_jc=['left', 'center', 'center']))
    if N:
        add(note('V-R10 · Hypotheses scoreboard', plain='H1–H6, the evidence, and supported, refuted or inconclusive. Keep refuted hypotheses; they are results.'))
    add(table('Hypotheses and their outcome',
              [950, 2450, 1400],
              ['Hypothesis', 'Evidence', 'Outcome'],
              [[f'H{k}', '', ''] for k in range(1, 7)],
              row_h=260, col_jc=['center', 'left', 'center']))
    add(slot('Write V-R10 here'))

    # ------------------------------------------------------------------ VI. Discussion
    add(h1('Discussion'))
    if N:
        add(note('Section VI · 0.75–1 page · five paragraphs', plain='Interpretation belongs here and nowhere earlier; Section V reports and does not explain.'))
        add(note('VI-D1 · Mechanisms behind the ranking', [
            'Take each result of Section V in turn and give the mechanism from Section III that accounts for it. Mark each mechanism as tested or as conjecture. Tie back to H1–H6 by number.']))
    add(slot('Write VI-D1 here'))
    if N:
        add(note('VI-D2 · What the cross-stage effect means in practice', [
            'State the pairing you would recommend, the condition under which the recommendation holds, and the condition under which it reverses.',
            'Say which of the two stages deserves the larger share of a practitioner’s tuning effort, if the data say so.']))
    add(slot('Write VI-D2 here'))
    if N:
        add(note('VI-D3 · Convergence flags and outcomes', [
            'State the lesson plainly: stop-rule flags are not comparable across algorithms, and a metric built on them ranks stopping rules. Show how the ranking by P(τ) and ERT(τ) differs from the legacy ranking.']))
    add(slot('Write VI-D3 here'))
    if N:
        add(note('VI-D4 · Threats to validity', [
            'A compact list; each item states the threat and what you did or did not do about it.',
            '**Convexity of Stage 1.** The Stage-1 objective is convex and its constraints are linear in the coefficients, so the optimum is a Euclidean projection that convex methods can compute to a stated tolerance. Say that the study treats Stage 1 as a black-box testbed and that a convex baseline, checked for continuous feasibility, can serve as the reference for Stage-1 gaps, not as the floor for E. Do not claim that Stage 1 requires a global optimizer.',
            '**Half-band architecture.** Results describe approximation under that constraint. Targets at ρ ≠ 0.5 are valid test cases that the lattice can only approximate. Report δ, the error above the bound, and say that the floor comes from the architecture, not from the optimizers.',
            '**Infrastructure failures.** In the snapshot, telemetry failures were counted as scientific failures. The program now treats telemetry publication as best-effort, so none should remain in the full run; report any that do, separately.',
            'The other items are self-explanatory from the labels below.']))
    threats = [
        ('Convexity of Stage 1.', 'threat, and what you did'),
        ('Unequal native budgets.', 'the comparison is of algorithms under their own stopping rules, not at matched cost'),
        ('Untuned settings.', 'settings were fixed once for all N and ρ; tuned settings could change the ranking'),
        ('One problem family.', 'one lattice, one target type, N = 4–12, ρ = 0.2–0.5'),
        ('Implementation dependence.', 'results describe one toolbox release, R2026a'),
        ('Cost measure.', 'evaluations ignore per-iteration overhead'),
        ('Penalty handling.', 'infeasible points are penalized to the largest representable value; other constraint handling could change the Stage-1 results'),
        ('Target definition.', 'the target is a truncated series without a tapering window'),
        ('Half-band architecture.', 'threat, and what you did'),
        ('Exploratory hypotheses.', 'H1–H6 and any mechanism offered after inspecting diagnostics are exploratory unless fixed beforehand'),
        ('Clustered design.', 'the effective sample size is set by distinct Stage-1 runs, not by 77,760'),
        ('Concurrency.', 'wall-clock times come from concurrent runs on one device'),
        ('Infrastructure failures.', 'threat, and what you did'),
    ]
    for lead, lab in threats:
        add(bullet_slot(lead, lab))
    if N:
        add(note('VI-D5 · Generalization and future work', [
            'Say which findings should transfer to other two-stage pipelines (a constrained first stage feeding a periodic second stage) and which are specific to this lattice.',
            'Name two or three concrete extensions: matched-budget comparison, hybrid global-then-local pipelines, convex first stage with global second stage, larger orders.']))
    add(slot('Write VI-D5 here'))

    # ------------------------------------------------------------------ VII. Conclusion
    add(h1('Conclusion'))
    if N:
        add(note('Section VII · about 0.25 page · three short paragraphs; no new facts and no citations'))
        add(note('VII-C1 · Restate the problem and approach', plain='Two sentences: the two-stage design task, and the pairing study across 36 pipelines and 77,760 trials.'))
    add(slot('Write VII-C1 here'))
    if N:
        add(note('VII-C2 · Findings with numbers', plain='Three bullets or three sentences: the best pair, the stage-coupling result, the role of the flag-based versus the outcome-based success measure [final run].'))
    add(slot('Write VII-C2 here'))
    if N:
        add(note('VII-C3 · Recommendation, limit, next step', plain='One sentence each.'))
    add(slot('Write VII-C3 here'))

    # ------------------------------------------------------------------ Acknowledgment, references
    add(h5('Acknowledgment'))
    if N:
        add(note('Acknowledgment', plain='Optional. Put sponsor acknowledgments in the unnumbered footnote on the first page, as the template says. Delete this heading if there is nothing to acknowledge.'))
    add(slot('Write the acknowledgment, or delete this heading'))
    add(h5('References'))
    if N:
        add(note('References', [
            'The first 15 entries are the ones you verified in earlier drafts, in the order of your draft. Numbering is automatic; arrange the list in order of first citation and delete the entries you do not cite.',
            'The last six (highlighted) are new candidates for I-P3, II-P3 and IV-P8. I confirmed by search that each exists with this title and venue; I did not open the publisher pages, so check volume, issue and pages before you cite. Boyd and Vandenberghe is from memory and was not searched.']))
    for e in REFS_VERIFIED:
        add(para('references', run(e)))
    for e in REFS_CANDIDATE:
        add(para('references', run(e) + run(' [verify]', hl='yellow')))

    return front_title, author, ''.join(b)
