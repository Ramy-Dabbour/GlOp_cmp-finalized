# Provisional statistics from the 4,947-trial snapshot (rho=0.2, seed 0, orders 4-10, pre-fix code).
# Success at tau (dB): both stages valid and delta = sqrt(E^2 - bound^2) <= 10^(tau/20).
import sys, json
import numpy as np, pandas as pd

SRC = sys.argv[1]; OUT = sys.argv[2]
S = ['GA', 'PSO', 'SO', 'SA', 'PS', 'PaS']      # solver index 0..5
t = pd.read_csv(SRC)
t['ref'] = t.refSolver.map(dict(enumerate(S)))
t['mzi'] = t.mziSolver.map(dict(enumerate(S)))
t['both_valid'] = t.both_valid.astype(bool)
t['delta'] = np.sqrt(np.maximum(t.E**2 - t.E_bound**2, 0.0))
t.loc[~t.both_valid, 'delta'] = np.nan
t['delta_dB'] = 20*np.log10(t.delta)
t['Cev'] = t.total_evals; t['Tsec'] = t.total_seconds
res = {}
res['n_trials'] = int(len(t)); res['orders'] = sorted(t.order.unique().tolist())
res['no_stage2'] = int((~t.both_valid).sum())
res['pairs_n'] = t.groupby(['ref', 'mzi']).size().describe().to_dict()
# best delta per order (instance)
best = t.groupby('order').delta.min()
res['best_delta_by_order'] = {int(k): float(v) for k, v in best.items()}
res['best_delta_dB_by_order'] = {int(k): float(20*np.log10(v)) for k, v in best.items()}
res['best_delta_overall'] = float(best.min()); res['worst_best_delta'] = float(best.max())
res['delta_quantiles'] = {q: float(t.delta.quantile(q)) for q in (0, .05, .25, .5, .75, .95, 1)}
# success tables
taus = [-20, -22.5, -25, -27.5, -30, -35, -40]
rows = []
for (r, m), g in t.groupby(['ref', 'mzi']):
    row = dict(ref=r, mzi=m, n=len(g), valid=int(g.both_valid.sum()),
               evalsTot=float(g.Cev.sum()), secTot=float(g.Tsec.sum()),
               meanDelta_dB=float(20*np.log10(g.delta.mean())) if g.delta.notna().any() else np.nan,
               medDelta=float(g.delta.median()), minDelta=float(g.delta.min()))
    for tau in taus:
        thr = 10**(tau/20)
        s = int(((g.delta <= thr) & g.both_valid).sum())
        row[f's{tau}'] = s; row[f'P{tau}'] = s/len(g)
        row[f'ERT_ev{tau}'] = float(g.Cev.sum()/s) if s else np.nan
        row[f'ERT_s{tau}'] = float(g.Tsec.sum()/s) if s else np.nan
    # legacy
    ok = (g.ref_exit > 0) & (g.mzi_exit > 0) & g.both_valid
    row['legacy_s'] = int(ok.sum()); row['legacy_P'] = ok.sum()/len(g)
    if ok.sum():
        Eb = g.E[ok].mean(); Cb = g.Cev[ok].mean()
        row['legacy_E'] = float(Eb); row['legacy_C'] = float(Cb)
        row['legacy_F'] = float(row['legacy_P']/(Eb*np.log(Cb))) if Cb > 1 else np.nan
    else:
        row['legacy_E'] = row['legacy_C'] = np.nan; row['legacy_F'] = 0.0
    rows.append(row)
P = pd.DataFrame(rows); P.to_csv(OUT + '/pair_stats.csv', index=False)
# exit-flag shares per solver and stage
fl = []
for stage, col, solv in (('S1', 'ref_exit', 'ref'), ('S2', 'mzi_exit', 'mzi')):
    for s_ in S:
        g = t[t[solv] == s_]
        c = g[col].value_counts(dropna=True)
        n = int(g[col].notna().sum())
        fl.append(dict(stage=stage, solver=s_, n=n, **{f'flag{int(k)}': int(v) for k, v in c.items()}))
pd.DataFrame(fl).fillna(0).to_csv(OUT + '/exit_flags.csv', index=False)
# per-stage costs
st = []
for s_ in S:
    g1 = t[t.ref == s_]; g2 = t[(t.mzi == s_) & t.mzi_present]
    st.append(dict(solver=s_, S1_evals=g1.ref_evals.mean(), S1_sec=g1.ref_seconds.mean(),
                   S2_evals=g2.mzi_evals.mean(), S2_sec=g2.mzi_seconds.mean(),
                   S1_gap_baseline=g1.s1_gap_to_baseline.mean(),
                   S2_med_delta=g2.delta.median()))
pd.DataFrame(st).to_csv(OUT + '/stage_costs.csv', index=False)
t.to_csv(OUT + '/trial_delta.csv', index=False)
json.dump(res, open(OUT + '/summary.json', 'w'), indent=1, default=float)
print(json.dumps(res, indent=1, default=float))
