# Numerical check of the Section II identities (half-band, decomposition of E) on random designs.
import numpy as np
rng = np.random.default_rng(1)

def polymul(a, b):
    return np.convolve(a, b)

def cascade(theta, phi, N):
    K = N + 1
    # 2x2 matrix of polynomials in z^-1 (coefficient arrays)
    M = [[np.array([1.0 + 0j]), np.array([0j])], [np.array([0j]), np.array([1.0 + 0j])]]
    def mm(A, B):
        out = [[None, None], [None, None]]
        for i in range(2):
            for j in range(2):
                acc = None
                for k in range(2):
                    t = polymul(A[i][k], B[k][j])
                    if acc is None: acc = t
                    else:
                        L = max(len(acc), len(t))
                        acc = np.pad(acc, (0, L - len(acc))) + np.pad(t, (0, L - len(t)))
                out[i][j] = acc
        return out
    for k in range(1, K + 1):
        d = 2 if k < K else 1
        ph = phi if ((K - k) % 2 == 1) else 0.0     # every second stage counted back from output: K-1, K-3, ...
        a = np.exp(-2j * np.pi * ph)
        c, s = np.cos(2 * np.pi * theta[k - 1]), np.sin(2 * np.pi * theta[k - 1])
        zd = np.zeros(d + 1, complex); zd[d] = 1.0
        S = [[a * c * zd, np.array([1j * s])], [a * 1j * s * zd, np.array([c])]]
        # NOTE: summary: S_k = [[a c z^-d, j s],[j a s z^-d, c]]
        S[1][0] = 1j * a * s * zd
        M = mm(M, S)
    C = np.array([[1, 1j], [1j, 1]]) / np.sqrt(2)
    out = [[None, None], [None, None]]
    for i in range(2):
        for j in range(2):
            acc = None
            for k in range(2):
                t = M[i][k] * C[k, j]
                if acc is None: acc = t
                else:
                    L = max(len(acc), len(t))
                    acc = np.pad(acc, (0, L - len(acc))) + np.pad(t, (0, L - len(t)))
            out[i][j] = acc
    return out

def autocorr(p, L):
    # power response |P(e^jw)|^2 lag coefficients for lags -L..L
    full = np.correlate(p, p, mode='full')          # lags -(n-1)..(n-1)
    n = len(p)
    out = np.zeros(2 * L + 1, complex)
    mid = n - 1
    for lag in range(-(n - 1), n):
        out[lag + L] = full[lag + mid]
    return out

def G_matrix(S, N):
    L = 2 * N + 1
    return np.array([autocorr(S[0][0], L), autocorr(S[0][1], L), autocorr(S[1][0], L), autocorr(S[1][1], L)])

def R_matrix(x, N):
    L = 2 * N + 1
    g = np.zeros(2 * L + 1); g[L] = x[0]
    for k in range(1, len(x)): g[L + k] = x[k] / 2; g[L - k] = x[k] / 2
    e0 = np.zeros(2 * L + 1); e0[L] = 1
    return np.array([g, e0 - g, e0 - g, g])

worst = {}
for N in (4, 7, 12):
    for rho in (0.2, 0.3, 0.4, 0.5):
        k = np.arange(1, N + 1)
        t = np.concatenate([[rho], 2 * rho * np.sinc(rho * k)])
        theta = rng.random(N + 1); phi = rng.random()
        S = cascade(theta, phi, N)
        G = G_matrix(S, N)
        Rt = R_matrix(t, N)
        D = np.sum(np.abs(Rt) ** 2)
        E2 = np.sum(np.abs(G - Rt) ** 2) / D
        L = 2 * N + 1
        g = G[0]
        g0 = g[L].real
        even = max(abs(g[L + kk]) for kk in range(2, L + 1, 2))
        # unitarity / lossless: |S11|^2 + |S12|^2 = 1 -> lag-0 + e0
        uni = np.max(np.abs(G[0] + G[1] - np.eye(1, 2 * L + 1, L)[0]))
        sym = np.max(np.abs(G[0] - G[3]))
        # decomposition
        etop2 = (4 * (0.5 - rho) ** 2 + 2 * sum(t[kk] ** 2 for kk in range(2, N + 1, 2))) / D
        odd = sum(abs(g[L + kk] - (t[kk] / 2 if kk <= N else 0.0)) ** 2 for kk in range(1, L + 1, 2))
        delta2 = 8 * odd / D
        res = abs(E2 - (etop2 + delta2))
        D_formula = 2 * (rho ** 2 + (1 - rho) ** 2 + np.sum(t[1:] ** 2))
        worst[(N, rho)] = (abs(g0 - 0.5), even, uni, sym, res, abs(D - D_formula))
for key, v in worst.items():
    print(key, ' '.join(f'{x:.1e}' for x in v))
print('max over all:', [f'{max(v[i] for v in worst.values()):.1e}' for i in range(6)])
