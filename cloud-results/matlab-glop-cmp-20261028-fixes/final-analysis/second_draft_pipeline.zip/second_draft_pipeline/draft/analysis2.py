# Second-pass provisional statistics for the partial draft (snapshot only).
import sys, json
import numpy as np, pandas as pd
from itertools import product
from scipy.stats import kendalltau, spearmanr

S = ['GA','PSO','SO','SA','PS','PaS']
LONG = {'GA':'Genetic algorithm','PSO':'Particle swarm','SO':'Surrogate opt.','SA':'Simulated annealing','PS':'Pattern search','PaS':'Pareto search'}
t = pd.read_csv('work/trial_delta.csv')
t['rep'] = t.trial
t['ok'] = t.both_valid.astype(bool)
TAUS = [-20,-25,-30,-35,-40]
rng = np.random.default_rng(12345)

def succ(g, tau):
    return (g.ok & (g.delta <= 10**(tau/20))).values

out = {}
# ---------- matrices
P = {tau: pd.DataFrame(index=S, columns=S, dtype=float) for tau in [-20,-22.5,-25,-27.5,-30]}
ERTe = pd.DataFrame(index=S, columns=S, dtype=float); ERTs = ERTe.copy()
N_ = pd.DataFrame(index=S, columns=S, dtype=float)
Fleg = pd.DataFrame(index=S, columns=S, dtype=float); Pleg = Fleg.copy()
medd = Fleg.copy(); meaneval = Fleg.copy(); meansec = Fleg.copy()
for r in S:
    for m in S:
        g = t[(t.ref==r)&(t.mzi==m)]
        N_.loc[r,m] = len(g)
        for tau in P:
            P[tau].loc[r,m] = succ(g,tau).mean()
        s = succ(g,-20).sum()
        ERTe.loc[r,m] = g.Cev.sum()/s if s else np.nan
        ERTs.loc[r,m] = g.Tsec.sum()/s if s else np.nan
        okf = (g.ref_exit>0)&(g.mzi_exit>0)&g.ok
        Pleg.loc[r,m] = okf.mean()
        if okf.sum() and g.Cev[okf].mean()>1:
            Fleg.loc[r,m] = okf.mean()/(g.E[okf].mean()*np.log(g.Cev[okf].mean()))
        else:
            Fleg.loc[r,m] = 0.0
        medd.loc[r,m] = 20*np.log10(g.delta.median())
        meaneval.loc[r,m] = g.Cev.mean(); meansec.loc[r,m] = g.Tsec.mean()
pd.set_option('display.width',200); pd.set_option('display.float_format',lambda x:f'{x:.3f}')
print('n per pair\n', N_.astype(int))
for tau in P: print(f'P(tau={tau})\n', P[tau])
print('ERT evals @-20\n', (ERTe/1e3).round(0))
print('ERT sec @-20\n', ERTs.round(0))
print('legacy P\n', Pleg); print('legacy F\n', Fleg)
print('median delta dB\n', medd)
print('mean evals per trial (k)\n', (meaneval/1e3).round(1))
print('mean sec per trial\n', meansec.round(0))

# ---------- marginals
def marg(col):
    rows=[]
    for s_ in S:
        g = t[t[col]==s_]
        rows.append(dict(solver=s_, n=len(g), P20=succ(g,-20).mean(), P25=succ(g,-25).mean(), medd=20*np.log10(g.delta.median()),
                         meanEv=g.Cev.mean(), meanSec=g.Tsec.mean(), s1gap=g.s1_gap_to_baseline.median()))
    return pd.DataFrame(rows)
print('MARGINAL BY STAGE-1\n', marg('ref')); print('MARGINAL BY STAGE-2\n', marg('mzi'))

# ---------- rankings and agreement
pairs = [(r,m) for r in S for m in S]
tab = pd.DataFrame({'pair':[f'{r}>{m}' for r,m in pairs],
                    'P20':[P[-20].loc[r,m] for r,m in pairs],
                    'P25':[P[-25].loc[r,m] for r,m in pairs],
                    'ERTe':[ERTe.loc[r,m] for r,m in pairs],
                    'ERTs':[ERTs.loc[r,m] for r,m in pairs],
                    'F':[Fleg.loc[r,m] for r,m in pairs],
                    'Pleg':[Pleg.loc[r,m] for r,m in pairs],
                    'medd':[medd.loc[r,m] for r,m in pairs],
                    'meanEv':[meaneval.loc[r,m] for r,m in pairs],
                    'meanSec':[meansec.loc[r,m] for r,m in pairs]})
tab['ERTe_fill'] = tab.ERTe.fillna(np.inf)
print('\nTOP 8 by P20 then ERT')
print(tab.sort_values(['P20','ERTe_fill'],ascending=[False,True]).head(10).to_string())
print('\nTOP 8 by ERT (evals)')
print(tab.sort_values('ERTe_fill').head(10).to_string())
print('\nTOP 8 by ERT (sec)')
print(tab.assign(ERTs_fill=tab.ERTs.fillna(np.inf)).sort_values('ERTs_fill').head(10).to_string())
print('\nTOP 8 by legacy F')
print(tab.sort_values('F',ascending=False).head(10).to_string())
print('pairs with legacy F = 0:', int((tab.F==0).sum()), ' pairs with P20=0:', int((tab.P20==0).sum()), ' pairs with P20>=0.9:', int((tab.P20>=0.9).sum()))
# Kendall tau: F vs P20, F vs -ERT, F vs -medd
def kt(a,b):
    m = np.isfinite(a)&np.isfinite(b)
    return kendalltau(a[m],b[m])
print('Kendall F~P20', kt(tab.F.values, tab.P20.values))
print('Kendall F~(-ERTe)', kt(tab.F.values, -tab.ERTe_fill.values))
print('Kendall F~(-medd)', kt(tab.F.values, -tab.medd.values))
print('Kendall P20~P25', kt(tab.P20.values, tab.P25.values))
print('Kendall P20~(-ERTe) among success', kt(tab.P20.values, -tab.ERTe_fill.values))
print('Kendall Pleg~P20', kt(tab.Pleg.values, tab.P20.values))

# ---------- non-dominated pairs in (P20 up, ERT down)
def nondom(df, xcol, ycol, xmax=True, ymin=True):
    keep=[]
    for i,a in df.iterrows():
        dom=False
        for j,b in df.iterrows():
            if i==j: continue
            ge = (b[xcol]>=a[xcol]) if xmax else (b[xcol]<=a[xcol])
            le = (b[ycol]<=a[ycol]) if ymin else (b[ycol]>=a[ycol])
            gt = ((b[xcol]>a[xcol]) if xmax else (b[xcol]<a[xcol])) or ((b[ycol]<a[ycol]) if ymin else (b[ycol]>a[ycol]))
            if ge and le and gt: dom=True;break
        if not dom: keep.append(a['pair'])
    return keep
d = tab[tab.P20>0].copy()
print('NONDOM (P20, ERTe):', nondom(d,'P20','ERTe'))
print('NONDOM (P20, ERTs):', nondom(d,'P20','ERTs'))
d2 = tab.copy()
print('NONDOM (medd min, meanEv min):', nondom(d2,'medd','meanEv',xmax=False,ymin=True))

# ---------- block bootstrap over repeats (20 blocks, each spans orders)
B=2000
reps = sorted(t.rep.unique())
idx = {rp: np.where(t.rep.values==rp)[0] for rp in reps}
def pair_stats_boot(sel_ref, sel_mzi, tau=-20, B=B):
    g = t[(t.ref==sel_ref)&(t.mzi==sel_mzi)]
    gi = {rp: np.where(g.rep.values==rp)[0] for rp in reps}
    ok = succ(g,tau); ev = g.Cev.values; sc = g.Tsec.values
    Ps=[];Es=[]
    for b in range(B):
        draw = rng.choice(reps, size=len(reps), replace=True)
        ii = np.concatenate([gi[rp] for rp in draw])
        s = ok[ii].sum(); n=len(ii)
        Ps.append(s/n); Es.append(ev[ii].sum()/s if s else np.nan)
    Ps=np.array(Ps); Es=np.array(Es)
    return (np.percentile(Ps,[2.5,97.5]), np.nanpercentile(Es,[2.5,97.5]), int(np.isnan(Es).sum()))
CI = {}
for pr in [('GA','PSO'),('PSO','PSO'),('PSO','PS'),('GA','PS'),('PSO','SO'),('GA','SO'),('PS','PS'),('SA','SA'),('GA','GA'),('PSO','GA'),('PSO','PaS'),('GA','PaS')]:
    pc, ec, nd = pair_stats_boot(*pr)
    CI['>'.join(pr)] = dict(P=[float(pc[0]),float(pc[1])], ERT=[float(ec[0]),float(ec[1])], dropped=nd)
    print(pr, 'P CI', np.round(pc,3), 'ERT CI(k ev)', np.round(ec/1e3,0), 'dropped', nd)

# ---------- stage-1 effect: Spearman between S1 gap and final delta ----------
v = t[t.ok & t.s1_gap_to_baseline.notna() & t.delta.notna()]
print('Spearman(S1 gap, delta) =', spearmanr(v.s1_gap_to_baseline, v.delta))
# within each stage-2 solver
for m in S:
    vv = v[v.mzi==m]
    print(' S2=',m, 'spearman', round(spearmanr(vv.s1_gap_to_baseline, vv.delta)[0],3), 'n', len(vv))
# stage-2 cost by stage-1 solver for each stage-2 solver (mean mzi_evals)
cost = t[t.mzi_present].groupby(['mzi','ref']).mzi_evals.mean().unstack()[S].loc[S]
print('Stage-2 mean evals by (S2 row, S1 col)\n', cost.round(0))
medd_by = t.groupby(['mzi','ref']).delta.median().unstack()[S].loc[S].apply(lambda c: 20*np.log10(c))
print('median delta dB by (S2 row, S1 col)\n', medd_by.round(1))
# order dependence of best pairs
for pr in [('GA','PSO'),('PSO','PS'),('GA','PS'),('PSO','PSO')]:
    g = t[(t.ref==pr[0])&(t.mzi==pr[1])]
    print(pr, 'by order: P20', {int(o): round(float(succ(gg,-20).mean()),2) for o,gg in g.groupby('order')},
          ' median delta dB', {int(o): round(float(20*np.log10(gg.delta.median())),1) for o,gg in g.groupby('order')})
# best delta per order
print('best delta dB by order', t.groupby('order').delta.min().apply(lambda x: round(20*np.log10(x),1)).to_dict())
# stage-1 gap and baseline
print('S1 gap to baseline (median) by solver', t.groupby('ref').s1_gap_to_baseline.median().to_dict())
print('S1 gap to baseline (mean) by solver', t.groupby('ref').s1_gap_to_baseline.mean().to_dict())
print('S1 gap relative to baseline objective? baseline_lower stats', t.baseline_lower.describe().to_dict())
# fraction of trials per stage-1 solver where final delta <= -20
# coverage
print('n trials', len(t), ' both_valid False', int((~t.ok).sum()))
print('min(E-E_bound)', float((t.E-t.E_bound).min()), ' min margin where valid', float((t.E-t.E_bound)[t.ok].min()))
json.dump(CI, open('work/ci_boot.json','w'), indent=1)
tab.to_csv('work/pair_table2.csv', index=False)
for tau in P: P[tau].to_csv(f'work/P_{tau}.csv')
ERTe.to_csv('work/ERTe_20.csv'); ERTs.to_csv('work/ERTs_20.csv'); Fleg.to_csv('work/Fleg.csv'); Pleg.to_csv('work/Pleg.csv')
medd.to_csv('work/medd.csv'); meaneval.to_csv('work/meaneval.csv'); meansec.to_csv('work/meansec.csv'); cost.to_csv('work/s2cost_by_s1.csv'); medd_by.to_csv('work/medd_by_s1.csv')
