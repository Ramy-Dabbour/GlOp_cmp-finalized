# Figures for the partial draft. Static PNGs sized to one IEEE column (3.4 in).
import sys, json
import numpy as np, pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, Circle, FancyArrowPatch
from matplotlib.colors import LinearSegmentedColormap, Normalize
from scipy.stats import spearmanr

SRC = sys.argv[1] if len(sys.argv) > 1 else 'work/trial_delta.csv'
OUT = sys.argv[2] if len(sys.argv) > 2 else 'figs'
plt.rcParams.update({'font.family': 'serif', 'font.serif': ['Liberation Serif', 'DejaVu Serif'],
                     'mathtext.fontset': 'stix', 'font.size': 7, 'axes.linewidth': 0.5,
                     'axes.edgecolor': '#6b6b6b', 'text.color': '#1b1b1b', 'axes.labelcolor': '#1b1b1b',
                     'xtick.color': '#3b3b3b', 'ytick.color': '#3b3b3b', 'xtick.major.width': 0.5,
                     'ytick.major.width': 0.5, 'xtick.major.size': 2.5, 'ytick.major.size': 2.5,
                     'savefig.dpi': 300, 'figure.dpi': 150})
INK = '#1b1b1b'; MUTED = '#5c5c5c'; GRID = '#dddddd'
CAT = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300']     # validated order
S = ['GA', 'PSO', 'SO', 'SA', 'PS', 'PAR']
ALIAS = {'PaS': 'PAR'}
t = pd.read_csv(SRC)
t['ref'] = t.ref.replace(ALIAS); t['mzi'] = t['mzi'].replace(ALIAS)
t['ok'] = t.both_valid.astype(bool)
W = 3.4

def box(ax, x, y, w, h, text, fc='#f4f4f2', ec='#6b6b6b', fs=6.6, bold=False, lw=0.6):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.0,rounding_size=0.04', fc=fc, ec=ec, lw=lw))
    ax.text(x + w / 2, y + h / 2, text, ha='center', va='center', fontsize=fs, fontweight='bold' if bold else 'normal', linespacing=1.15)

def arrow(ax, p0, p1, lw=0.7, style='-|>', color=INK, ls='-', rad=0.0, ms=6):
    ax.add_patch(FancyArrowPatch(p0, p1, arrowstyle=style, mutation_scale=ms, lw=lw, color=color, ls=ls,
                                 connectionstyle=f'arc3,rad={rad}', shrinkA=0, shrinkB=0))

# ---------------------------------------------------------------- Fig. 1
def fig1():
    H = 2.78
    fig = plt.figure(figsize=(W, H)); ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, W); ax.set_ylim(0, H); ax.axis('off')
    ax.text(0.02, 2.66, '(a)', fontsize=7, fontweight='bold', va='bottom'); ax.text(0.20, 2.66, 'Two-stage design pipeline', fontsize=6.8, va='bottom', style='italic')
    y0, h = 1.74, 0.50
    box(ax, 0.02, y0, 0.74, h, 'Target\n$\\mathbf{t}(N,\\rho)$', fs=6.8)
    box(ax, 0.98, y0, 0.74, h, 'Stage 1\nsolver $i$', fc='#e8f0fb', ec='#2a78d6', fs=6.8)
    box(ax, 1.94, y0, 0.74, h, 'Stage 2\nsolver $j$', fc='#fdeee6', ec='#eb6834', fs=6.8)
    box(ax, 2.90, y0, 0.48, h, 'Score\n$E,\\delta$', fs=6.8)
    mid = y0 + h / 2
    arrow(ax, (0.76, mid), (0.98, mid)); arrow(ax, (1.72, mid), (1.94, mid)); arrow(ax, (2.68, mid), (2.90, mid))
    ax.text(1.35, y0 + h + 0.025, '$\\mathbf{x}^{*}$', fontsize=7, ha='center', va='bottom', color=MUTED)
    ax.text(2.31, y0 + h + 0.025, '$(\\boldsymbol{\\theta},\\varphi)$', fontsize=7, ha='center', va='bottom', color=MUTED)
    ax.text(1.35, y0 - 0.05, 'nearest admissible\nreference', fontsize=6.0, ha='center', va='top', color=MUTED, linespacing=1.1)
    ax.text(2.31, y0 - 0.05, 'angles and\nshared phase', fontsize=6.0, ha='center', va='top', color=MUTED, linespacing=1.1)
    yt = 2.46
    arrow(ax, (0.39, y0 + h), (0.39, yt), lw=0.6, style='-', color=MUTED, ls=(0, (3, 2)))
    arrow(ax, (0.39, yt), (3.14, yt), lw=0.6, style='-', color=MUTED, ls=(0, (3, 2)))
    arrow(ax, (3.14, yt), (3.14, y0 + h), lw=0.6, style='-|>', color=MUTED, ls=(0, (3, 2)))
    ax.text(1.76, yt + 0.02, 'scored against the raw target $\\mathbf{t}$', fontsize=6.2, ha='center', va='bottom', color=MUTED, style='italic')
    # lattice
    ya, yb = 0.86, 0.34
    ax.text(0.02, 1.33, '(b)', fontsize=7, fontweight='bold', va='bottom'); ax.text(0.20, 1.33, 'Lattice realized by Stage 2', fontsize=6.8, va='bottom', style='italic')
    xl, xr = 0.22, 3.10
    ax.plot([xl, xr], [ya, ya], color=INK, lw=0.8, solid_capstyle='butt'); ax.plot([xl, xr], [yb, yb], color=INK, lw=0.8, solid_capstyle='butt')
    for yy in (ya, yb):
        ax.text(xl - 0.03, yy, 'in', ha='right', va='center', fontsize=6.2, color=MUTED)
        ax.text(xr + 0.03, yy, 'out', ha='left', va='center', fontsize=6.2, color=MUTED)
    ax.text(0.40, (ya + yb) / 2, '$\\cdots$', ha='center', va='center', fontsize=9)
    lab = ['K{-}3', 'K{-}2', 'K{-}1', 'K']
    dl = ['z^{-2}', 'z^{-2}', 'z^{-2}', 'z^{-1}']
    phase = [True, False, True, False]
    x = 0.54; sw = 0.58
    for k in range(4):
        ax.add_patch(Rectangle((x, ya - 0.095), 0.25, 0.19, fc='#f4f4f2', ec='#6b6b6b', lw=0.6, zorder=3))
        ax.text(x + 0.125, ya, f'${dl[k]}$', ha='center', va='center', fontsize=6.2, zorder=4)
        if phase[k]:
            ax.add_patch(Circle((x + 0.335, ya), 0.065, fc='#fff4d6', ec='#b07d00', lw=0.6, zorder=3))
            ax.text(x + 0.335, ya, '$\\varphi$', ha='center', va='center', fontsize=6.0, zorder=4)
        cx = x + 0.44
        ax.add_patch(Rectangle((cx, yb - 0.07), 0.08, ya - yb + 0.14, fc='#e8f0fb', ec='#2a78d6', lw=0.7, zorder=3))
        ax.text(cx + 0.04, yb - 0.12, f'$\\theta_{{{lab[k]}}}$', ha='center', va='top', fontsize=6.4)
        x += sw
    fx = x + 0.02
    ax.add_patch(Rectangle((fx, yb - 0.07), 0.08, ya - yb + 0.14, fc='#cfd6dd', ec='#4a5560', lw=0.7, zorder=3))
    ax.text(fx + 0.04, yb - 0.12, '50:50', ha='center', va='top', fontsize=6.0, color=INK)
    ax.text(0.54, ya + 0.14, 'stage $K{-}3$', fontsize=5.8, color=MUTED, ha='left', va='bottom')
    ax.text(0.54 + 3 * sw, ya + 0.14, 'stage $K$', fontsize=5.8, color=MUTED, ha='left', va='bottom')
    ax.text(1.70, 0.03, '$K=N{+}1$ tunable stages, one fixed coupler, $N{+}2$ variables', fontsize=6.0, ha='center', va='bottom', color=MUTED)
    fig.savefig(f'{OUT}/fig1_pipeline.png'); plt.close(fig)

# ---------------------------------------------------------------- stats helpers
def succ(g, tau): return (g.ok & (g.delta <= 10 ** (tau / 20))).values

def pmat(tau):
    M = pd.DataFrame(index=S, columns=S, dtype=float)
    for r in S:
        for m in S:
            g = t[(t.ref == r) & (t.mzi == m)]; M.loc[r, m] = succ(g, tau).mean()
    return M

def ertmat(tau):
    M = pd.DataFrame(index=S, columns=S, dtype=float)
    for r in S:
        for m in S:
            g = t[(t.ref == r) & (t.mzi == m)]; s = succ(g, tau).sum()
            M.loc[r, m] = g.Cev.sum() / s if s else np.nan
    return M

def fmt_k(v):
    if not np.isfinite(v): return '–'
    if v >= 1e6: return f'{v/1e6:.1f}M'
    if v >= 1e4: return f'{v/1e3:.0f}k'
    if v >= 1e3: return f'{v/1e3:.1f}k'
    return f'{v:.0f}'

# ---------------------------------------------------------------- Fig. 2
def fig2():
    P = pmat(-20); E = ertmat(-20)
    seq = LinearSegmentedColormap.from_list('seqblue', ['#eaf2fc', '#9ec5f4', '#3987e5', '#1c5cab', '#0d366b'])
    org = LinearSegmentedColormap.from_list('seqorange', ['#fdeee6', '#f7c3a8', '#eb6834', '#b84a1f', '#7a2f10'])
    fig, axs = plt.subplots(1, 2, figsize=(W, 1.88), gridspec_kw={'wspace': 0.12})
    for ax, M, title, norm, fmt, lg, cm in ((axs[0], P, '(a) Success fraction, $\\delta\\leq-20$ dB', Normalize(0, 1), lambda v: f'{v:.2f}', False, seq),
                                        (axs[1], E, '(b) Evaluations per success', Normalize(3.3, 6.6), fmt_k, True, org)):
        A = M.values.astype(float)
        D = np.log10(A) if lg else A
        Dm = np.ma.masked_invalid(D)
        ax.imshow(Dm, cmap=cm, norm=norm, aspect='auto')
        for i in range(6):
            for j in range(6):
                v = A[i, j]
                if not np.isfinite(v):
                    ax.text(j, i, '–', ha='center', va='center', fontsize=6, color=MUTED); continue
                dark = (norm(D[i, j]) > 0.52)
                ax.text(j, i, fmt(v), ha='center', va='center', fontsize=6.0, color='white' if dark else INK)
        ax.set_xticks(range(6)); ax.set_xticklabels(S, fontsize=6.3)
        ax.xaxis.tick_top(); ax.tick_params(axis='x', length=0, pad=1.5)
        ax.set_yticks(range(6)); ax.set_yticklabels(S if ax is axs[0] else [], fontsize=6.3); ax.tick_params(axis='y', length=0, pad=1.5)
        ax.set_xticks(np.arange(-.5, 6, 1), minor=True); ax.set_yticks(np.arange(-.5, 6, 1), minor=True)
        ax.grid(which='minor', color='white', lw=1.0); ax.tick_params(which='minor', length=0)
        for s_ in ax.spines.values(): s_.set_visible(False)
        ax.set_title(title, fontsize=6.9, pad=13, loc='left')
    axs[0].set_ylabel('Stage-1 solver', fontsize=6.8, labelpad=2)
    fig.text(0.50, 0.005, 'Stage-2 solver (columns)', fontsize=6.8, ha='center', va='bottom', color=INK)
    fig.subplots_adjust(left=0.115, right=0.995, top=0.80, bottom=0.10)
    fig.savefig(f'{OUT}/fig2_heatmaps.png'); plt.close(fig)

# ---------------------------------------------------------------- Fig. 3
def fig3():
    fig, (a, b) = plt.subplots(2, 1, figsize=(W, 3.75), gridspec_kw={'hspace': 0.52, 'height_ratios': [1, 1.05]})
    taus = np.arange(-10, -34.01, -0.5)
    Pm = {tau: pmat(tau) for tau in (-20, -25)}
    Ee = ertmat(-20)
    Es = pd.DataFrame(index=S, columns=S, dtype=float)
    for r in S:
        for m in S:
            g = t[(t.ref == r) & (t.mzi == m)]; s_ = succ(g, -20).sum()
            Es.loc[r, m] = g.Tsec.sum() / s_ if s_ else np.nan
    def arg(M, mask=None, lo=False):
        A = M.copy()
        if mask is not None: A = A.where(mask)
        st = A.stack()
        return st.idxmin() if lo else st.idxmax()
    cand = [arg(Pm[-25]),                                              # highest P(-25)
            arg(Pm[-20].loc[['GA']]),                                  # best pair with GA first
            arg(Es, Pm[-20] >= 0.9, lo=True),                          # fewest seconds per success among P(-20) >= 0.9
            arg(Ee, Pm[-20] > 0, lo=True),                             # fewest evaluations per success
            arg(Pm[-20].loc[['PAR']]),                                 # best pair with PAR first
            arg(Pm[-20][['SA']])]                                      # best pair with SA second
    sel = []
    for c in cand:
        if c not in sel: sel.append(c)
    json.dump([list(c) for c in sel], open(f'{OUT}/fig3_pairs.json', 'w'))
    sty = [('-', 'o'), ('--', 's'), ('-.', '^'), (':', 'D'), ('-', 'v'), ('--', 'P')]
    for (r, m), (ls, mk), c in zip(sel, sty, CAT):
        g = t[(t.ref == r) & (t.mzi == m)]
        y = [succ(g, tau).mean() for tau in taus]
        a.plot(taus, y, color=c, ls=ls, lw=1.2, marker=mk, ms=2.6, mew=0.0, markevery=4, label=f'{r}→{m}', solid_capstyle='round')
    a.set_xlim(-10, -34); a.set_ylim(-0.02, 1.04)
    a.set_xlabel('Tolerance $\\tau$ (dB); stricter $\\rightarrow$', fontsize=6.9, labelpad=1.5); a.set_ylabel('Success fraction $P(\\tau)$', fontsize=6.9, labelpad=1.5)
    for tv in (-20, -25, -30):
        a.axvline(tv, color=GRID, lw=0.6, zorder=0)
    a.set_xticks([-10, -15, -20, -25, -30]); a.set_yticks([0, .25, .5, .75, 1.0]); a.set_yticklabels(['0', '0.25', '0.5', '0.75', '1'])
    a.tick_params(labelsize=6.5)
    a.grid(axis='y', color=GRID, lw=0.5); a.set_axisbelow(True)
    for s_ in ('top', 'right'): a.spines[s_].set_visible(False)
    leg = a.legend(loc='lower center', bbox_to_anchor=(0.5, 1.0), ncol=3, fontsize=6.2, frameon=False, handlelength=2.4, columnspacing=1.2, handletextpad=0.4, borderaxespad=0.1, labelspacing=0.25)
    a.text(-0.135, 1.30, '(a)', transform=a.transAxes, fontsize=7, fontweight='bold', va='bottom')
    # panel b: final delta vs stage-1 gap
    v = t[t.ok & (t.mzi != 'SA') & t.s1_gap_to_baseline.notna()].copy()
    v['gap'] = np.maximum(v.s1_gap_to_baseline, 1e-6)
    rho_ = spearmanr(v.s1_gap_to_baseline, v.delta)[0]
    mk = ['o', 's', '^', 'D', 'v', 'P']
    rng = np.random.default_rng(1)
    for k, s_ in enumerate(S):
        g = v[v.ref == s_]
        b.scatter(g.gap, g.delta_dB, s=2.0, marker=mk[k], color=CAT[k], alpha=0.10, linewidths=0, label=s_, rasterized=True)
    b.set_xscale('log'); b.set_xlim(8e-7, 3)
    b.set_ylim(-36, 2)
    b.set_xlabel('Stage-1 gap to the convex baseline (objective units)', fontsize=6.9, labelpad=1.5)
    b.set_ylabel('Final $\\delta$ (dB)', fontsize=6.9, labelpad=1.5)
    b.tick_params(labelsize=6.5); b.grid(color=GRID, lw=0.5); b.set_axisbelow(True)
    for s_ in ('top', 'right'): b.spines[s_].set_visible(False)
    # direct labels beside each cluster (SO and SA overlap: one joint label)
    for name, x_, y_ in (('PSO', 5e-4, -32.6), ('GA', 7e-3, -32.6), ('PS', 0.075, -30.2), ('PAR', 0.085, -6.5), ('SO, SA', 0.22, -1.0)):
        b.text(x_, y_, name, fontsize=6.6, color=INK, ha='center', va='center', fontweight='bold')
    b.text(-0.135, 1.04, '(b)', transform=b.transAxes, fontsize=7, fontweight='bold', va='bottom')
    b.text(0.01, 0.93, f'Spearman $\\rho_s$ = {rho_:.2f}', transform=b.transAxes, fontsize=6.2, ha='left', va='bottom', color=MUTED)
    fig.subplots_adjust(left=0.135, right=0.985, top=0.872, bottom=0.090)
    fig.savefig(f'{OUT}/fig3_curves.png'); plt.close(fig)
    return rho_


# ---------------------------------------------------------------- Fig. 4
def fig4():
    grp_s2 = ['GA', 'PSO', 'SO', 'PS']
    fig, axs = plt.subplots(2, 2, figsize=(W, 2.75), sharex=True, sharey=True, gridspec_kw={'hspace': 0.30, 'wspace': 0.10})
    first = [('PSO', CAT[1], 's'), ('GA', CAT[0], 'o'), ('PS', CAT[4], 'v')]
    out = {}
    for ax, rho in zip(axs.ravel(), (0.2, 0.3, 0.4, 0.5)):
        for r, c, mk in first:
            g = t[(t.ref == r) & t.mzi.isin(grp_s2) & (np.isclose(t.ratio, rho))]
            for tau, ls, fill in ((-20, '-', c), (-25, (0, (3, 1.6)), 'white')):
                y = g.assign(s=succ(g, tau)).groupby('order').s.mean()
                ax.plot(y.index, y.values, color=c, ls=ls, lw=1.1, marker=mk, ms=2.9, mfc=fill, mec=c, mew=0.7,
                        label=f'{r}, {tau} dB'.replace('-', '\u2212'), solid_capstyle='round')
                out[f'{r}|{rho}|{tau}'] = {int(k): float(x) for k, x in y.items()}
        ax.set_title(f'$\\rho$ = {rho}', fontsize=6.9, pad=2.5, loc='left')
        ax.set_ylim(-0.04, 1.06); ax.set_xticks(range(4, 13)); ax.set_yticks([0, .5, 1.0]); ax.set_yticklabels(['0', '0.5', '1'])
        ax.tick_params(labelsize=6.3); ax.grid(axis='y', color=GRID, lw=0.5); ax.set_axisbelow(True)
        for s_ in ('top', 'right'): ax.spines[s_].set_visible(False)
    for ax in axs[1]: ax.set_xlabel('Order $N$', fontsize=6.9, labelpad=1.5)
    for ax in axs[:, 0]: ax.set_ylabel('Success fraction', fontsize=6.9, labelpad=1.5)
    h, l = axs[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc='upper center', ncol=3, fontsize=6.2, frameon=False, handlelength=2.6, columnspacing=1.2, handletextpad=0.4, bbox_to_anchor=(0.54, 1.005), labelspacing=0.25)
    fig.subplots_adjust(left=0.115, right=0.99, top=0.845, bottom=0.115)
    fig.savefig(f'{OUT}/fig4_order.png'); plt.close(fig)
    json.dump(out, open(f'{OUT}/fig4_data.json', 'w'))

if __name__ == '__main__':
    fig1(); fig2(); r = fig3(); fig4(); print('spearman', r)
