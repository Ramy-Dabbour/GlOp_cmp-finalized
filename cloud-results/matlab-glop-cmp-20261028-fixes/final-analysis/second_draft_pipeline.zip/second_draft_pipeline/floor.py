import numpy as np, pandas as pd
from scipy.optimize import minimize
def floor(N,rho,M=6001):
    k=np.arange(1,N+1); t=np.concatenate([[rho],2*rho*np.sinc(rho*k)])
    D=2*(rho**2+(1-rho)**2+np.sum(t[1:]**2))
    odd=np.arange(1,2*N+2,2); tk=np.array([t[j]/2 if j<=N else 0.0 for j in odd])
    w=np.linspace(0,np.pi/2,M)           # half-band symmetry: |dev| on [0,pi/2] suffices
    C=2*np.cos(np.outer(w,odd))
    f=lambda g: np.sum((g-tk)**2); jac=lambda g: 2*(g-tk)
    cons=[{'type':'ineq','fun':lambda g:0.5-C@g,'jac':lambda g:-C},{'type':'ineq','fun':lambda g:0.5+C@g,'jac':lambda g:C}]
    r=minimize(f,np.zeros(len(odd)),jac=jac,constraints=cons,method='SLSQP',options={'maxiter':2000,'ftol':1e-18})
    g=r.x; lo=np.sqrt(8*f(g)/D)
    # feasible upper bound: shrink toward 0 until dense-grid feasible
    wd=np.linspace(0,np.pi,200001); dev=np.abs(2*np.cos(np.outer(wd,odd))@g).max()
    gu=g*min(1,0.5/dev); up=np.sqrt(8*f(gu)/D)
    return lo,up,r.success,dev-0.5
rows=[]
for N in range(4,13):
    for rho in (.2,.3,.4,.5):
        lo,up,ok,v=floor(N,rho); rows.append(dict(order=N,ratio=rho,floor_lo=lo,floor_up=up,ok=ok,viol=v))
f=pd.DataFrame(rows); f['floor_dB']=20*np.log10(f.floor_lo); f['floor_up_dB']=20*np.log10(f.floor_up)
t=pd.read_csv('trial_delta.csv')
b=t.groupby(['order','ratio']).delta.min().rename('best').reset_index(); f=f.merge(b); f['best_dB']=20*np.log10(f.best); f['gap_dB']=f.best_dB-f.floor_dB
pd.set_option('display.width',200); print(f.round(4).to_string())
print('all ok',f.ok.all(),'min (best-floor_lo)',(f.best-f.floor_lo).min(),'max up-lo dB',(f.floor_up_dB-f.floor_dB).max())
print(f.pivot(index='ratio',columns='order',values='floor_dB').round(1)); print(f.pivot(index='ratio',columns='order',values='gap_dB').round(1))
f.to_csv('delta_floor.csv',index=False)
